import { db } from "@/lib/db";
import { cookies } from "next/headers";
import { createHash, randomBytes } from "node:crypto";

// Admin auth using a password set in environment variables.
// On Vercel, set ADMIN_PASSWORD env var. Locally, defaults to "admin123".
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "admin123";
const SESSION_DURATION = 7 * 24 * 60 * 60 * 1000; // 7 days

export function hashToken(token: string): string {
  return createHash("sha256").update(token).digest("hex");
}

export async function createSession(): Promise<string> {
  const token = randomBytes(32).toString("hex");
  const hashed = hashToken(token);

  await db.adminSession.create({
    data: {
      token: hashed,
      expiresAt: new Date(Date.now() + SESSION_DURATION),
    },
  });

  return token;
}

export async function validateSession(token: string | undefined): Promise<boolean> {
  if (!token) return false;
  const hashed = hashToken(token);

  const session = await db.adminSession.findUnique({
    where: { token: hashed },
  });

  if (!session) return false;
  if (session.expiresAt < new Date()) {
    await db.adminSession.delete({ where: { id: session.id } });
    return false;
  }

  return true;
}

export async function destroySession(token: string): Promise<void> {
  const hashed = hashToken(token);
  try {
    await db.adminSession.delete({ where: { token: hashed } });
  } catch {
    // session may not exist
  }
}

export async function getAuthToken(): Promise<string | undefined> {
  const cookieStore = await cookies();
  return cookieStore.get("admin-token")?.value;
}

export async function isAuthenticated(): Promise<boolean> {
  const token = await getAuthToken();
  return validateSession(token);
}

export function verifyPassword(password: string): boolean {
  return password === ADMIN_PASSWORD;
}
