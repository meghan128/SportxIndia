// Shared client-side types for SportX India

export type PostStatus = "published" | "quarantined" | "pending";

export type PostSummary = {
  id: string;
  slug: string;
  title: string;
  excerpt: string | null;
  coverSeed: string;
  readMinutes: number;
  publishedAt: string;
  contentHash: string;
  status: PostStatus;
  moderationScore: number;
  featured: boolean;
  views: number;
  author: { login: string; displayName: string };
  categories: { slug: string; name: string }[];
  tags: { slug: string; name: string }[];
};

export type PostDetail = PostSummary & {
  content: string;
  contentPlain: string;
  importedAt: string;
  moderationReasons: string;
  author: PostSummary["author"] & { bio: string | null; role: string };
};

export type FilterData = {
  categories: { slug: string; name: string; count: number }[];
  authors: { login: string; displayName: string; role: string; count: number }[];
  tags: { slug: string; name: string; count: number }[];
};

export type DashboardStats = {
  posts: { total: number; published: number; quarantined: number };
  incidents: { open: number };
  reports: { open: number; total: number };
  integrity: { verifiedFingerprints: number; algorithm: string; coverage: number };
  engagement: { totalViews: number };
  activity: { auditEntries24h: number };
};

export type AuditEntry = {
  id: string;
  action: string;
  actor: string;
  targetType: string;
  targetId: string | null;
  message: string;
  severity: "info" | "warning" | "critical";
  metadata: string;
  createdAt: string;
};

export type SecurityIncident = {
  id: string;
  postId: string;
  type: string;
  severity: "low" | "medium" | "high" | "critical";
  reason: string;
  status: "open" | "resolved" | "ignored";
  detectedAt: string;
  resolvedAt: string | null;
  resolvedBy: string | null;
  resolution: string | null;
  post: { title: string; slug: string; status: string; moderationScore: number } | null;
};

export type ContentReport = {
  id: string;
  reporterName: string;
  reporterEmail: string;
  infringingUrl: string;
  postId: string | null;
  post: { title: string; slug: string } | null;
  description: string;
  status: "open" | "investigating" | "resolved" | "dismissed";
  createdAt: string;
  updatedAt: string;
};
