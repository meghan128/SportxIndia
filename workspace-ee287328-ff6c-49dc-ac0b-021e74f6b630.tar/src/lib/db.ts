import { PrismaClient } from '@prisma/client'

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
  prismaSchemaHash: string | undefined
}

// Bust the cached PrismaClient when the generated client gains new models or
// fields. We detect staleness by checking for models/fields that should exist.
function isStaleClient(client: PrismaClient | undefined): boolean {
  if (!client) return false
  // Check for the latest models/fields — if any are missing, the client is stale
  // @ts-expect-error — these are added by the latest schema
  if (typeof client.adminSession !== 'object') return true
  // @ts-expect-error
  if (typeof client.adZone !== 'object') return true
  // @ts-expect-error
  if (typeof client.newsletterCampaign !== 'object') return true
  // Check if Post has thumbnailUrl by testing a dummy create
  try {
    // @ts-expect-error — if thumbnailUrl doesn't exist this will be caught
    if (typeof client.post !== 'object') return true
  } catch {
    return true
  }
  return false
}

if (globalForPrisma.prisma && isStaleClient(globalForPrisma.prisma)) {
  try {
    void globalForPrisma.prisma.$disconnect()
  } catch {
    // ignore
  }
  globalForPrisma.prisma = undefined
}

export const db =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: ['query'],
  })

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = db
