"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Search,
  ShieldCheck,
  Menu,
  X,
  Filter,
  TrendingUp,
  Clock,
  ArrowRight,
  Sparkles,
  Fingerprint,
  ChevronDown,
  Loader2,
  Newspaper,
  Flag,
  Lock,
  CheckCircle2,
  AlertTriangle,
  Eye,
  PenTool,
  Bookmark,
  BarChart3,
  Hash,
  Twitter,
  Github,
  Rss,
  Mail,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { CoverArt } from "@/components/cover-art";
import { ArticleReader } from "@/components/article-reader";
import { SecurityCenter } from "@/components/security-center";
import { ReportContentDialog } from "@/components/report-content-dialog";
import { ThemeToggle } from "@/components/theme-toggle";
import { NewsletterSignup } from "@/components/newsletter-signup";
import { useKeyboardNav, KeyboardHelpOverlay } from "@/components/keyboard-nav";
import { AuthorProfileModal } from "@/components/author-profile-modal";
import { ReadingHistory, useReadingHistory } from "@/components/reading-history";
import { BackToTop } from "@/components/back-to-top";
import { useBookmarks, BookmarksDrawer } from "@/components/bookmarks";
import { ScrollReveal } from "@/components/scroll-reveal";
import { NumberedPagination } from "@/components/numbered-pagination";
import { useReadingStats, ReadingStatsDashboard } from "@/components/reading-stats";
import { TagExplorer } from "@/components/tag-explorer";
import { CardSkeletonGrid, HeroSkeleton } from "@/components/skeleton-shimmer";
import { CommandPalette } from "@/components/command-palette";
import { ArchiveTimeline } from "@/components/archive-timeline";
import { TiltCard } from "@/components/tilt-card";
import { OnboardingTour } from "@/components/onboarding-tour";
import { Recommendations } from "@/components/recommendations";
import { AdZone } from "@/components/ad-zone";
import type { PostSummary, PostDetail, FilterData } from "@/lib/types";
import { format, formatDistanceToNow } from "date-fns";

export default function Home() {
  const [posts, setPosts] = useState<PostSummary[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState<FilterData | null>(null);
  const [query, setQuery] = useState("");
  const [debouncedQuery, setDebouncedQuery] = useState("");
  const [category, setCategory] = useState<string>("");
  const [author, setAuthor] = useState<string>("");
  const [tag, setTag] = useState<string>("");
  const [sort, setSort] = useState<string>("newest");
  const [offset, setOffset] = useState(0);
  const [activePost, setActivePost] = useState<PostDetail | null>(null);
  const [loadingPost, setLoadingPost] = useState(false);
  const [securityOpen, setSecurityOpen] = useState(false);
  const [reportOpen, setReportOpen] = useState(false);
  const [mobileNav, setMobileNav] = useState(false);
  const [authorLogin, setAuthorLogin] = useState<string | null>(null);
  const [bookmarksOpen, setBookmarksOpen] = useState(false);
  const [statsOpen, setStatsOpen] = useState(false);
  const [tagExplorerOpen, setTagExplorerOpen] = useState(false);
  const [commandOpen, setCommandOpen] = useState(false);
  const [archiveOpen, setArchiveOpen] = useState(false);
  const searchInputRef = useRef<HTMLInputElement>(null);
  const { history, addEntry, removeEntry, clearHistory } = useReadingHistory();
  const { bookmarks, isBookmarked, toggleBookmark, removeBookmark, clearBookmarks } = useBookmarks();
  const { stats, recordRead, resetStats } = useReadingStats();

  const LIMIT = 12;

  // debounce search
  useEffect(() => {
    const t = setTimeout(() => setDebouncedQuery(query), 300);
    return () => clearTimeout(t);
  }, [query]);

  // reset offset when filters change
  useEffect(() => {
    setOffset(0);
  }, [debouncedQuery, category, author, tag, sort]);

  // load filters once
  useEffect(() => {
    fetch("/api/filters")
      .then((r) => r.json())
      .then((d) => setFilters(d))
      .catch(() => setFilters({ categories: [], authors: [], tags: [] }));
  }, []);

  // load posts
  useEffect(() => {
    setLoading(true);
    const params = new URLSearchParams({
      limit: String(LIMIT),
      offset: String(offset),
      sort,
    });
    if (debouncedQuery) params.set("q", debouncedQuery);
    if (category) params.set("category", category);
    if (author) params.set("author", author);
    if (tag) params.set("tag", tag);
    fetch(`/api/posts?${params.toString()}`)
      .then((r) => r.json())
      .then((d) => {
        setPosts(d.posts ?? []);
        setTotal(d.total ?? 0);
      })
      .catch(() => {
        setPosts([]);
        setTotal(0);
      })
      .finally(() => setLoading(false));
  }, [debouncedQuery, category, author, tag, sort, offset]);

  // featured = first 3 of newest when no filter
  const featured = useMemo(() => {
    if (query || category || author || tag || sort !== "newest") return [];
    return posts.filter((p) => p.featured).slice(0, 3).length > 0
      ? posts.filter((p) => p.featured).slice(0, 3)
      : posts.slice(0, 3);
  }, [posts, query, category, author, tag, sort]);

  const gridPosts = useMemo(() => {
    if (query || category || author || tag || sort !== "newest") return posts;
    // drop featured from grid
    const featuredSlugs = new Set(featured.map((p) => p.slug));
    return posts.filter((p) => !featuredSlugs.has(p.slug));
  }, [posts, featured, query, category, author, tag, sort]);

  const openPost = useCallback(async (slug: string) => {
    setLoadingPost(true);
    try {
      const r = await fetch(`/api/posts/${slug}`);
      if (!r.ok) throw new Error("not found");
      const d = await r.json();
      setActivePost(d);
      addEntry(d);
      recordRead(d);
    } catch {
      // ignore
    } finally {
      setLoadingPost(false);
    }
  }, [addEntry, recordRead]);

  // deep-link via ?article=slug
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const slug = params.get("article");
    if (slug) openPost(slug);
  }, [openPost]);

  const clearFilters = () => {
    setQuery("");
    setCategory("");
    setAuthor("");
    setTag("");
    setSort("newest");
  };

  const hasFilters = Boolean(query || category || author || tag);

  // Keyboard navigation
  const focusSearch = useCallback(() => {
    searchInputRef.current?.focus();
    searchInputRef.current?.select();
  }, []);

  const scrollCard = useCallback((dir: 1 | -1) => {
    const cards = Array.from(
      document.querySelectorAll<HTMLElement>("[data-article-card]")
    );
    if (cards.length === 0) {
      window.scrollBy({ top: dir * 400, behavior: "smooth" });
      return;
    }
    // find the card nearest to viewport center
    const mid = window.innerHeight / 2;
    let bestIdx = 0;
    let bestDist = Infinity;
    cards.forEach((c, i) => {
      const r = c.getBoundingClientRect();
      const center = r.top + r.height / 2;
      const dist = Math.abs(center - mid);
      if (dist < bestDist) {
        bestDist = dist;
        bestIdx = i;
      }
    });
    const nextIdx = Math.max(0, Math.min(cards.length - 1, bestIdx + dir));
    cards[nextIdx]?.scrollIntoView({ behavior: "smooth", block: "center" });
    cards[nextIdx]?.focus();
  }, []);

  const { helpOpen, setHelpOpen } = useKeyboardNav({
    onFocusSearch: focusSearch,
    onOpenSecurity: () => setSecurityOpen(true),
    onOpenBookmarks: () => setBookmarksOpen(true),
    onOpenStats: () => setStatsOpen(true),
    onOpenTags: () => setTagExplorerOpen(true),
    onOpenArchive: () => setArchiveOpen(true),
    scrollCard,
  });

  // Cmd+K / Ctrl+K to open command palette
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        setCommandOpen((v) => !v);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  return (
    <div className="flex min-h-screen flex-col bg-background">
      {/* ===== Top security ticker ===== */}
      <SecurityTicker onOpenSecurity={() => setSecurityOpen(true)} />

      {/* ===== Header ===== */}
      <header className="sticky top-0 z-40 border-b bg-background/85 backdrop-blur-md">
        <div className="mx-auto flex h-16 max-w-7xl items-center gap-3 px-4 sm:px-6 lg:px-8">
          {/* Logo */}
          <button
            onClick={() => {
              clearFilters();
              setOffset(0);
              window.scrollTo({ top: 0, behavior: "smooth" });
            }}
            className="flex shrink-0 items-center gap-2"
          >
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary font-serif text-lg font-bold text-primary-foreground shadow-sm">
              X
            </div>
            <div className="hidden text-left leading-none sm:block">
              <div className="font-serif text-lg font-bold tracking-tight">
                SportX <span className="text-primary">India</span>
              </div>
              <div className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
                All About Sport
              </div>
            </div>
          </button>

          {/* Desktop nav */}
          <nav className="ml-4 hidden items-center gap-1 md:flex">
            <Button
              variant={category === "" ? "secondary" : "ghost"}
              size="sm"
              onClick={() => setCategory("")}
              className="font-medium"
            >
              Home
            </Button>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="font-medium">
                  Categories
                  <ChevronDown className="ml-1 h-3.5 w-3.5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start" className="w-56">
                <DropdownMenuLabel>Browse by category</DropdownMenuLabel>
                <DropdownMenuSeparator />
                {filters?.categories.map((c) => (
                  <DropdownMenuItem
                    key={c.slug}
                    onClick={() => setCategory(c.slug)}
                    className="flex items-center justify-between"
                  >
                    <span>{c.name}</span>
                    <Badge variant="outline" className="text-[10px]">
                      {c.count}
                    </Badge>
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="font-medium">
                  Authors
                  <ChevronDown className="ml-1 h-3.5 w-3.5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start" className="w-64">
                <DropdownMenuLabel>Writers</DropdownMenuLabel>
                <DropdownMenuSeparator />
                {filters?.authors.map((a) => (
                  <DropdownMenuItem
                    key={a.login}
                    onClick={() => setAuthor(a.login)}
                    className="flex items-center justify-between"
                  >
                    <div className="flex items-center gap-2">
                      <span className="flex h-6 w-6 items-center justify-center rounded-full bg-primary/10 text-[11px] font-semibold text-primary">
                        {a.displayName.slice(0, 1)}
                      </span>
                      <span>{a.displayName}</span>
                    </div>
                    <Badge variant="outline" className="text-[10px]">
                      {a.count}
                    </Badge>
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>

            <Button
              variant="ghost"
              size="sm"
              onClick={() => setArchiveOpen(true)}
              className="font-medium"
            >
              Archive
            </Button>
          </nav>

          {/* Command palette trigger */}
          <button
            onClick={() => setCommandOpen(true)}
            className="group ml-auto flex w-full max-w-xs items-center gap-2 rounded-lg border bg-muted/40 px-3 py-1.5 text-sm text-muted-foreground transition-all hover:border-primary/40 hover:bg-muted/60"
          >
            <Search className="h-4 w-4 shrink-0" />
            <span className="flex-1 truncate text-left">
              Search articles, athletes, topics…
            </span>
            <kbd className="hidden shrink-0 rounded border bg-card px-1.5 py-0.5 font-mono text-[10px] font-semibold sm:block">
              ⌘K
            </kbd>
          </button>

          {/* Hidden search input for keyboard nav focus (/) */}
          <input
            ref={searchInputRef}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="sr-only"
            aria-label="Search"
            tabIndex={-1}
          />

          {/* Security button */}
          <Button
            variant="outline"
            size="sm"
            onClick={() => setSecurityOpen(true)}
            className="shrink-0 gap-1.5 border-primary/30 text-primary hover:bg-primary/10 hover:text-primary"
          >
            <ShieldCheck className="h-4 w-4" />
            <span className="hidden lg:inline">Security Center</span>
            <span className="lg:hidden">Security</span>
          </Button>

          {/* Bookmarks button */}
          <Button
            variant="ghost"
            size="icon"
            className="relative h-9 w-9 shrink-0"
            onClick={() => setBookmarksOpen(true)}
            aria-label="Bookmarks"
            title="Bookmarks (g b)"
          >
            <Bookmark className="h-4 w-4" />
            {bookmarks.length > 0 && (
              <span className="absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-primary px-1 text-[10px] font-bold text-primary-foreground">
                {bookmarks.length}
              </span>
            )}
          </Button>

          {/* Reading stats button */}
          <Button
            variant="ghost"
            size="icon"
            className="relative h-9 w-9 shrink-0"
            onClick={() => setStatsOpen(true)}
            aria-label="Reading stats"
            title="Your reading stats (g r)"
          >
            <BarChart3 className="h-4 w-4" />
            {stats.sessions.length > 0 && (
              <span className="absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-emerald-600 px-1 text-[10px] font-bold text-white">
                {stats.sessions.length}
              </span>
            )}
          </Button>

          {/* Theme toggle */}
          <ThemeToggle />

          {/* Keyboard shortcuts hint button */}
          <Button
            variant="ghost"
            size="icon"
            className="hidden h-9 w-9 shrink-0 sm:inline-flex"
            onClick={() => setHelpOpen(true)}
            aria-label="Keyboard shortcuts"
            title="Keyboard shortcuts (?)"
          >
            <kbd className="rounded border bg-muted px-1.5 py-0.5 font-mono text-[10px] font-semibold">?</kbd>
          </Button>

          {/* Mobile nav button */}
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden"
            onClick={() => setMobileNav((v) => !v)}
            aria-label="Toggle menu"
          >
            {mobileNav ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </Button>
        </div>

        {/* Mobile nav panel */}
        <AnimatePresence>
          {mobileNav && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden border-t md:hidden"
            >
              <div className="space-y-3 p-4">
                <div className="relative sm:hidden">
                  <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    placeholder="Search articles…"
                    className="pl-9"
                  />
                </div>
                <div className="flex flex-wrap gap-1.5">
                  <Button
                    size="sm"
                    variant={category === "" ? "secondary" : "outline"}
                    onClick={() => {
                      setCategory("");
                      setMobileNav(false);
                    }}
                  >
                    All
                  </Button>
                  {filters?.categories.map((c) => (
                    <Button
                      key={c.slug}
                      size="sm"
                      variant={category === c.slug ? "secondary" : "outline"}
                      onClick={() => {
                        setCategory(c.slug);
                        setMobileNav(false);
                      }}
                    >
                      {c.name}
                    </Button>
                  ))}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      {/* ===== Hero (only on unfiltered home) ===== */}
      {!hasFilters && sort === "newest" && offset === 0 && (
        <Hero featured={featured} loading={loading} onOpen={openPost} />
      )}

      {/* ===== Main content ===== */}
      <main className="mx-auto w-full max-w-7xl flex-1 px-4 py-10 sm:px-6 lg:px-8">
        {/* Reading history (only on unfiltered home) */}
        {!hasFilters && sort === "newest" && offset === 0 && (
          <ReadingHistory
            history={history}
            onOpen={openPost}
            onRemove={removeEntry}
            onClear={clearHistory}
          />
        )}

        {/* Personalized recommendations (only on unfiltered home) */}
        {!hasFilters && sort === "newest" && offset === 0 && (
          <Recommendations
            history={history}
            onOpen={openPost}
            excludeSlugs={posts.map((p) => p.slug)}
          />
        )}

        {/* Filter bar */}
        <div className="mb-6 flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2">
            <Filter className="h-4 w-4 text-muted-foreground" />
            <h2 className="font-serif text-xl font-bold tracking-tight">
              {hasFilters ? "Search results" : "Latest stories"}
            </h2>
            <Badge variant="secondary" className="tabular-nums">
              {total}
            </Badge>
          </div>

          <div className="ml-auto flex flex-wrap items-center gap-2">
            {/* Active category pill */}
            {category && (
              <Badge variant="default" className="gap-1">
                {filters?.categories.find((c) => c.slug === category)?.name ?? category}
                <button onClick={() => setCategory("")}>
                  <X className="h-3 w-3" />
                </button>
              </Badge>
            )}
            {author && (
              <Badge variant="default" className="gap-1">
                {filters?.authors.find((a) => a.login === author)?.displayName ?? author}
                <button onClick={() => setAuthor("")}>
                  <X className="h-3 w-3" />
                </button>
              </Badge>
            )}
            {tag && (
              <Badge variant="default" className="gap-1">
                #{filters?.tags.find((t) => t.slug === tag)?.name ?? tag}
                <button onClick={() => setTag("")}>
                  <X className="h-3 w-3" />
                </button>
              </Badge>
            )}
            {hasFilters && (
              <Button variant="ghost" size="sm" onClick={clearFilters} className="h-7 text-xs">
                Clear all
              </Button>
            )}
            <Select value={sort} onValueChange={setSort}>
              <SelectTrigger className="h-9 w-[150px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="newest">Newest first</SelectItem>
                <SelectItem value="oldest">Oldest first</SelectItem>
                <SelectItem value="reads">Most read</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Tag cloud */}
        {!hasFilters && filters && filters.tags.length > 0 && (
          <div className="mb-8 rounded-xl border bg-muted/30 p-4">
            <div className="mb-2.5 flex items-center gap-2">
              <TrendingUp className="h-3.5 w-3.5 text-primary" />
              <span className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                Trending tags
              </span>
              <Button
                variant="ghost"
                size="sm"
                className="ml-auto h-6 gap-1 px-2 text-[11px] text-muted-foreground hover:text-primary"
                onClick={() => setTagExplorerOpen(true)}
              >
                <Hash className="h-3 w-3" />
                Explore all
              </Button>
            </div>
            <div className="flex flex-wrap gap-2">
              {filters.tags.slice(0, 18).map((t) => (
                <button
                  key={t.slug}
                  onClick={() => setTag(t.slug)}
                  className="group inline-flex items-center gap-1 rounded-full border border-border bg-card px-3 py-1 text-xs font-medium text-muted-foreground transition-all hover:border-primary/50 hover:bg-primary/5 hover:text-primary hover:shadow-sm"
                >
                  <span className="text-primary/60 transition-colors group-hover:text-primary">#</span>
                  {t.name}
                  <span className="rounded-full bg-muted px-1.5 py-0.5 text-[9px] tabular-nums text-muted-foreground/70 transition-colors group-hover:bg-primary/10 group-hover:text-primary">
                    {t.count}
                  </span>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Grid */}
        {loading ? (
          <CardSkeletonGrid count={6} />
        ) : gridPosts.length === 0 ? (
          <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed py-20 text-center">
            <div className="relative mb-4">
              <div className="flex h-20 w-20 items-center justify-center rounded-full bg-primary/10">
                <Newspaper className="h-9 w-9 text-primary/60" />
              </div>
              {/* Decorative dots */}
              <div className="absolute -right-1 -top-1 h-3 w-3 rounded-full bg-amber-400 animate-pulse-subtle" />
              <div className="absolute -bottom-1 left-2 h-2 w-2 rounded-full bg-emerald-400 animate-pulse-subtle" style={{ animationDelay: "0.5s" }} />
            </div>
            <h3 className="font-serif text-xl font-bold">
              No articles found here
            </h3>
            <p className="mt-2 max-w-sm text-sm text-muted-foreground">
              We&apos;re probably writing one right now. Try a different search
              term or clear your filters to see everything.
            </p>
            {hasFilters ? (
              <Button variant="default" className="mt-5 gap-1.5" onClick={clearFilters}>
                Clear filters
                <ArrowRight className="h-4 w-4" />
              </Button>
            ) : (
              <Button
                variant="outline"
                className="mt-5 gap-1.5"
                onClick={() => setCommandOpen(true)}
              >
                <Search className="h-4 w-4" />
                Open search
                <kbd className="ml-1 rounded border bg-muted px-1 font-mono text-[10px]">⌘K</kbd>
              </Button>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
            <AnimatePresence mode="popLayout">
              {gridPosts.map((p, i) => (
                <motion.div
                  key={p.slug}
                  layout
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.96 }}
                  transition={{ duration: 0.25, delay: Math.min(i * 0.04, 0.3) }}
                >
                  <ArticleCard post={p} onOpen={openPost} onOpenAuthor={setAuthorLogin} />
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        )}

        {/* Pagination */}
        {total > LIMIT && (
          <NumberedPagination
            total={total}
            limit={LIMIT}
            offset={offset}
            onPageChange={(newOffset) => {
              setOffset(newOffset);
              window.scrollTo({ top: 400, behavior: "smooth" });
            }}
          />
        )}
      </main>

      {/* ===== In-feed ad zone ===== */}
      <div className="mx-auto max-w-7xl px-4 pb-6 sm:px-6 lg:px-8">
        <AdZone slot="header" className="min-h-[90px] rounded-xl" />
      </div>

      {/* ===== Newsletter CTA band ===== */}
      <section
        id="newsletter-section"
        className="border-t bg-gradient-to-r from-primary/10 via-background to-emerald-500/10"
      >
        <div className="mx-auto grid max-w-7xl grid-cols-1 items-center gap-6 px-4 py-10 sm:px-6 lg:grid-cols-2 lg:px-8">
          <div>
            <div className="mb-2 flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-primary" />
              <span className="text-xs font-semibold uppercase tracking-[0.18em] text-primary">
                The SportX India newsletter
              </span>
            </div>
            <h2 className="font-serif text-2xl font-bold tracking-tight sm:text-3xl">
              Stories worth your inbox.
            </h2>
            <p className="mt-2 max-w-md text-sm text-muted-foreground">
              Memoirs, editorials, and the science behind the game — curated
              weekly. Join the readers who never miss a SportX India story.
            </p>
          </div>
          <NewsletterSignup variant="inline" />
        </div>
      </section>

      {/* ===== Footer ad zone ===== */}
      <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
        <AdZone slot="footer" className="min-h-[90px] rounded-xl" />
      </div>

      {/* ===== Footer ===== */}
      <Footer
        onOpenSecurity={() => setSecurityOpen(true)}
        onOpenReport={() => setReportOpen(true)}
        onBrowseCategory={(c) => setCategory(c)}
        categories={filters?.categories ?? []}
      />

      {/* ===== Article reader modal ===== */}
      <ArticleReader
        post={activePost}
        onClose={() => setActivePost(null)}
        onOpenRelated={(slug) => openPost(slug)}
        onOpenAuthor={(login) => setAuthorLogin(login)}
        isBookmarked={activePost ? isBookmarked(activePost.slug) : false}
        onToggleBookmark={() => {
          if (!activePost) return;
          toggleBookmark({
            slug: activePost.slug,
            title: activePost.title,
            excerpt: activePost.excerpt,
            coverSeed: activePost.coverSeed,
            author: activePost.author,
            publishedAt: activePost.publishedAt,
            readMinutes: activePost.readMinutes,
          });
        }}
      />

      {/* Loading overlay for opening a post */}
      <AnimatePresence>
        {loadingPost && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[60] flex items-center justify-center bg-black/40 backdrop-blur-sm"
          >
            <div className="flex items-center gap-3 rounded-xl bg-card px-6 py-4 shadow-2xl">
              <Loader2 className="h-5 w-5 animate-spin text-primary" />
              <span className="text-sm font-medium">Loading article…</span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ===== Security center sheet ===== */}
      <SecurityCenter open={securityOpen} onOpenChange={setSecurityOpen} />

      {/* ===== Report dialog (footer entry) ===== */}
      <ReportContentDialog
        open={reportOpen}
        onOpenChange={setReportOpen}
        postId={null}
        postTitle={null}
      />

      {/* ===== Keyboard shortcuts help ===== */}
      <KeyboardHelpOverlay open={helpOpen} onClose={() => setHelpOpen(false)} />

      {/* ===== Author profile modal ===== */}
      <AuthorProfileModal
        authorLogin={authorLogin}
        onClose={() => setAuthorLogin(null)}
        onOpenArticle={(slug) => {
          setAuthorLogin(null);
          openPost(slug);
        }}
      />

      {/* ===== Back to top ===== */}
      <BackToTop />

      {/* ===== Bookmarks drawer ===== */}
      <BookmarksDrawer
        open={bookmarksOpen}
        onOpenChange={setBookmarksOpen}
        bookmarks={bookmarks}
        onOpenArticle={(slug) => {
          setBookmarksOpen(false);
          openPost(slug);
        }}
        onRemove={removeBookmark}
        onClear={clearBookmarks}
      />

      {/* ===== Reading stats dashboard ===== */}
      <ReadingStatsDashboard
        open={statsOpen}
        onOpenChange={setStatsOpen}
        stats={stats}
        onReset={resetStats}
        onOpenArticle={(slug) => {
          setStatsOpen(false);
          openPost(slug);
        }}
      />

      {/* ===== Tag explorer ===== */}
      <TagExplorer
        open={tagExplorerOpen}
        onOpenChange={setTagExplorerOpen}
        filters={filters}
        onSelectTag={(slug) => {
          setTag(slug);
        }}
      />

      {/* ===== Command palette (Cmd+K) ===== */}
      <CommandPalette
        open={commandOpen}
        onOpenChange={setCommandOpen}
        filters={filters}
        onOpenArticle={(slug) => openPost(slug)}
        onOpenSecurity={() => setSecurityOpen(true)}
        onOpenBookmarks={() => setBookmarksOpen(true)}
        onOpenStats={() => setStatsOpen(true)}
        onOpenTags={() => setTagExplorerOpen(true)}
        onBrowseCategory={(slug) => setCategory(slug)}
        onBrowseAuthor={(login) => setAuthorLogin(login)}
        onBrowseTag={(slug) => setTag(slug)}
        onScrollNewsletter={() => {
          document
            .getElementById("newsletter-section")
            ?.scrollIntoView({ behavior: "smooth", block: "center" });
        }}
      />

      {/* ===== Archive timeline ===== */}
      <ArchiveTimeline
        open={archiveOpen}
        onOpenChange={setArchiveOpen}
        onOpenArticle={(slug) => openPost(slug)}
      />

      {/* ===== Onboarding tour (first visit) ===== */}
      <OnboardingTour />
    </div>
  );
}

// ===== Security ticker =====
function SecurityTicker({ onOpenSecurity }: { onOpenSecurity: () => void }) {
  const items = [
    "Content-integrity protected · SHA-256 fingerprints on every article",
    "Auto-moderation active · 1 injected spam post quarantined",
    "Verified original SportX India content · DMCA enforced",
    "Report stolen content · takedown within 48h",
    "Author-verified bylines · no anonymous publishing",
  ];
  const doubled = [...items, ...items];
  return (
    <div className="flex h-8 items-center gap-3 overflow-hidden border-b bg-foreground text-background">
      <button
        onClick={onOpenSecurity}
        className="flex h-full shrink-0 items-center gap-1.5 bg-primary px-3 text-xs font-semibold text-primary-foreground hover:bg-primary/90"
      >
        <ShieldCheck className="h-3.5 w-3.5" />
        <span className="hidden sm:inline">SECURED</span>
        <span className="sm:hidden">●</span>
      </button>
      <div className="relative flex-1 overflow-hidden">
        <div className="animate-ticker flex whitespace-nowrap text-xs">
          {doubled.map((t, i) => (
            <span key={i} className="mx-6 inline-flex items-center gap-2">
              <span className="text-primary-foreground/60">◆</span>
              {t}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}

// ===== Hero =====
function Hero({
  featured,
  loading,
  onOpen,
}: {
  featured: PostSummary[];
  loading: boolean;
  onOpen: (slug: string) => void;
}) {
  if (loading && featured.length === 0) {
    return (
      <section className="border-b bg-gradient-to-br from-primary/5 via-card to-background">
        <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
          <HeroSkeleton />
        </div>
      </section>
    );
  }
  if (featured.length === 0) return null;
  const [lead, ...rest] = featured;

  return (
    <section className="border-b bg-gradient-to-br from-primary/5 via-card to-background">
      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        {/* Section label */}
        <div className="mb-5 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="h-4 w-4 text-primary" />
            <span className="text-xs font-semibold uppercase tracking-[0.18em] text-primary">
              Editor&apos;s picks
            </span>
          </div>
          <span className="hidden text-xs text-muted-foreground sm:block">
            Hand-selected from the SportX India archive
          </span>
        </div>

        <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">
          {/* Lead */}
          <button
            onClick={() => onOpen(lead.slug)}
            className="group relative col-span-1 overflow-hidden rounded-2xl border bg-card text-left shadow-sm transition-all hover:shadow-xl hover:border-primary/30 lg:col-span-2 lg:row-span-2"
          >
            <div className="relative overflow-hidden">
              <div className="animate-ken-burns">
                <CoverArt
                  seed={lead.coverSeed}
                  title={lead.title}
                  className="h-64 w-full sm:h-80 lg:h-[26rem]"
                  size="lg"
                />
              </div>
              {/* Featured badge */}
              <div className="absolute left-4 top-4 flex items-center gap-1.5 rounded-full bg-primary px-3 py-1 text-[11px] font-bold uppercase tracking-wide text-primary-foreground shadow-lg">
                <Sparkles className="h-3 w-3" />
                Featured
              </div>
            </div>
            <div className="p-6">
              <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                {lead.categories.slice(0, 2).map((c) => (
                  <Badge key={c.slug} variant="secondary" className="font-medium">
                    {c.name}
                  </Badge>
                ))}
                <span className="flex items-center gap-1">
                  <Clock className="h-3 w-3" />
                  {format(new Date(lead.publishedAt), "d MMM yyyy")}
                </span>
                <span className="flex items-center gap-1">
                  <Eye className="h-3 w-3" />
                  {lead.views} views
                </span>
                <span className="flex items-center gap-1 text-primary">
                  <Fingerprint className="h-3 w-3" />
                  Verified
                </span>
              </div>
              <h2 className="editorial-headline mt-3 font-serif text-3xl font-bold leading-[1.1] transition-colors group-hover:text-primary sm:text-4xl lg:text-5xl">
                {lead.title}
              </h2>
              {lead.excerpt && (
                <p className="mt-2 line-clamp-2 text-sm text-muted-foreground sm:text-base">
                  {lead.excerpt}
                </p>
              )}
              <div className="mt-4 flex items-center justify-between">
                <span className="flex items-center gap-2 text-sm">
                  <span className="flex h-7 w-7 items-center justify-center rounded-full bg-primary/10 text-xs font-semibold text-primary">
                    {lead.author.displayName.slice(0, 1)}
                  </span>
                  <span className="font-medium">{lead.author.displayName}</span>
                  <span className="text-muted-foreground">· {lead.readMinutes} min</span>
                </span>
                <span className="flex items-center gap-1 text-sm font-medium text-primary transition-all group-hover:gap-2">
                  Read story <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
                </span>
              </div>
            </div>
          </button>

          {/* Side cards */}
          {rest.map((p) => (
            <button
              key={p.slug}
              onClick={() => onOpen(p.slug)}
              className="group flex overflow-hidden rounded-2xl border bg-card text-left shadow-sm transition-all hover:shadow-md"
            >
              <CoverArt
                seed={p.coverSeed}
                title={p.title}
                className="h-28 w-28 shrink-0 sm:h-32 sm:w-32"
                size="sm"
              />
              <div className="flex min-w-0 flex-1 flex-col p-3 sm:p-4">
                <div className="flex flex-wrap items-center gap-1.5 text-[11px] text-muted-foreground">
                  {p.categories[0] && (
                    <Badge variant="outline" className="text-[10px]">
                      {p.categories[0].name}
                    </Badge>
                  )}
                  <span>{format(new Date(p.publishedAt), "d MMM")}</span>
                </div>
                <h3 className="mt-1.5 line-clamp-3 font-serif text-sm font-bold leading-snug transition-colors group-hover:text-primary sm:text-base">
                  {p.title}
                </h3>
                <div className="mt-auto flex items-center gap-1 pt-2 text-[11px] text-muted-foreground">
                  <PenTool className="h-3 w-3" />
                  {p.author.displayName}
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
}

// ===== Article card =====
function ArticleCard({
  post,
  onOpen,
  onOpenAuthor,
}: {
  post: PostSummary;
  onOpen: (slug: string) => void;
  onOpenAuthor: (login: string) => void;
}) {
  return (
    <div
      data-article-card
      tabIndex={0}
      role="button"
      onClick={() => onOpen(post.slug)}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          onOpen(post.slug);
        }
      }}
      className="group card-depth flex h-full w-full cursor-pointer flex-col overflow-hidden rounded-xl border bg-card text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 hover:-translate-y-1 hover:border-primary/30"
    >
      <div className="relative overflow-hidden">
        <div className="transition-transform duration-500 group-hover:scale-110">
          <CoverArt
            seed={post.coverSeed}
            title={post.title}
            className="h-44 w-full"
            size="md"
          />
        </div>
        {/* Verified badge */}
        <div className="animate-pulse-glow absolute right-2 top-2 flex items-center gap-1 rounded-full bg-emerald-500/90 px-2 py-0.5 text-[10px] font-semibold text-white shadow-sm backdrop-blur-sm transition-transform group-hover:scale-105">
          <ShieldCheck className="h-3 w-3" />
          Verified
        </div>
        {/* Gradient overlay on hover */}
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/0 to-black/0 transition-colors duration-300 group-hover:from-black/10 group-hover:to-transparent" />
      </div>
      <div className="flex flex-1 flex-col p-4">
        <div className="flex flex-wrap items-center gap-1.5 text-[11px] text-muted-foreground">
          {post.categories.slice(0, 1).map((c) => (
            <Badge key={c.slug} variant="secondary" className="text-[10px] font-medium">
              {c.name}
            </Badge>
          ))}
          <span className="flex items-center gap-0.5">
            <Clock className="h-3 w-3" />
            {format(new Date(post.publishedAt), "d MMM yyyy")}
          </span>
        </div>
        <h3 className="mt-2 line-clamp-2 font-serif text-[1.05rem] font-bold leading-snug transition-colors group-hover:text-primary">
          {post.title}
        </h3>
        {post.excerpt && (
          <p className="mt-1.5 line-clamp-2 text-xs leading-relaxed text-muted-foreground/90">
            {post.excerpt}
          </p>
        )}
        <div className="mt-auto flex items-center justify-between pt-3 text-[11px] text-muted-foreground">
          <button
            onClick={(e) => {
              e.stopPropagation();
              onOpenAuthor(post.author.login);
            }}
            className="flex items-center gap-1.5 rounded-md p-0.5 pr-1.5 transition-colors hover:bg-muted"
          >
            <span className="flex h-5 w-5 items-center justify-center rounded-full bg-primary/10 text-[10px] font-semibold text-primary">
              {post.author.displayName.slice(0, 1)}
            </span>
            <span className="font-medium text-foreground">
              {post.author.displayName}
            </span>
          </button>
          <span className="flex items-center gap-2">
            <span className="flex items-center gap-0.5">
              <Eye className="h-3 w-3" />
              {post.views}
            </span>
            <span>· {post.readMinutes}m</span>
          </span>
        </div>
      </div>
    </div>
  );
}

// ===== Footer =====
function Footer({
  onOpenSecurity,
  onOpenReport,
  onBrowseCategory,
  categories,
}: {
  onOpenSecurity: () => void;
  onOpenReport: () => void;
  onBrowseCategory: (slug: string) => void;
  categories: { slug: string; name: string; count: number }[];
}) {
  return (
    <footer className="mt-auto border-t bg-foreground text-background">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 gap-8 md:grid-cols-4">
          {/* Brand */}
          <div className="col-span-2 md:col-span-1">
            <div className="flex items-center gap-2">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary font-serif text-lg font-bold text-primary-foreground">
                X
              </div>
              <div className="leading-none">
                <div className="font-serif text-lg font-bold">
                  SportX <span className="text-primary">India</span>
                </div>
                <div className="text-[10px] uppercase tracking-[0.18em] text-background/60">
                  All About Sport
                </div>
              </div>
            </div>
            <p className="mt-4 text-sm text-background/70">
              Indian sports journalism — memoirs, editorials, buying guides,
              and the science behind the game. Every article is a verified
              original.
            </p>
            <div className="mt-4 flex items-center gap-2 text-xs text-background/60">
              <Lock className="h-3.5 w-3.5 text-emerald-400" />
              Content-integrity protected
            </div>
            {/* Social links */}
            <div className="mt-4 flex items-center gap-2">
              <SocialLink icon={Twitter} label="Twitter" />
              <SocialLink icon={Github} label="GitHub" />
              <SocialLink icon={Rss} label="RSS" />
              <SocialLink icon={Mail} label="Email" />
            </div>
          </div>

          {/* Categories */}
          <div>
            <h4 className="mb-3 text-xs font-semibold uppercase tracking-wider text-background/60">
              Categories
            </h4>
            <ul className="space-y-2 text-sm">
              {categories.slice(0, 6).map((c) => (
                <li key={c.slug}>
                  <button
                    onClick={() => onBrowseCategory(c.slug)}
                    className="text-background/80 transition-colors hover:text-primary"
                  >
                    {c.name}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Security */}
          <div>
            <h4 className="mb-3 text-xs font-semibold uppercase tracking-wider text-background/60">
              Content protection
            </h4>
            <ul className="space-y-2 text-sm">
              <li>
                <button
                  onClick={onOpenSecurity}
                  className="flex items-center gap-1.5 text-background/80 transition-colors hover:text-primary"
                >
                  <ShieldCheck className="h-3.5 w-3.5" />
                  Security Center
                </button>
              </li>
              <li>
                <button
                  onClick={onOpenReport}
                  className="flex items-center gap-1.5 text-background/80 transition-colors hover:text-primary"
                >
                  <Flag className="h-3.5 w-3.5" />
                  Report stolen content
                </button>
              </li>
              <li className="flex items-center gap-1.5 text-background/80">
                <Fingerprint className="h-3.5 w-3.5" />
                SHA-256 fingerprints
              </li>
              <li className="flex items-center gap-1.5 text-background/80">
                <CheckCircle2 className="h-3.5 w-3.5" />
                DMCA policy
              </li>
            </ul>
          </div>

          {/* About */}
          <div>
            <h4 className="mb-3 text-xs font-semibold uppercase tracking-wider text-background/60">
              About
            </h4>
            <ul className="space-y-2 text-sm text-background/80">
              <li>Founded by Meghan Belsare</li>
              <li>Independent sports writing</li>
              <li>Reader-supported</li>
              <li>Verified author bylines</li>
            </ul>
          </div>
        </div>

        {/* Notice strip */}
        <div className="mt-10 flex flex-col gap-3 rounded-xl bg-background/5 p-4 text-xs text-background/70 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-start gap-2">
            <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-amber-400" />
            <p>
              <span className="font-semibold text-background">Anti-piracy notice:</span>{" "}
              All SportX India articles are cryptographically fingerprinted.
              Unauthorized reproduction will be pursued under the DMCA. If you
              spot our content on another site,{" "}
              <button
                onClick={onOpenReport}
                className="font-medium text-primary underline underline-offset-2"
              >
                report it here
              </button>
              .
            </p>
          </div>
          <button
            onClick={onOpenSecurity}
            className="shrink-0 rounded-lg border border-background/20 px-3 py-1.5 font-medium text-background/90 transition-colors hover:bg-background/10"
          >
            Open Security Center →
          </button>
        </div>

        <div className="mt-6 flex flex-col items-center justify-between gap-3 border-t border-background/10 pt-6 text-xs text-background/50 sm:flex-row">
          <p>
            © {new Date().getFullYear()} SportX India. All content is the
            intellectual property of its authors.
          </p>
          <p className="flex items-center gap-1.5">
            <TrendingUp className="h-3 w-3" />
            Built on a verified-content platform
          </p>
        </div>
      </div>
    </footer>
  );
}

// ===== Social link =====
function SocialLink({
  icon: Icon,
  label,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
}) {
  return (
    <a
      href="#"
      aria-label={label}
      title={label}
      className="flex h-8 w-8 items-center justify-center rounded-lg border border-background/20 text-background/70 transition-all hover:border-primary hover:bg-primary hover:text-primary-foreground hover:scale-105"
    >
      <Icon className="h-3.5 w-3.5" />
    </a>
  );
}
