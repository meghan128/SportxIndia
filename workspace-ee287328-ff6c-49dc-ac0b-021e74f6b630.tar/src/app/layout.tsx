import type { Metadata } from "next";
import { Geist, Geist_Mono, Fraunces, Inter } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { ThemeProvider } from "@/components/theme-provider";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

// Editorial serif for headlines — Fraunces is a high-contrast display serif
// that evokes print journalism (like The Athletic / NYT).
const fraunces = Fraunces({
  variable: "--font-serif",
  subsets: ["latin"],
  weight: ["400", "500", "600", "700", "800", "900"],
  style: ["normal", "italic"],
  display: "swap",
});

// Inter as the UI/body sans — clean and neutral
const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "SportX India — All About Sport",
  description:
    "Indian sports journalism — memoirs, editorials, buying guides, and the science behind the game. Protected by content-integrity verification.",
  keywords: [
    "SportX India",
    "sports journalism India",
    "sports memoirs",
    "IPL",
    "sports science",
    "sports technology",
  ],
  authors: [{ name: "Meghan Belsare", url: "https://sportxin.wordpress.com" }],
  icons: {
    icon: "/favicon.svg",
  },
  openGraph: {
    title: "SportX India — All About Sport",
    description:
      "Indian sports journalism with content-integrity protection. Memoirs, editorials, buying guides, and the science behind the game.",
    siteName: "SportX India",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "SportX India — All About Sport",
    description:
      "Indian sports journalism with content-integrity protection.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} ${fraunces.variable} ${inter.variable} antialiased bg-background text-foreground`}
      >
        <ThemeProvider
          attribute="class"
          defaultTheme="light"
          enableSystem
          disableTransitionOnChange
        >
          {children}
          <Toaster />
        </ThemeProvider>
      </body>
    </html>
  );
}
