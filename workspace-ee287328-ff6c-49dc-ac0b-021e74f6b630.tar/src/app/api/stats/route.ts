import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

// GET /api/stats — dashboard summary for the security center
export async function GET() {
  const [
    totalPosts,
    publishedPosts,
    quarantinedPosts,
    openIncidents,
    openReports,
    totalReports,
    totalViews,
    recentAudit,
  ] = await Promise.all([
    db.post.count(),
    db.post.count({ where: { status: "published" } }),
    db.post.count({ where: { status: "quarantined" } }),
    db.securityIncident.count({ where: { status: "open" } }),
    db.contentReport.count({ where: { status: "open" } }),
    db.contentReport.count(),
    db.post.aggregate({ _sum: { views: true } }),
    db.auditLog.count({
      where: { createdAt: { gte: new Date(Date.now() - 24 * 60 * 60 * 1000) } },
    }),
  ]);

  const verifiedFingerprints = publishedPosts; // every published post has a SHA-256 hash

  return NextResponse.json({
    posts: { total: totalPosts, published: publishedPosts, quarantined: quarantinedPosts },
    incidents: { open: openIncidents },
    reports: { open: openReports, total: totalReports },
    integrity: {
      verifiedFingerprints,
      algorithm: "SHA-256",
      coverage: totalPosts === 0 ? 0 : Math.round((verifiedFingerprints / totalPosts) * 100),
    },
    engagement: { totalViews: totalViews._sum.views ?? 0 },
    activity: { auditEntries24h: recentAudit },
  });
}
