import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

// GET /api/authors/[login] — author profile + their published posts
export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ login: string }> }
) {
  const { login } = await params;
  const author = await db.author.findUnique({
    where: { login },
    include: {
      posts: {
        where: { status: "published" },
        orderBy: { publishedAt: "desc" },
        take: 50,
        include: { categories: true, tags: { take: 4 } },
      },
    },
  });
  if (!author) {
    return NextResponse.json({ error: "Author not found" }, { status: 404 });
  }

  const totalViews = author.posts.reduce((sum, p) => sum + p.views, 0);

  return NextResponse.json({
    login: author.login,
    displayName: author.displayName,
    firstName: author.firstName,
    lastName: author.lastName,
    email: author.email,
    bio: author.bio,
    role: author.role,
    createdAt: author.createdAt,
    stats: {
      postCount: author.posts.length,
      totalViews,
      categories: [...new Set(author.posts.flatMap((p) => p.categories.map((c) => c.name)))],
    },
    posts: author.posts.map((p) => ({
      id: p.id,
      slug: p.slug,
      title: p.title,
      excerpt: p.excerpt,
      coverSeed: p.coverSeed,
      readMinutes: p.readMinutes,
      publishedAt: p.publishedAt,
      views: p.views,
      featured: p.featured,
      categories: p.categories.map((c) => ({ slug: c.slug, name: c.name })),
      tags: p.tags.map((t) => ({ slug: t.slug, name: t.name })),
    })),
  });
}
