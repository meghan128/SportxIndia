import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

// GET /api/ads — fetch active ad zones for public display
export async function GET() {
  const ads = await db.adZone.findMany({
    where: { active: true },
    select: { slot: true, adCode: true },
  });

  const adMap: Record<string, string> = {};
  for (const ad of ads) {
    if (ad.adCode) adMap[ad.slot] = ad.adCode;
  }

  return NextResponse.json({ ads: adMap });
}
