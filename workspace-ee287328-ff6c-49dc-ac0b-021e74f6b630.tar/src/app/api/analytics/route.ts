import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

// GET /api/analytics — aggregated data for Security Center charts
export async function GET() {
  const [
    postsByCategory,
    moderationDistribution,
    topPostsByViews,
    postsByMonth,
    auditByAction,
    incidentBySeverity,
  ] = await Promise.all([
    db.category.findMany({
      include: { _count: { select: { posts: { where: { status: "published" } } } } },
      orderBy: { name: "asc" },
    }),
    db.post.groupBy({
      by: ["status"],
      _count: true,
    }),
    db.post.findMany({
      where: { status: "published" },
      orderBy: { views: "desc" },
      take: 5,
      select: { title: true, views: true, slug: true },
    }),
    db.post.findMany({
      where: { status: "published" },
      orderBy: { publishedAt: "asc" },
      select: { publishedAt: true },
    }),
    db.auditLog.groupBy({
      by: ["action"],
      _count: true,
    }),
    db.securityIncident.groupBy({
      by: ["severity"],
      _count: true,
    }),
  ]);

  // Posts by month (last 12 months that have posts)
  const monthMap = new Map<string, number>();
  for (const p of postsByMonth) {
    const key = `${p.publishedAt.getFullYear()}-${String(p.publishedAt.getMonth() + 1).padStart(2, "0")}`;
    monthMap.set(key, (monthMap.get(key) ?? 0) + 1);
  }
  const byMonth = Array.from(monthMap.entries())
    .sort()
    .slice(-12)
    .map(([month, count]) => ({ month, count }));

  return NextResponse.json({
    postsByCategory: postsByCategory
      .filter((c) => c.slug !== "uncategorized")
      .map((c) => ({ name: c.name, slug: c.slug, count: c._count.posts }))
      .sort((a, b) => b.count - a.count),
    moderationDistribution: moderationDistribution.map((m) => ({
      status: m.status,
      count: m._count,
    })),
    topPosts: topPostsByViews.map((p) => ({
      title: p.title.length > 40 ? p.title.slice(0, 40) + "…" : p.title,
      views: p.views,
      slug: p.slug,
    })),
    postsByMonth: byMonth,
    auditByAction: auditByAction.map((a) => ({ action: a.action, count: a._count })),
    incidentBySeverity: incidentBySeverity.map((i) => ({
      severity: i.severity,
      count: i._count,
    })),
  });
}
