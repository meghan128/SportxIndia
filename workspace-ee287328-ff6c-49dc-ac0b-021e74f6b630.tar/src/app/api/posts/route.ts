import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

// GET /api/posts — list posts with filters
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const q = searchParams.get("q")?.trim().toLowerCase() ?? "";
  const category = searchParams.get("category")?.trim() ?? "";
  const tag = searchParams.get("tag")?.trim() ?? "";
  const author = searchParams.get("author")?.trim() ?? "";
  const sort = searchParams.get("sort") ?? "newest"; // newest | oldest | reads
  const limit = Math.min(48, Math.max(1, Number(searchParams.get("limit") ?? 24)));
  const offset = Math.max(0, Number(searchParams.get("offset") ?? 0));
  const includeQuarantined = searchParams.get("mod") === "1";

  const where = {
    AND: [
      includeQuarantined ? {} : { status: "published" as const },
      q
        ? {
            OR: [
              { title: { contains: q } },
              { contentPlain: { contains: q } },
              { excerpt: { contains: q } },
            ],
          }
        : {},
      category ? { categories: { some: { slug: category } } } : {},
      tag ? { tags: { some: { slug: tag } } } : {},
      author ? { author: { login: author } } : {},
    ],
  };

  const orderBy =
    sort === "reads"
      ? { views: "desc" as const }
      : sort === "oldest"
        ? { publishedAt: "asc" as const }
        : { publishedAt: "desc" as const };

  const [posts, total] = await Promise.all([
    db.post.findMany({
      where,
      orderBy,
      skip: offset,
      take: limit,
      include: {
        author: true,
        categories: true,
        tags: { take: 6 },
      },
    }),
    db.post.count({ where }),
  ]);

  return NextResponse.json({
    posts: posts.map((p) => ({
      id: p.id,
      slug: p.slug,
      title: p.title,
      excerpt: p.excerpt,
      coverSeed: p.coverSeed,
      readMinutes: p.readMinutes,
      publishedAt: p.publishedAt,
      contentHash: p.contentHash,
      status: p.status,
      moderationScore: p.moderationScore,
      featured: p.featured,
      views: p.views,
      author: {
        login: p.author.login,
        displayName: p.author.displayName,
      },
      categories: p.categories.map((c) => ({ slug: c.slug, name: c.name })),
      tags: p.tags.map((t) => ({ slug: t.slug, name: t.name })),
    })),
    total,
    offset,
    limit,
  });
}
