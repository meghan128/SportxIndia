import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

// GET /api/posts/[slug]/related — find related posts by shared tags/categories
export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ slug: string }> }
) {
  const { slug } = await params;
  const post = await db.post.findUnique({
    where: { slug },
    include: { tags: true, categories: true },
  });
  if (!post) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const tagIds = post.tags.map((t) => t.id);
  const catIds = post.categories.map((c) => c.id);

  // Find posts sharing tags or categories, excluding self, published only.
  // Score = shared tags * 2 + shared categories * 1
  const candidates = await db.post.findMany({
    where: {
      status: "published",
      id: { not: post.id },
      OR: [
        { tags: { some: { id: { in: tagIds } } } },
        { categories: { some: { id: { in: catIds } } } },
      ],
    },
    take: 30,
    include: {
      author: true,
      categories: true,
      tags: true,
    },
  });

  const scored = candidates
    .map((p) => {
      const sharedTags = p.tags.filter((t) => tagIds.includes(t.id)).length;
      const sharedCats = p.categories.filter((c) => catIds.includes(c.id)).length;
      return {
        post: p,
        score: sharedTags * 2 + sharedCats,
      };
    })
    .sort((a, b) => b.score - a.score || b.post.views - a.post.views)
    .slice(0, 4)
    .map(({ post: p }) => ({
      id: p.id,
      slug: p.slug,
      title: p.title,
      excerpt: p.excerpt,
      coverSeed: p.coverSeed,
      readMinutes: p.readMinutes,
      publishedAt: p.publishedAt,
      views: p.views,
      author: { login: p.author.login, displayName: p.author.displayName },
      categories: p.categories.map((c) => ({ slug: c.slug, name: c.name })),
    }));

  return NextResponse.json({ related: scored });
}
