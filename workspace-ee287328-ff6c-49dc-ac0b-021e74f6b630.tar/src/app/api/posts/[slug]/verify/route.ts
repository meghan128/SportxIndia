import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { createHash } from "node:crypto";

export const dynamic = "force-dynamic";

// GET /api/posts/[slug]/verify — re-hash the stored content and compare to the
// stored fingerprint. Returns whether the content is intact (not tampered).
// This is the tamper-detection endpoint: if the contentHash differs from a
// fresh SHA-256 of contentPlain, the post has been modified after import.
export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ slug: string }> }
) {
  const { slug } = await params;
  const post = await db.post.findUnique({
    where: { slug },
    select: {
      id: true,
      title: true,
      contentPlain: true,
      contentHash: true,
      importedAt: true,
    },
  });
  if (!post) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const freshHash = createHash("sha256")
    .update(post.contentPlain, "utf8")
    .digest("hex");
  const intact = freshHash === post.contentHash;

  return NextResponse.json({
    slug,
    title: post.title,
    verified: intact,
    storedHash: post.contentHash,
    computedHash: freshHash,
    algorithm: "SHA-256",
    importedAt: post.importedAt,
    lastVerified: new Date().toISOString(),
    message: intact
      ? "Content fingerprint matches the original. No tampering detected."
      : "WARNING: Content fingerprint mismatch. The article has been modified after publication.",
  });
}
