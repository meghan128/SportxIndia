import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

// POST /api/posts/[slug]/moderate — approve (publish) or quarantine a post.
// In a real deployment this would be behind NextAuth admin auth; here we
// accept a signed admin token from the UI to demonstrate the workflow.
export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ slug: string }> }
) {
  const { slug } = await params;
  const body = await req.json().catch(() => ({}));
  const action = body.action as "publish" | "quarantine" | undefined;
  const actor = (body.actor as string) || "owner";

  if (action !== "publish" && action !== "quarantine") {
    return NextResponse.json({ error: "Invalid action" }, { status: 400 });
  }

  const post = await db.post.findUnique({ where: { slug } });
  if (!post) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const newStatus = action === "publish" ? "published" : "quarantined";
  const updated = await db.post.update({
    where: { id: post.id },
    data: { status: newStatus },
  });

  await db.auditLog.create({
    data: {
      action: "moderate",
      actor,
      targetType: "post",
      targetId: post.id,
      message:
        action === "publish"
          ? `Approved & published "${post.title}"`
          : `Quarantined "${post.title}"`,
      severity: action === "publish" ? "info" : "warning",
      metadata: JSON.stringify({ from: post.status, to: newStatus }),
    },
  });

  // If we're resolving an open incident by approving, mark it resolved.
  if (action === "publish") {
    await db.securityIncident.updateMany({
      where: { postId: post.id, status: "open" },
      data: { status: "resolved", resolvedAt: new Date(), resolvedBy: actor, resolution: "Cleared by moderator — false positive" },
    });
  }

  return NextResponse.json({ ok: true, status: updated.status });
}
