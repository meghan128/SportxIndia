import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

// GET /api/posts/[slug] — single post detail (also returns quarantined for admin view)
export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ slug: string }> }
) {
  const { slug } = await params;
  const post = await db.post.findUnique({
    where: { slug },
    include: { author: true, categories: true, tags: true },
  });
  if (!post) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }
  return NextResponse.json({
    id: post.id,
    slug: post.slug,
    title: post.title,
    excerpt: post.excerpt,
    content: post.content,
    contentPlain: post.contentPlain,
    contentHash: post.contentHash,
    coverSeed: post.coverSeed,
    readMinutes: post.readMinutes,
    publishedAt: post.publishedAt,
    importedAt: post.importedAt,
    status: post.status,
    moderationScore: post.moderationScore,
    moderationReasons: post.moderationReasons,
    featured: post.featured,
    views: post.views,
    author: {
      login: post.author.login,
      displayName: post.author.displayName,
      bio: post.author.bio,
      role: post.author.role,
    },
    categories: post.categories.map((c) => ({ slug: c.slug, name: c.name })),
    tags: post.tags.map((t) => ({ slug: t.slug, name: t.name })),
  });
}
