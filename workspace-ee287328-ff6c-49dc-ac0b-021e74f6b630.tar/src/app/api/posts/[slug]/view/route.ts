import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

// POST /api/posts/[slug]/view — increment view counter
export async function POST(
  _req: NextRequest,
  { params }: { params: Promise<{ slug: string }> }
) {
  const { slug } = await params;
  const post = await db.post.findUnique({ where: { slug }, select: { id: true } });
  if (!post) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }
  await db.post.update({
    where: { id: post.id },
    data: { views: { increment: 1 } },
  });
  return NextResponse.json({ ok: true });
}
