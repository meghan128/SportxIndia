import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

// GET /api/filters — categories, tags, authors for the filter UI
export async function GET() {
  const [categories, authors, tagCounts] = await Promise.all([
    db.category.findMany({
      orderBy: { name: "asc" },
      include: { _count: { select: { posts: { where: { status: "published" } } } } },
    }),
    db.author.findMany({
      orderBy: { displayName: "asc" },
      include: { _count: { select: { posts: { where: { status: "published" } } } } },
    }),
    db.tag.findMany({
      where: { posts: { some: { status: "published" } } },
      orderBy: { name: "asc" },
      include: { _count: { select: { posts: { where: { status: "published" } } } } },
    }),
  ]);

  return NextResponse.json({
    categories: categories
      .filter((c) => c.slug !== "uncategorized")
      .map((c) => ({ slug: c.slug, name: c.name, count: c._count.posts })),
    authors: authors
      .filter((a) => a._count.posts > 0)
      .map((a) => ({
        login: a.login,
        displayName: a.displayName,
        role: a.role,
        count: a._count.posts,
      })),
    tags: tagCounts
      .filter((t) => t._count.posts > 0)
      .sort((a, b) => b._count.posts - a._count.posts)
      .slice(0, 40)
      .map((t) => ({ slug: t.slug, name: t.name, count: t._count.posts })),
  });
}
