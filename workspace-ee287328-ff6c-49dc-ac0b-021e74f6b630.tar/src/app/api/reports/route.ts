import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

// GET /api/reports — list content-theft / DMCA reports
export async function GET() {
  const reports = await db.contentReport.findMany({
    orderBy: { createdAt: "desc" },
    include: { post: { select: { title: true, slug: true } } },
  });
  return NextResponse.json({
    reports: reports.map((r) => ({
      id: r.id,
      reporterName: r.reporterName,
      reporterEmail: r.reporterEmail,
      infringingUrl: r.infringingUrl,
      postId: r.postId,
      post: r.post,
      description: r.description,
      status: r.status,
      createdAt: r.createdAt,
      updatedAt: r.updatedAt,
    })),
  });
}

// POST /api/reports — submit a new content-theft report (public)
export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const reporterName = String(body.reporterName ?? "").trim();
  const reporterEmail = String(body.reporterEmail ?? "").trim();
  const infringingUrl = String(body.infringingUrl ?? "").trim();
  const description = String(body.description ?? "").trim();
  const postId = body.postId ? String(body.postId) : null;

  if (!reporterName || !reporterEmail || !infringingUrl || !description) {
    return NextResponse.json(
      { error: "All fields are required." },
      { status: 400 }
    );
  }
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(reporterEmail)) {
    return NextResponse.json({ error: "Invalid email." }, { status: 400 });
  }
  if (!/^https?:\/\//i.test(infringingUrl)) {
    return NextResponse.json(
      { error: "Infringing URL must start with http:// or https://" },
      { status: 400 }
    );
  }

  const report = await db.contentReport.create({
    data: {
      reporterName,
      reporterEmail,
      infringingUrl,
      description,
      postId: postId || null,
      status: "open",
    },
  });

  await db.auditLog.create({
    data: {
      action: "report",
      actor: reporterEmail,
      targetType: "report",
      targetId: report.id,
      message: `New content-theft report filed for ${infringingUrl}`,
      severity: "warning",
      metadata: JSON.stringify({ infringingUrl, postId }),
    },
  });

  return NextResponse.json({ ok: true, id: report.id });
}
