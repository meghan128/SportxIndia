import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

// GET /api/audit — audit log timeline (most recent first)
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const limit = Math.min(100, Math.max(1, Number(searchParams.get("limit") ?? 30)));
  const severity = searchParams.get("severity"); // info | warning | critical

  const entries = await db.auditLog.findMany({
    where: severity ? { severity } : {},
    orderBy: { createdAt: "desc" },
    take: limit,
  });

  return NextResponse.json({
    entries: entries.map((e) => ({
      id: e.id,
      action: e.action,
      actor: e.actor,
      targetType: e.targetType,
      targetId: e.targetId,
      message: e.message,
      severity: e.severity,
      metadata: e.metadata,
      createdAt: e.createdAt,
    })),
  });
}
