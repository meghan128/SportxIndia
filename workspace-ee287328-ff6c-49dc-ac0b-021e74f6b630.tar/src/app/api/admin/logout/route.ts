import { NextResponse } from "next/server";
import { getAuthToken, destroySession } from "@/lib/admin-auth";

export const dynamic = "force-dynamic";

// POST /api/admin/logout
export async function POST() {
  const token = await getAuthToken();
  if (token) await destroySession(token);

  const res = NextResponse.json({ ok: true });
  res.cookies.delete("admin-token");
  return res;
}
