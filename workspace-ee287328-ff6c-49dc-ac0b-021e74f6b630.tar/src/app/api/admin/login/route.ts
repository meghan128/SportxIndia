import { NextRequest, NextResponse } from "next/server";
import { verifyPassword, createSession } from "@/lib/admin-auth";

export const dynamic = "force-dynamic";

// POST /api/admin/login
export async function POST(req: NextRequest) {
  const { password } = await req.json().catch(() => ({}));

  if (!password) {
    return NextResponse.json({ error: "Password required" }, { status: 400 });
  }

  if (!verifyPassword(password)) {
    return NextResponse.json({ error: "Invalid password" }, { status: 401 });
  }

  const token = await createSession();

  const res = NextResponse.json({ ok: true });
  res.cookies.set("admin-token", token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    maxAge: 7 * 24 * 60 * 60, // 7 days
    path: "/",
  });

  return res;
}
