import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { isAuthenticated } from "@/lib/admin-auth";

export const dynamic = "force-dynamic";

// GET /api/admin/newsletter — list campaigns + subscriber count
export async function GET() {
  if (!(await isAuthenticated())) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const [campaigns, subscriberCount] = await Promise.all([
    db.newsletterCampaign.findMany({ orderBy: { createdAt: "desc" }, take: 20 }),
    db.subscriber.count({ where: { active: true } }),
  ]);

  return NextResponse.json({
    campaigns: campaigns.map((c) => ({
      id: c.id,
      subject: c.subject,
      status: c.status,
      sentCount: c.sentCount,
      sentAt: c.sentAt,
      createdAt: c.createdAt,
    })),
    subscriberCount,
  });
}

// POST /api/admin/newsletter — create + send a campaign
export async function POST(req: NextRequest) {
  if (!(await isAuthenticated())) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { subject, body, send } = await req.json().catch(() => ({}));

  if (!subject || !body) {
    return NextResponse.json({ error: "Subject and body required" }, { status: 400 });
  }

  const campaign = await db.newsletterCampaign.create({
    data: {
      subject,
      body,
      status: send ? "sent" : "draft",
      sentAt: send ? new Date() : null,
    },
  });

  if (send) {
    // Fetch all active subscribers
    const subscribers = await db.subscriber.findMany({
      where: { active: true },
      select: { email: true },
    });

    // Send via Resend if configured, otherwise just record the count
    const resendKey = process.env.RESEND_API_KEY;
    let sentCount = 0;

    if (resendKey) {
      // Send individual emails via Resend API
      const fromEmail = process.env.NEWSLETTER_FROM || "newsletter@sportxindia.com";

      for (const sub of subscribers) {
        try {
          const res = await fetch("https://api.resend.com/emails", {
            method: "POST",
            headers: {
              "Authorization": `Bearer ${resendKey}`,
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              from: `SportX India <${fromEmail}>`,
              to: sub.email,
              subject,
              html: body,
            }),
          });
          if (res.ok) sentCount++;
        } catch {
          // continue on individual failures
        }
      }
    } else {
      // No Resend key — just record the count (for local dev / testing)
      sentCount = subscribers.length;
    }

    await db.newsletterCampaign.update({
      where: { id: campaign.id },
      data: { sentCount },
    });

    await db.auditLog.create({
      data: {
        action: "newsletter",
        actor: "owner",
        targetType: "system",
        message: `Sent newsletter "${subject}" to ${sentCount} subscribers`,
        severity: "info",
      },
    });

    return NextResponse.json({ ok: true, sentCount, campaignId: campaign.id });
  }

  return NextResponse.json({ ok: true, campaignId: campaign.id, status: "draft" });
}
