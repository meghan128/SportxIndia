import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { isAuthenticated } from "@/lib/admin-auth";
import { createHash } from "node:crypto";

export const dynamic = "force-dynamic";

// Moderation engine (reused from seed)
const SPAM_PATTERNS: { re: RegExp; weight: number; label: string }[] = [
  { re: /slavic\s+brides?/i, weight: 90, label: "spam:slavic-brides" },
  { re: /\bmail[- ]?order\s+(brides?|wives?)/i, weight: 90, label: "spam:mail-order-brides" },
  { re: /\b(russian|ukrainian|asian)\s+(brides?|women|girls|wives?|singles)\b/i, weight: 85, label: "spam:dating-brides" },
  { re: /\bdating\s+(site|service|agency|app)\b/i, weight: 60, label: "spam:dating-service" },
  { re: /\b(hookup|casual\s+encounters?|adult\s+dating)\b/i, weight: 80, label: "spam:hookup" },
  { re: /\bai\s+girlfriend\b/i, weight: 70, label: "spam:ai-girlfriend" },
  { re: /\b(buy\s+cheap|cheap\s+pills?|discount\s+pharmacy)\b/i, weight: 75, label: "spam:pharmacy" },
  { re: /\b(viagra|cialis|levitra)\b/i, weight: 70, label: "spam:ed-drugs" },
  { re: /\b(online\s+casino|sports\s+betting|crypto\s+casino)\b/i, weight: 65, label: "spam:gambling" },
  { re: /\b(free\s+money|guaranteed\s+income|work\s+from\s+home\s+earn)\b/i, weight: 65, label: "spam:scam-income" },
  { re: /\bsteroids?\s+for\s+sale|buy\s+steroids?\b/i, weight: 80, label: "spam:steroids-sale" },
];

function moderate(title: string, plain: string): { score: number; reasons: string[] } {
  const text = `${title}\n${plain}`;
  const reasons: string[] = [];
  let score = 0;
  for (const { re, weight, label } of SPAM_PATTERNS) {
    if (re.test(text)) {
      score += weight;
      reasons.push(label);
    }
  }
  return { score: Math.min(100, score), reasons };
}

function slugify(t: string): string {
  return t.toLowerCase().replace(/[^a-z0-9\s-]/g, "").replace(/[\s_-]+/g, "-").trim("-").slice(0, 80) || "post";
}

function toPlain(html: string): string {
  return html.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();
}

function cleanHtml(h: string): string {
  return h.replace(/<!--\s*\/?wp:[a-z/]+[^>]*?-->/g, "").replace(/\n{3,}/g, "\n\n").trim();
}

// GET /api/admin/posts — list all posts (including drafts/quarantined)
export async function GET() {
  if (!(await isAuthenticated())) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const posts = await db.post.findMany({
    orderBy: { publishedAt: "desc" },
    take: 100,
    include: { author: true, categories: true },
  });

  return NextResponse.json({
    posts: posts.map((p) => ({
      id: p.id,
      slug: p.slug,
      title: p.title,
      status: p.status,
      publishedAt: p.publishedAt,
      views: p.views,
      moderationScore: p.moderationScore,
      thumbnailUrl: p.thumbnailUrl,
      author: { displayName: p.author.displayName },
      categories: p.categories.map((c) => c.name),
    })),
  });
}

// POST /api/admin/posts — create a new post
export async function POST(req: NextRequest) {
  if (!(await isAuthenticated())) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const body = await req.json().catch(() => ({}));
  const { title, content, excerpt, thumbnailUrl, categoryId, tagNames, authorLogin } = body;

  if (!title || !content) {
    return NextResponse.json({ error: "Title and content are required" }, { status: 400 });
  }

  const cleanedHtml = cleanHtml(content);
  const plain = toPlain(cleanedHtml);
  const contentHash = createHash("sha256").update(plain, "utf8").digest("hex");
  const slug = `${slugify(title)}-${Date.now().toString(36)}`;
  const { score, reasons } = moderate(title, plain);
  const isQuarantined = score >= 60 || reasons.some((r) => r.startsWith("spam:"));

  // Find or create author
  let author = authorLogin
    ? await db.author.findUnique({ where: { login: authorLogin } })
    : null;
  if (!author) {
    // Default to first author
    author = await db.author.findFirst();
    if (!author) {
      return NextResponse.json({ error: "No author found. Seed the database first." }, { status: 500 });
    }
  }

  // Find or create category
  let category = null;
  if (categoryId) {
    category = await db.category.findUnique({ where: { id: categoryId } });
  }

  // Find or create tags
  const tags: { id: string }[] = [];
  if (tagNames && Array.isArray(tagNames)) {
    for (const tagName of tagNames.slice(0, 12)) {
      const slug = slugify(tagName);
      const tag = await db.tag.upsert({
        where: { slug },
        update: {},
        create: { slug, name: tagName },
      });
      tags.push({ id: tag.id });
    }
  }

  const readMinutes = Math.max(2, Math.ceil(plain.length / 900));

  const postData: Record<string, unknown> = {
    slug,
    title,
    excerpt: excerpt || plain.slice(0, 180) + (plain.length > 180 ? "…" : ""),
    content: cleanedHtml,
    contentPlain: plain,
    contentHash,
    coverSeed: slug,
    thumbnailUrl: thumbnailUrl || null,
    readMinutes,
    authorId: author.id,
    publishedAt: new Date(),
    status: isQuarantined ? "quarantined" : "published",
    moderationScore: score,
    moderationReasons: JSON.stringify(reasons),
  };

  if (category) {
    postData.categories = { connect: { id: category.id } };
  }
  if (tags.length > 0) {
    postData.tags = { connect: tags };
  }

  const post = await db.post.create({
    data: postData as any,
  });

  if (isQuarantined) {
    await db.securityIncident.create({
      data: {
        postId: post.id,
        type: "keyword_match",
        severity: "high",
        reason: `Auto-moderation flagged: ${reasons.join(", ")}. Score ${score}/100.`,
        status: "open",
      },
    });
  }

  await db.auditLog.create({
    data: {
      action: "create",
      actor: "owner",
      targetType: "post",
      targetId: post.id,
      message: `Created "${title}" (${isQuarantined ? "quarantined" : "published"})`,
      severity: isQuarantined ? "warning" : "info",
      metadata: JSON.stringify({ score, reasons }),
    },
  });

  return NextResponse.json({ ok: true, slug: post.slug, status: post.status, moderationScore: score });
}
