import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { isAuthenticated } from "@/lib/admin-auth";

export const dynamic = "force-dynamic";

// DELETE /api/admin/posts/[id]
export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  if (!(await isAuthenticated())) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { id } = await params;
  const post = await db.post.findUnique({ where: { id } });
  if (!post) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  await db.post.delete({ where: { id } });

  await db.auditLog.create({
    data: {
      action: "delete",
      actor: "owner",
      targetType: "post",
      targetId: id,
      message: `Deleted "${post.title}"`,
      severity: "warning",
    },
  });

  return NextResponse.json({ ok: true });
}

// PATCH /api/admin/posts/[id] — update status (publish/quarantine) or content
export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  if (!(await isAuthenticated())) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { id } = await params;
  const body = await req.json().catch(() => ({}));
  const { action } = body;

  if (action === "publish" || action === "quarantine") {
    const post = await db.post.update({
      where: { id },
      data: { status: action === "publish" ? "published" : "quarantined" },
    });

    await db.auditLog.create({
      data: {
        action: "moderate",
        actor: "owner",
        targetType: "post",
        targetId: id,
        message: `${action === "publish" ? "Published" : "Quarantined"} "${post.title}"`,
        severity: action === "publish" ? "info" : "warning",
      },
    });

    return NextResponse.json({ ok: true, status: post.status });
  }

  return NextResponse.json({ error: "Invalid action" }, { status: 400 });
}
