import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { isAuthenticated } from "@/lib/admin-auth";

export const dynamic = "force-dynamic";

// GET /api/admin/ads — list all ad zones
export async function GET() {
  if (!(await isAuthenticated())) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const ads = await db.adZone.findMany({ orderBy: { slot: "asc" } });
  return NextResponse.json({ ads });
}

// PUT /api/admin/ads — update an ad zone
export async function PUT(req: NextRequest) {
  if (!(await isAuthenticated())) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { slot, name, adCode, active } = await req.json().catch(() => ({}));

  if (!slot) {
    return NextResponse.json({ error: "Slot required" }, { status: 400 });
  }

  const ad = await db.adZone.upsert({
    where: { slot },
    update: { name, adCode, active },
    create: { slot, name: name || slot, adCode, active: active ?? false },
  });

  return NextResponse.json({ ok: true, ad });
}
