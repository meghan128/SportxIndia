import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { isAuthenticated } from "@/lib/admin-auth";

export const dynamic = "force-dynamic";

// GET /api/admin/stats — dashboard overview
export async function GET() {
  if (!(await isAuthenticated())) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const [
    totalPosts,
    publishedPosts,
    quarantinedPosts,
    totalSubscribers,
    totalViews,
    activeAds,
    totalCampaigns,
    recentAudit,
  ] = await Promise.all([
    db.post.count(),
    db.post.count({ where: { status: "published" } }),
    db.post.count({ where: { status: "quarantined" } }),
    db.subscriber.count({ where: { active: true } }),
    db.post.aggregate({ _sum: { views: true } }),
    db.adZone.count({ where: { active: true } }),
    db.newsletterCampaign.count(),
    db.auditLog.findMany({
      orderBy: { createdAt: "desc" },
      take: 10,
    }),
  ]);

  return NextResponse.json({
    posts: { total: totalPosts, published: publishedPosts, quarantined: quarantinedPosts },
    subscribers: totalSubscribers,
    totalViews: totalViews._sum.views ?? 0,
    activeAds,
    campaigns: totalCampaigns,
    recentActivity: recentAudit.map((a) => ({
      action: a.action,
      message: a.message,
      severity: a.severity,
      createdAt: a.createdAt,
    })),
  });
}
