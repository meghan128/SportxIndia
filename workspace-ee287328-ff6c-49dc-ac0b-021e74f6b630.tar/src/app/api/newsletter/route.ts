import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

// POST /api/newsletter — subscribe an email
export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const email = String(body.email ?? "").trim().toLowerCase();
  const name = String(body.name ?? "").trim() || null;
  const source = String(body.source ?? "footer").trim();

  if (!email) {
    return NextResponse.json({ error: "Email is required." }, { status: 400 });
  }
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) {
    return NextResponse.json({ error: "Please enter a valid email." }, { status: 400 });
  }

  const existing = await db.subscriber.findUnique({ where: { email } });
  if (existing) {
    if (!existing.active) {
      await db.subscriber.update({
        where: { id: existing.id },
        data: { active: true, name },
      });
      return NextResponse.json({ ok: true, reactivated: true });
    }
    return NextResponse.json({ ok: true, already: true });
  }

  await db.subscriber.create({ data: { email, name, source } });
  await db.auditLog.create({
    data: {
      action: "subscribe",
      actor: email,
      targetType: "system",
      message: `New newsletter subscriber: ${email}`,
      severity: "info",
      metadata: JSON.stringify({ source }),
    },
  });
  return NextResponse.json({ ok: true });
}

// GET /api/newsletter — subscriber count (for dashboard display)
export async function GET() {
  const count = await db.subscriber.count({ where: { active: true } });
  return NextResponse.json({ subscribers: count });
}
