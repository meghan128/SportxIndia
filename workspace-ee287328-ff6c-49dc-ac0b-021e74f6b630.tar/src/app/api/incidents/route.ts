import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

// GET /api/incidents — security incidents list
export async function GET() {
  const incidents = await db.securityIncident.findMany({
    orderBy: { detectedAt: "desc" },
    include: { post: { select: { title: true, slug: true, status: true, moderationScore: true } } },
  });
  return NextResponse.json({
    incidents: incidents.map((i) => ({
      id: i.id,
      postId: i.postId,
      type: i.type,
      severity: i.severity,
      reason: i.reason,
      status: i.status,
      detectedAt: i.detectedAt,
      resolvedAt: i.resolvedAt,
      resolvedBy: i.resolvedBy,
      resolution: i.resolution,
      post: i.post,
    })),
  });
}
