import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

// POST /api/incidents/[id]/resolve — resolve or ignore a security incident
export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const body = await req.json().catch(() => ({}));
  const resolution = (body.resolution as "resolved" | "ignored") ?? "resolved";
  const note = (body.note as string) ?? "";
  const actor = (body.actor as string) || "owner";

  const incident = await db.securityIncident.findUnique({ where: { id } });
  if (!incident) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const updated = await db.securityIncident.update({
    where: { id },
    data: {
      status: resolution,
      resolvedAt: new Date(),
      resolvedBy: actor,
      resolution: note || (resolution === "ignored" ? "Marked as false positive" : "Resolved by moderator"),
    },
  });

  await db.auditLog.create({
    data: {
      action: "resolve",
      actor,
      targetType: "incident",
      targetId: incident.id,
      message: `${resolution === "resolved" ? "Resolved" : "Ignored"} incident on "${incident.reason.slice(0, 60)}…"`,
      severity: resolution === "resolved" ? "info" : "warning",
      metadata: JSON.stringify({ incidentType: incident.type, postId: incident.postId }),
    },
  });

  return NextResponse.json({ ok: true, status: updated.status });
}
