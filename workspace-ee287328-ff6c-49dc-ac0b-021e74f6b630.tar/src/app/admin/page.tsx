"use client";

import { useEffect, useState, useCallback } from "react";
import { useRouter } from "next/navigation";
import {
  LayoutDashboard,
  FileText,
  PenSquare,
  Megaphone,
  Mail,
  LogOut,
  Loader2,
  Plus,
  Trash2,
  Eye,
  Send,
  ExternalLink,
  TrendingUp,
  Users,
  DollarSign,
  ShieldCheck,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { format } from "date-fns";

type AdminStats = {
  posts: { total: number; published: number; quarantined: number };
  subscribers: number;
  totalViews: number;
  activeAds: number;
  campaigns: number;
  recentActivity: { action: string; message: string; severity: string; createdAt: string }[];
};

type AdminPost = {
  id: string;
  slug: string;
  title: string;
  status: string;
  publishedAt: string;
  views: number;
  moderationScore: number;
  thumbnailUrl: string | null;
  author: { displayName: string };
  categories: string[];
};

type AdZone = {
  id: string;
  slot: string;
  name: string;
  adCode: string | null;
  active: boolean;
};

type Campaign = {
  id: string;
  subject: string;
  status: string;
  sentCount: number;
  sentAt: string | null;
  createdAt: string;
};

export default function AdminDashboard() {
  const router = useRouter();
  const [authChecked, setAuthChecked] = useState(false);
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [posts, setPosts] = useState<AdminPost[]>([]);
  const [ads, setAds] = useState<AdZone[]>([]);
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [subscriberCount, setSubscriberCount] = useState(0);
  const [categories, setCategories] = useState<{ id: string; slug: string; name: string }[]>([]);
  const [loading, setLoading] = useState(true);

  // Check auth on mount
  useEffect(() => {
    fetch("/api/admin/stats")
      .then((r) => {
        if (r.status === 401) {
          router.push("/admin/login");
          return null;
        }
        return r.json();
      })
      .then((d) => {
        if (d) {
          setStats(d);
          setAuthChecked(true);
        }
      })
      .catch(() => router.push("/admin/login"));
  }, [router]);

  // Load all data
  const loadAll = useCallback(async () => {
    setLoading(true);
    try {
      const [postsRes, adsRes, nlRes, catRes] = await Promise.all([
        fetch("/api/admin/posts").then((r) => r.json()),
        fetch("/api/admin/ads").then((r) => r.json()),
        fetch("/api/admin/newsletter").then((r) => r.json()),
        fetch("/api/filters").then((r) => r.json()),
      ]);
      setPosts(postsRes.posts ?? []);
      setAds(adsRes.ads ?? []);
      setCampaigns(nlRes.campaigns ?? []);
      setSubscriberCount(nlRes.subscriberCount ?? 0);
      setCategories(catRes.categories ?? []);
    } catch {
      // ignore
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (authChecked) loadAll();
  }, [authChecked, loadAll]);

  const handleLogout = async () => {
    await fetch("/api/admin/logout", { method: "POST" });
    router.push("/admin/login");
  };

  if (!authChecked) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-muted/30">
      {/* Header */}
      <header className="sticky top-0 z-40 border-b bg-card">
        <div className="mx-auto flex h-14 max-w-6xl items-center gap-3 px-4">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-primary-foreground">
              <ShieldCheck className="h-4 w-4" />
            </div>
            <span className="font-serif text-lg font-bold">SportX Admin</span>
          </div>
          <div className="ml-auto flex items-center gap-2">
            <a href="/" target="_blank" rel="noopener noreferrer">
              <Button variant="ghost" size="sm" className="gap-1.5">
                <ExternalLink className="h-3.5 w-3.5" />
                View site
              </Button>
            </a>
            <Button variant="ghost" size="sm" onClick={handleLogout} className="gap-1.5">
              <LogOut className="h-3.5 w-3.5" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4 py-6">
        <Tabs defaultValue="dashboard">
          <TabsList className="mb-6 grid w-full grid-cols-5">
            <TabsTrigger value="dashboard" className="gap-1.5">
              <LayoutDashboard className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">Dashboard</span>
            </TabsTrigger>
            <TabsTrigger value="posts" className="gap-1.5">
              <FileText className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">Posts</span>
            </TabsTrigger>
            <TabsTrigger value="write" className="gap-1.5">
              <PenSquare className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">Write</span>
            </TabsTrigger>
            <TabsTrigger value="ads" className="gap-1.5">
              <Megaphone className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">Ads</span>
            </TabsTrigger>
            <TabsTrigger value="newsletter" className="gap-1.5">
              <Mail className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">Newsletter</span>
            </TabsTrigger>
          </TabsList>

          {/* Dashboard tab */}
          <TabsContent value="dashboard">
            {stats && <DashboardTab stats={stats} />}
          </TabsContent>

          {/* Posts tab */}
          <TabsContent value="posts">
            <PostsTab posts={posts} loading={loading} onRefresh={loadAll} />
          </TabsContent>

          {/* Write tab */}
          <TabsContent value="write">
            <WriteTab categories={categories} onPublished={loadAll} />
          </TabsContent>

          {/* Ads tab */}
          <TabsContent value="ads">
            <AdsTab ads={ads} onRefresh={loadAll} />
          </TabsContent>

          {/* Newsletter tab */}
          <TabsContent value="newsletter">
            <NewsletterTab
              campaigns={campaigns}
              subscriberCount={subscriberCount}
              onRefresh={loadAll}
            />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}

// ===== Dashboard Tab =====
function DashboardTab({ stats }: { stats: AdminStats }) {
  const cards = [
    { label: "Total Posts", value: stats.posts.total, icon: FileText, tone: "default" },
    { label: "Published", value: stats.posts.published, icon: Eye, tone: "success" },
    { label: "Subscribers", value: stats.subscribers, icon: Users, tone: "default" },
    { label: "Total Views", value: stats.totalViews, icon: TrendingUp, tone: "default" },
    { label: "Active Ads", value: stats.activeAds, icon: DollarSign, tone: "warning" },
    { label: "Campaigns", value: stats.campaigns, icon: Mail, tone: "default" },
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
        {cards.map((c) => (
          <div key={c.label} className="rounded-xl border bg-card p-4">
            <c.icon className="mb-2 h-5 w-5 text-primary" />
            <div className="text-2xl font-bold tabular-nums">{c.value.toLocaleString()}</div>
            <div className="text-xs text-muted-foreground">{c.label}</div>
          </div>
        ))}
      </div>

      {stats.posts.quarantined > 0 && (
        <div className="rounded-xl border border-destructive/30 bg-destructive/5 p-4">
          <p className="text-sm font-semibold text-destructive">
            {stats.posts.quarantined} post(s) quarantined by auto-moderation
          </p>
          <p className="text-xs text-muted-foreground">
            Review them in the Posts tab.
          </p>
        </div>
      )}

      <div>
        <h3 className="mb-3 text-sm font-semibold">Recent Activity</h3>
        <div className="space-y-2">
          {stats.recentActivity.length === 0 ? (
            <p className="text-sm text-muted-foreground">No recent activity.</p>
          ) : (
            stats.recentActivity.map((a, i) => (
              <div key={i} className="flex items-center gap-3 rounded-lg border bg-card p-3 text-sm">
                <div className={`h-2 w-2 rounded-full ${
                  a.severity === "critical" ? "bg-destructive" :
                  a.severity === "warning" ? "bg-amber-500" : "bg-emerald-500"
                }`} />
                <span className="flex-1">{a.message}</span>
                <span className="text-xs text-muted-foreground">
                  {format(new Date(a.createdAt), "d MMM, HH:mm")}
                </span>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}

// ===== Posts Tab =====
function PostsTab({
  posts,
  loading,
  onRefresh,
}: {
  posts: AdminPost[];
  loading: boolean;
  onRefresh: () => void;
}) {
  const handleAction = async (id: string, action: "publish" | "quarantine") => {
    try {
      await fetch(`/api/admin/posts/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action }),
      });
      toast.success(action === "publish" ? "Post published" : "Post quarantined");
      onRefresh();
    } catch {
      toast.error("Action failed");
    }
  };

  const handleDelete = async (id: string, title: string) => {
    if (!confirm(`Delete "${title}"? This cannot be undone.`)) return;
    try {
      await fetch(`/api/admin/posts/${id}`, { method: "DELETE" });
      toast.success("Post deleted");
      onRefresh();
    } catch {
      toast.error("Delete failed");
    }
  };

  if (loading) return <div className="py-8 text-center text-muted-foreground">Loading posts…</div>;

  return (
    <div className="space-y-3">
      {posts.length === 0 ? (
        <p className="py-8 text-center text-muted-foreground">No posts yet. Write one!</p>
      ) : (
        posts.map((p) => (
          <div key={p.id} className="flex items-center gap-3 rounded-xl border bg-card p-4">
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2">
                <span className="truncate text-sm font-semibold">{p.title}</span>
                <Badge
                  variant={p.status === "published" ? "default" : "destructive"}
                  className="text-[10px]"
                >
                  {p.status}
                </Badge>
                {p.moderationScore > 0 && (
                  <Badge variant="outline" className="text-[10px]">
                    Score: {p.moderationScore}
                  </Badge>
                )}
              </div>
              <div className="mt-1 flex items-center gap-2 text-xs text-muted-foreground">
                <span>{p.author.displayName}</span>
                <span>·</span>
                <span>{format(new Date(p.publishedAt), "d MMM yyyy")}</span>
                <span>·</span>
                <span>{p.views} views</span>
                {p.categories.length > 0 && (
                  <>
                    <span>·</span>
                    <span>{p.categories.join(", ")}</span>
                  </>
                )}
              </div>
            </div>
            <div className="flex shrink-0 gap-1">
              {p.status !== "published" && (
                <Button size="sm" variant="ghost" onClick={() => handleAction(p.id, "publish")}>
                  Publish
                </Button>
              )}
              {p.status !== "quarantined" && (
                <Button size="sm" variant="ghost" onClick={() => handleAction(p.id, "quarantine")}>
                  Quarantine
                </Button>
              )}
              <Button
                size="sm"
                variant="ghost"
                className="text-destructive hover:text-destructive"
                onClick={() => handleDelete(p.id, p.title)}
              >
                <Trash2 className="h-3.5 w-3.5" />
              </Button>
            </div>
          </div>
        ))
      )}
    </div>
  );
}

// ===== Write Tab =====
function WriteTab({
  categories,
  onPublished,
}: {
  categories: { id: string; slug: string; name: string }[];
  onPublished: () => void;
}) {
  const [title, setTitle] = useState("");
  const [excerpt, setExcerpt] = useState("");
  const [content, setContent] = useState("");
  const [thumbnailUrl, setThumbnailUrl] = useState("");
  const [categoryId, setCategoryId] = useState("");
  const [tags, setTags] = useState("");
  const [publishing, setPublishing] = useState(false);

  const handlePublish = async () => {
    if (!title.trim() || !content.trim()) {
      toast.error("Title and content are required.");
      return;
    }
    setPublishing(true);
    try {
      const tagNames = tags.split(",").map((t) => t.trim()).filter(Boolean);
      const res = await fetch("/api/admin/posts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title,
          excerpt: excerpt || undefined,
          content,
          thumbnailUrl: thumbnailUrl || undefined,
          categoryId: categoryId || undefined,
          tagNames,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Publish failed");

      if (data.status === "quarantined") {
        toast.warning("Published but quarantined by auto-moderation.", {
          description: `Score: ${data.moderationScore}/100`,
        });
      } else {
        toast.success("Article published!");
      }

      // Reset form
      setTitle("");
      setExcerpt("");
      setContent("");
      setThumbnailUrl("");
      setCategoryId("");
      setTags("");
      onPublished();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Publish failed");
    } finally {
      setPublishing(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="rounded-xl border bg-card p-6">
        <h2 className="mb-4 font-serif text-xl font-bold">Write New Article</h2>

        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="title">Title *</Label>
            <Input
              id="title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Enter article title…"
              className="text-lg"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="excerpt">Excerpt (optional)</Label>
            <Input
              id="excerpt"
              value={excerpt}
              onChange={(e) => setExcerpt(e.target.value)}
              placeholder="Short summary (auto-generated if empty)…"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="thumbnail">Thumbnail Image URL (optional)</Label>
            <Input
              id="thumbnail"
              value={thumbnailUrl}
              onChange={(e) => setThumbnailUrl(e.target.value)}
              placeholder="https://example.com/sports-photo.jpg"
            />
            {thumbnailUrl && (
              <div className="mt-2 h-32 overflow-hidden rounded-lg border">
                <img src={thumbnailUrl} alt="Preview" className="h-full w-full object-cover" />
              </div>
            )}
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Category</Label>
              <Select value={categoryId} onValueChange={setCategoryId}>
                <SelectTrigger>
                  <SelectValue placeholder="Select category…" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((c) => (
                    <SelectItem key={c.id} value={c.id}>
                      {c.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="tags">Tags (comma-separated)</Label>
              <Input
                id="tags"
                value={tags}
                onChange={(e) => setTags(e.target.value)}
                placeholder="cricket, IPL, memoirs"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="content">Content * (HTML)</Label>
            <Textarea
              id="content"
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="<p>Write your article in HTML…</p><p>Use &lt;p&gt;, &lt;h2&gt;, &lt;h3&gt;, &lt;blockquote&gt;, &lt;strong&gt;, &lt;em&gt;, &lt;a href&gt; tags.</p>"
              className="min-h-[300px] font-mono text-sm"
            />
            <p className="text-xs text-muted-foreground">
              Supports HTML: &lt;p&gt;, &lt;h2&gt;, &lt;h3&gt;, &lt;blockquote&gt;, &lt;strong&gt;, &lt;em&gt;, &lt;a&gt;, &lt;ul&gt;, &lt;ol&gt;
            </p>
          </div>

          <div className="flex justify-end gap-2">
            <Button
              onClick={handlePublish}
              disabled={publishing || !title || !content}
              className="gap-1.5"
            >
              {publishing ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Plus className="h-4 w-4" />
              )}
              {publishing ? "Publishing…" : "Publish Article"}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ===== Ads Tab =====
function AdsTab({ ads, onRefresh }: { ads: AdZone[]; onRefresh: () => void }) {
  const slots = ["header", "sidebar", "in-article", "footer"];
  const [editing, setEditing] = useState<Record<string, { adCode: string; active: boolean }>>({});
  const [saving, setSaving] = useState<string | null>(null);

  // Initialize editing state from ads
  useEffect(() => {
    const state: Record<string, { adCode: string; active: boolean }> = {};
    for (const slot of slots) {
      const ad = ads.find((a) => a.slot === slot);
      state[slot] = {
        adCode: ad?.adCode ?? "",
        active: ad?.active ?? false,
      };
    }
    setEditing(state);
  }, [ads]);

  const handleSave = async (slot: string) => {
    setSaving(slot);
    try {
      const data = editing[slot];
      await fetch("/api/admin/ads", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          slot,
          name: slot.charAt(0).toUpperCase() + slot.slice(1),
          adCode: data.adCode,
          active: data.active,
        }),
      });
      toast.success(`Ad zone "${slot}" saved`);
      onRefresh();
    } catch {
      toast.error("Save failed");
    } finally {
      setSaving(null);
    }
  };

  return (
    <div className="space-y-4">
      <div className="rounded-xl border bg-blue-50 p-4 text-sm dark:bg-blue-950/20">
        <p className="font-semibold">How to monetize with Google AdSense:</p>
        <ol className="mt-2 list-decimal space-y-1 pl-4 text-muted-foreground">
          <li>Apply at <a href="https://adsense.google.com" target="_blank" rel="noopener noreferrer" className="text-primary underline">adsense.google.com</a></li>
          <li>Get approved (may take a few days)</li>
          <li>Create ad units in AdSense dashboard</li>
          <li>Copy the ad code snippet</li>
          <li>Paste it into the ad zones below</li>
          <li>Toggle "Active" and save</li>
        </ol>
      </div>

      {slots.map((slot) => (
        <div key={slot} className="rounded-xl border bg-card p-4">
          <div className="mb-3 flex items-center justify-between">
            <div>
              <h3 className="font-semibold capitalize">{slot} Ad Zone</h3>
              <p className="text-xs text-muted-foreground">
                {slot === "header" && "Banner at the top of the page"}
                {slot === "sidebar" && "Vertical ad in the article reader"}
                {slot === "in-article" && "Mid-content ad within articles"}
                {slot === "footer" && "Banner at the bottom of the page"}
              </p>
            </div>
            {editing[slot] && (
              <label className="flex items-center gap-2 text-sm">
                <input
                  type="checkbox"
                  checked={editing[slot].active}
                  onChange={(e) =>
                    setEditing({
                      ...editing,
                      [slot]: { ...editing[slot], active: e.target.checked },
                    })
                  }
                  className="h-4 w-4 rounded"
                />
                Active
              </label>
            )}
          </div>
          <Textarea
            value={editing[slot]?.adCode ?? ""}
            onChange={(e) =>
              setEditing({
                ...editing,
                [slot]: { ...editing[slot], adCode: e.target.value },
              })
            }
            placeholder="Paste your Google AdSense code here…&#10;<script async src=…></script>"
            className="min-h-[100px] font-mono text-xs"
          />
          <div className="mt-2 flex justify-end">
            <Button
              size="sm"
              onClick={() => handleSave(slot)}
              disabled={saving === slot}
            >
              {saving === slot ? <Loader2 className="h-4 w-4 animate-spin" /> : "Save"}
            </Button>
          </div>
        </div>
      ))}
    </div>
  );
}

// ===== Newsletter Tab =====
function NewsletterTab({
  campaigns,
  subscriberCount,
  onRefresh,
}: {
  campaigns: Campaign[];
  subscriberCount: number;
  onRefresh: () => void;
}) {
  const [subject, setSubject] = useState("");
  const [body, setBody] = useState("");
  const [sending, setSending] = useState(false);

  const handleSend = async () => {
    if (!subject.trim() || !body.trim()) {
      toast.error("Subject and body are required.");
      return;
    }
    setSending(true);
    try {
      const res = await fetch("/api/admin/newsletter", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ subject, body, send: true }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Send failed");

      toast.success(`Newsletter sent to ${data.sentCount} subscribers`);
      setSubject("");
      setBody("");
      onRefresh();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Send failed");
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="rounded-xl border bg-card p-4">
        <div className="flex items-center gap-2">
          <Users className="h-5 w-5 text-primary" />
          <span className="text-sm font-semibold">
            {subscriberCount} active subscriber{subscriberCount !== 1 ? "s" : ""}
          </span>
        </div>
      </div>

      <div className="rounded-xl border bg-card p-6">
        <h2 className="mb-4 font-serif text-xl font-bold">Send Newsletter</h2>

        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="nl-subject">Subject</Label>
            <Input
              id="nl-subject"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              placeholder="Newsletter subject line…"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="nl-body">Email Body (HTML)</Label>
            <Textarea
              id="nl-body"
              value={body}
              onChange={(e) => setBody(e.target.value)}
              placeholder="<h2>Latest from SportX India</h2><p>Check out our new articles…</p>"
              className="min-h-[200px] font-mono text-sm"
            />
          </div>

          <div className="flex justify-end">
            <Button onClick={handleSend} disabled={sending || !subject || !body} className="gap-1.5">
              {sending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
              {sending ? "Sending…" : `Send to ${subscriberCount} subscribers`}
            </Button>
          </div>
        </div>
      </div>

      <div>
        <h3 className="mb-3 text-sm font-semibold">Past Campaigns</h3>
        {campaigns.length === 0 ? (
          <p className="text-sm text-muted-foreground">No campaigns sent yet.</p>
        ) : (
          <div className="space-y-2">
            {campaigns.map((c) => (
              <div key={c.id} className="flex items-center gap-3 rounded-lg border bg-card p-3">
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="truncate text-sm font-medium">{c.subject}</span>
                    <Badge variant={c.status === "sent" ? "default" : "secondary"} className="text-[10px]">
                      {c.status}
                    </Badge>
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {c.sentAt
                      ? `Sent ${format(new Date(c.sentAt), "d MMM yyyy")} · ${c.sentCount} recipients`
                      : `Created ${format(new Date(c.createdAt), "d MMM yyyy")}`}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="rounded-xl border bg-amber-50 p-4 text-sm dark:bg-amber-950/20">
        <p className="font-semibold">Email delivery setup:</p>
        <p className="mt-1 text-muted-foreground">
          To actually send emails, create a free account at{" "}
          <a href="https://resend.com" target="_blank" rel="noopener noreferrer" className="text-primary underline">resend.com</a>{" "}
          (3,000 emails/month free) and set the <code className="rounded bg-muted px-1 font-mono">RESEND_API_KEY</code> environment variable on Vercel.
          Without it, campaigns are recorded but not delivered.
        </p>
      </div>
    </div>
  );
}
