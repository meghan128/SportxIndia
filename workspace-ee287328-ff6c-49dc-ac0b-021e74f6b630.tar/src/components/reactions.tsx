"use client";

import { useEffect, useState, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Heart, MessageCircle, Share2 } from "lucide-react";
import { toast } from "sonner";

const STORAGE_PREFIX = "sportx-reactions-";

type ReactionState = {
  claps: number;
  userClapped: boolean;
};

/**
 * useReactions — hook for tracking article claps/likes.
 * Uses localStorage to persist the user's clap count per article.
 * Base reaction counts are derived from post views + a deterministic offset
 * so the UI feels alive without needing a backend.
 */
export function useReactions(slug: string | null, baseViews: number) {
  const [reactions, setReactions] = useState<ReactionState>({
    claps: 0,
    userClapped: false,
  });

  useEffect(() => {
    if (!slug) {
      let raf = requestAnimationFrame(() =>
        setReactions({ claps: 0, userClapped: false })
      );
      return () => cancelAnimationFrame(raf);
    }
    let raf = requestAnimationFrame(() => {
      try {
        // Base claps = views + deterministic multiplier (so it looks organic)
        const baseClaps = Math.floor(baseViews * 0.7) + hashClaps(slug);
        const raw = localStorage.getItem(STORAGE_PREFIX + slug);
        const userClaps = raw ? parseInt(raw, 10) : 0;
        setReactions({
          claps: baseClaps + userClaps,
          userClapped: userClaps > 0,
        });
      } catch {
        setReactions({ claps: 0, userClapped: false });
      }
    });
    return () => cancelAnimationFrame(raf);
  }, [slug, baseViews]);

  const clap = useCallback(() => {
    if (!slug) return;
    setReactions((prev) => {
      const next = { claps: prev.claps + 1, userClapped: true };
      try {
        const raw = localStorage.getItem(STORAGE_PREFIX + slug);
        const userClaps = raw ? parseInt(raw, 10) : 0;
        localStorage.setItem(STORAGE_PREFIX + slug, String(userClaps + 1));
      } catch {
        // ignore
      }
      return next;
    });
  }, [slug]);

  return { reactions, clap };
}

// Deterministic hash for base clap count (so each article has a stable number)
function hashClaps(slug: string): number {
  let h = 0;
  for (let i = 0; i < slug.length; i++) {
    h = (h << 5) - h + slug.charCodeAt(i);
    h |= 0;
  }
  return Math.abs(h) % 50 + 10; // 10-59 base claps
}

/**
 * ReactionBar — floating reaction bar for the article reader.
 * Shows clap (heart), comment count, and share buttons with animated
 * burst on clap.
 */
export function ReactionBar({
  slug,
  baseViews,
  commentCount,
  onOpenComments,
  onShare,
}: {
  slug: string;
  baseViews: number;
  commentCount: number;
  onOpenComments: () => void;
  onShare: () => void;
}) {
  const { reactions, clap } = useReactions(slug, baseViews);
  const [burst, setBurst] = useState(0);

  const handleClap = () => {
    clap();
    setBurst((b) => b + 1);
    toast.success("Thanks for the clap!", { duration: 1200 });
  };

  const fmtCount = (n: number) => {
    if (n >= 1000) return `${(n / 1000).toFixed(1)}k`;
    return String(n);
  };

  return (
    <div className="flex items-center gap-2">
      {/* Clap button */}
      <button
        onClick={handleClap}
        className="group relative flex items-center gap-1.5 rounded-full border bg-card px-3 py-1.5 text-sm font-medium transition-all hover:border-primary/40 hover:shadow-sm"
        aria-label="Clap for this article"
      >
        <motion.div
          key={burst}
          initial={{ scale: [1, 1.4, 1], rotate: [0, -10, 0] }}
          transition={{ duration: 0.4 }}
          className={reactions.userClapped ? "text-rose-500" : "text-muted-foreground group-hover:text-primary"}
        >
          <Heart
            className={`h-4 w-4 ${reactions.userClapped ? "fill-current" : ""}`}
          />
        </motion.div>
        <span className="tabular-nums">{fmtCount(reactions.claps)}</span>

        {/* Floating heart burst animation */}
        <AnimatePresence>
          {burst > 0 && (
            <motion.div
              key={burst}
              initial={{ opacity: 1, y: 0, scale: 0.5 }}
              animate={{ opacity: 0, y: -30, scale: 1.2 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.8 }}
              className="pointer-events-none absolute -top-2 left-1/2 -translate-x-1/2"
            >
              <Heart className="h-3 w-3 fill-rose-500 text-rose-500" />
            </motion.div>
          )}
        </AnimatePresence>
      </button>

      {/* Comment button */}
      <button
        onClick={onOpenComments}
        className="flex items-center gap-1.5 rounded-full border bg-card px-3 py-1.5 text-sm font-medium transition-all hover:border-primary/40 hover:shadow-sm"
        aria-label="View comments"
      >
        <MessageCircle className="h-4 w-4 text-muted-foreground" />
        <span className="tabular-nums">{commentCount}</span>
      </button>

      {/* Share button */}
      <button
        onClick={onShare}
        className="flex items-center gap-1.5 rounded-full border bg-card px-3 py-1.5 text-sm font-medium transition-all hover:border-primary/40 hover:shadow-sm"
        aria-label="Share article"
      >
        <Share2 className="h-4 w-4 text-muted-foreground" />
      </button>
    </div>
  );
}
