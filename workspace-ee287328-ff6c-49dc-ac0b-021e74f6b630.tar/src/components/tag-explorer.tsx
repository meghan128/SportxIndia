"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Hash, TrendingUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { CoverArt } from "@/components/cover-art";
import type { FilterData } from "@/lib/types";
import { format } from "date-fns";

type TagWithPosts = {
  slug: string;
  name: string;
  count: number;
  posts: {
    slug: string;
    title: string;
    excerpt: string | null;
    coverSeed: string;
    publishedAt: string;
    author: { displayName: string };
  }[];
};

export function TagExplorer({
  open,
  onOpenChange,
  filters,
  onSelectTag,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  filters: FilterData | null;
  onSelectTag: (slug: string) => void;
}) {
  const [selectedTag, setSelectedTag] = useState<string | null>(null);
  const [tagPosts, setTagPosts] = useState<TagWithPosts | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!selectedTag) return;
    let cancelled = false;
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setLoading(true);
    fetch(`/api/posts?tag=${selectedTag}&limit=6`)
      .then((r) => r.json())
      .then((d) => {
        if (cancelled) return;
        const tagInfo = filters?.tags.find((t) => t.slug === selectedTag);
        setTagPosts({
          slug: selectedTag,
          name: tagInfo?.name ?? selectedTag,
          count: tagInfo?.count ?? 0,
          posts: d.posts ?? [],
        });
      })
      .catch(() => {
        if (!cancelled) setTagPosts(null);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [selectedTag, filters]);

  const tags = filters?.tags ?? [];
  const maxCount = Math.max(...tags.map((t) => t.count), 1);

  // Font size scaled by popularity
  const tagSize = (count: number) => {
    const ratio = count / maxCount;
    if (ratio > 0.75) return "text-base";
    if (ratio > 0.5) return "text-sm";
    if (ratio > 0.25) return "text-xs";
    return "text-[11px]";
  };

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="fixed inset-0 z-50 flex items-stretch justify-center bg-black/70 backdrop-blur-sm sm:items-center sm:p-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={() => onOpenChange(false)}
        >
          <motion.div
            className="relative z-10 flex h-full w-full max-w-3xl flex-col bg-card shadow-2xl sm:h-auto sm:max-h-[90vh] sm:rounded-2xl overflow-hidden border"
            initial={{ y: 30, opacity: 0, scale: 0.98 }}
            animate={{ y: 0, opacity: 1, scale: 1 }}
            exit={{ y: 30, opacity: 0, scale: 0.98 }}
            transition={{ type: "spring", stiffness: 260, damping: 28 }}
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="relative overflow-hidden border-b bg-gradient-to-r from-primary/10 via-card to-emerald-500/10 p-5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10 text-primary">
                    <Hash className="h-5 w-5" />
                  </div>
                  <div>
                    <h2 className="font-serif text-xl font-bold">Explore by tag</h2>
                    <p className="text-xs text-muted-foreground">
                      {tags.length} tags · browse articles by topic
                    </p>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8"
                  onClick={() => onOpenChange(false)}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </div>

            <ScrollArea className="flex-1 min-h-0 scroll-area-thin">
              <div className="p-5">
                {/* Tag cloud */}
                {!selectedTag && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="flex flex-wrap gap-2"
                  >
                    {tags.map((t, i) => (
                      <motion.button
                        key={t.slug}
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: i * 0.02 }}
                        onClick={() => setSelectedTag(t.slug)}
                        className={`group inline-flex items-center gap-1.5 rounded-full border border-border bg-card px-3 py-1.5 font-medium transition-all hover:border-primary/50 hover:bg-primary/5 hover:shadow-sm ${tagSize(
                          t.count
                        )}`}
                      >
                        <span className="text-primary/60 group-hover:text-primary">#</span>
                        <span className="group-hover:text-primary">{t.name}</span>
                        <span className="rounded-full bg-muted px-1.5 py-0.5 text-[9px] tabular-nums text-muted-foreground group-hover:bg-primary/10 group-hover:text-primary">
                          {t.count}
                        </span>
                      </motion.button>
                    ))}
                  </motion.div>
                )}

                {/* Tag posts */}
                {selectedTag && (
                  <div>
                    <button
                      onClick={() => setSelectedTag(null)}
                      className="mb-4 flex items-center gap-1.5 text-sm text-muted-foreground transition-colors hover:text-primary"
                    >
                      <X className="h-3.5 w-3.5" />
                      Back to all tags
                    </button>
                    <div className="mb-4 flex items-center gap-2">
                      <Hash className="h-5 w-5 text-primary" />
                      <h3 className="font-serif text-lg font-bold">
                        {tagPosts?.name ?? selectedTag}
                      </h3>
                      {tagPosts && (
                        <Badge variant="secondary" className="text-xs">
                          {tagPosts.count} articles
                        </Badge>
                      )}
                    </div>

                    {loading ? (
                      <div className="space-y-3">
                        {Array.from({ length: 4 }).map((_, i) => (
                          <div
                            key={i}
                            className="h-20 animate-pulse rounded-xl bg-muted"
                          />
                        ))}
                      </div>
                    ) : tagPosts && tagPosts.posts.length > 0 ? (
                      <div className="space-y-2">
                        {tagPosts.posts.map((p, i) => (
                          <motion.button
                            key={p.slug}
                            initial={{ opacity: 0, x: 12 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: i * 0.05 }}
                            onClick={() => {
                              onOpenChange(false);
                              onSelectTag(p.slug);
                            }}
                            className="group flex w-full gap-3 rounded-xl border bg-card p-3 text-left transition-all hover:border-primary/40 hover:shadow-sm"
                          >
                            <CoverArt
                              seed={p.coverSeed}
                              title={p.title}
                              className="h-16 w-16 shrink-0 rounded-lg"
                              size="sm"
                            />
                            <div className="flex min-w-0 flex-1 flex-col">
                              <h4 className="line-clamp-2 text-sm font-semibold leading-snug transition-colors group-hover:text-primary">
                                {p.title}
                              </h4>
                              {p.excerpt && (
                                <p className="mt-0.5 line-clamp-1 text-[11px] text-muted-foreground">
                                  {p.excerpt}
                                </p>
                              )}
                              <div className="mt-auto flex items-center gap-2 pt-1 text-[10px] text-muted-foreground">
                                <span>{p.author.displayName.split(" ")[0]}</span>
                                <span>·</span>
                                <span>{format(new Date(p.publishedAt), "d MMM yyyy")}</span>
                              </div>
                            </div>
                          </motion.button>
                        ))}
                        <Button
                          variant="outline"
                          size="sm"
                          className="mt-3 w-full"
                          onClick={() => {
                            onOpenChange(false);
                            onSelectTag(selectedTag);
                          }}
                        >
                          View all articles with #{tagPosts.name}
                          <TrendingUp className="ml-1.5 h-3.5 w-3.5" />
                        </Button>
                      </div>
                    ) : (
                      <p className="py-8 text-center text-sm text-muted-foreground">
                        No articles found for this tag.
                      </p>
                    )}
                  </div>
                )}
              </div>
            </ScrollArea>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
