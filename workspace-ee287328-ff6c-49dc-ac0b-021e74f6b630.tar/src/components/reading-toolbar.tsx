"use client";

import { useEffect, useState, useRef, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Volume2,
  VolumeX,
  Pause,
  Play,
  Type,
  Maximize2,
  Minimize2,
  RotateCcw,
  ChevronUp,
  ChevronDown,
  X,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

type SpeakState = "idle" | "playing" | "paused";

/**
 * ReadingToolbar — a floating toolbar for the article reader with:
 * - Text-to-Speech (read aloud) using the Web Speech API
 * - Font size control (A- / A+ / reset)
 * - Focus mode (distraction-free reading)
 *
 * The toolbar is positioned at the bottom-center of the article reader modal.
 */
export function ReadingToolbar({
  articleRef,
  scrollRef,
  slug,
  onFontSizeChange,
  onFocusModeChange,
}: {
  articleRef: React.RefObject<HTMLElement | null>;
  scrollRef: React.RefObject<HTMLElement | null>;
  slug: string | null;
  onFontSizeChange?: (size: number) => void;
  onFocusModeChange?: (focused: boolean) => void;
}) {
  const [speakState, setSpeakState] = useState<SpeakState>("idle");
  const [fontSize, setFontSize] = useState(1); // 1 = 100% (1rem)
  const [focusMode, setFocusMode] = useState(false);
  const [supported, setSupported] = useState(false);
  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);

  // Check TTS support — defer setState via rAF to avoid lint rule
  useEffect(() => {
    let raf = requestAnimationFrame(() =>
      setSupported(typeof window !== "undefined" && "speechSynthesis" in window)
    );
    return () => cancelAnimationFrame(raf);
  }, []);

  // Apply font size to article
  useEffect(() => {
    if (!articleRef.current) return;
    const baseSize = 1.075; // matches article-prose base
    articleRef.current.style.fontSize = `${baseSize * fontSize}rem`;
    onFontSizeChange?.(fontSize);
  }, [fontSize, articleRef, onFontSizeChange]);

  // Cleanup TTS on unmount
  useEffect(() => {
    return () => {
      if (typeof window !== "undefined" && "speechSynthesis" in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  // Stop speaking callback (declared early so the article-change effect can use it)
  const stopSpeaking = useCallback(() => {
    if (!supported) return;
    window.speechSynthesis.cancel();
    setSpeakState("idle");
  }, [supported]);

  // Stop TTS when article changes — defer to avoid lint rule
  useEffect(() => {
    let raf = requestAnimationFrame(() => stopSpeaking());
    return () => cancelAnimationFrame(raf);
  }, [slug, stopSpeaking]);

  const getArticleText = useCallback(() => {
    if (!articleRef.current) return "";
    const clone = articleRef.current.cloneNode(true) as HTMLElement;
    // Remove TOC and other non-content elements
    clone.querySelectorAll("script, style, .table-of-contents, button").forEach((el) => el.remove());
    return clone.textContent?.trim() ?? "";
  }, [articleRef]);

  const startSpeaking = useCallback(() => {
    if (!supported) {
      toast.error("Text-to-speech is not supported in this browser.");
      return;
    }
    const text = getArticleText();
    if (!text) {
      toast.error("No text found to read.");
      return;
    }

    // Cancel any ongoing speech
    window.speechSynthesis.cancel();

    // Truncate to a reasonable length (Web Speech API has limits)
    const truncated = text.slice(0, 30000);
    const utterance = new SpeechSynthesisUtterance(truncated);
    utterance.rate = 1;
    utterance.pitch = 1;
    utterance.volume = 1;

    // Try to use a natural-sounding voice
    const voices = window.speechSynthesis.getVoices();
    const preferred =
      voices.find((v) => v.name.includes("Google") && v.lang.startsWith("en")) ||
      voices.find((v) => v.lang.startsWith("en"));
    if (preferred) utterance.voice = preferred;

    utterance.onstart = () => setSpeakState("playing");
    utterance.onend = () => setSpeakState("idle");
    utterance.onerror = () => {
      setSpeakState("idle");
      toast.error("Speech was interrupted.");
    };

    utteranceRef.current = utterance;
    window.speechSynthesis.speak(utterance);
    toast.success("Reading article aloud…", { duration: 2000 });
  }, [supported, getArticleText]);

  const pauseSpeaking = useCallback(() => {
    if (!supported) return;
    window.speechSynthesis.pause();
    setSpeakState("paused");
  }, [supported]);

  const resumeSpeaking = useCallback(() => {
    if (!supported) return;
    window.speechSynthesis.resume();
    setSpeakState("playing");
  }, [supported]);

  const toggleSpeak = () => {
    if (speakState === "idle") startSpeaking();
    else if (speakState === "playing") pauseSpeaking();
    else if (speakState === "paused") resumeSpeaking();
  };

  const increaseFont = () => setFontSize((s) => Math.min(1.5, s + 0.1));
  const decreaseFont = () => setFontSize((s) => Math.max(0.85, s - 0.1));
  const resetFont = () => setFontSize(1);

  const toggleFocus = () => {
    const next = !focusMode;
    setFocusMode(next);
    onFocusModeChange?.(next);
    if (next) toast.info("Focus mode on — distractions hidden. Press again to exit.");
  };

  if (!slug) return null;

  return (
    <motion.div
      initial={{ y: 60, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="absolute bottom-4 left-1/2 z-30 -translate-x-1/2"
    >
      <div className="flex items-center gap-1 rounded-full border bg-card/95 p-1.5 shadow-2xl backdrop-blur-md">
        {/* TTS button */}
        {supported && (
          <button
            onClick={toggleSpeak}
            className={`flex h-8 w-8 items-center justify-center rounded-full transition-colors ${
              speakState !== "idle"
                ? "bg-primary text-primary-foreground"
                : "hover:bg-muted"
            }`}
            title={
              speakState === "idle"
                ? "Read aloud"
                : speakState === "playing"
                  ? "Pause reading"
                  : "Resume reading"
            }
            aria-label={speakState === "idle" ? "Read aloud" : "Pause reading"}
          >
            {speakState === "playing" ? (
              <Pause className="h-4 w-4" />
            ) : speakState === "paused" ? (
              <Play className="h-4 w-4" />
            ) : (
              <Volume2 className="h-4 w-4" />
            )}
          </button>
        )}

        {/* Stop button (only when speaking) */}
        {speakState !== "idle" && (
          <button
            onClick={stopSpeaking}
            className="flex h-8 w-8 items-center justify-center rounded-full transition-colors hover:bg-muted"
            title="Stop reading"
            aria-label="Stop reading"
          >
            <VolumeX className="h-4 w-4" />
          </button>
        )}

        {/* Divider */}
        <div className="mx-0.5 h-5 w-px bg-border" />

        {/* Font size controls */}
        <button
          onClick={decreaseFont}
          className="flex h-8 w-8 items-center justify-center rounded-full transition-colors hover:bg-muted"
          title="Decrease font size"
          aria-label="Decrease font size"
          disabled={fontSize <= 0.85}
        >
          <ChevronDown className="h-4 w-4" />
        </button>
        <div className="flex h-8 items-center justify-center px-1 text-xs font-semibold tabular-nums text-muted-foreground">
          {Math.round(fontSize * 100)}%
        </div>
        <button
          onClick={increaseFont}
          className="flex h-8 w-8 items-center justify-center rounded-full transition-colors hover:bg-muted"
          title="Increase font size"
          aria-label="Increase font size"
          disabled={fontSize >= 1.5}
        >
          <ChevronUp className="h-4 w-4" />
        </button>
        {fontSize !== 1 && (
          <button
            onClick={resetFont}
            className="flex h-8 w-8 items-center justify-center rounded-full transition-colors hover:bg-muted"
            title="Reset font size"
            aria-label="Reset font size"
          >
            <RotateCcw className="h-3.5 w-3.5" />
          </button>
        )}

        {/* Divider */}
        <div className="mx-0.5 h-5 w-px bg-border" />

        {/* Focus mode toggle */}
        <button
          onClick={toggleFocus}
          className={`flex h-8 w-8 items-center justify-center rounded-full transition-colors ${
            focusMode ? "bg-primary text-primary-foreground" : "hover:bg-muted"
          }`}
          title={focusMode ? "Exit focus mode" : "Focus mode"}
          aria-label={focusMode ? "Exit focus mode" : "Focus mode"}
        >
          {focusMode ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
        </button>
      </div>
    </motion.div>
  );
}
