"use client";

import { motion } from "framer-motion";

/**
 * Shimmer skeleton loader for article cards — uses a sweeping gradient
 * animation to indicate loading state. More premium than a static skeleton.
 */
export function CardSkeleton() {
  return (
    <div className="flex h-full w-full flex-col overflow-hidden rounded-xl border bg-card">
      <ShimmerBox className="h-44 w-full" />
      <div className="flex flex-1 flex-col p-4">
        <div className="flex items-center gap-1.5">
          <ShimmerBox className="h-4 w-16 rounded" />
          <ShimmerBox className="h-3 w-20 rounded" />
        </div>
        <ShimmerBox className="mt-2 h-4 w-full rounded" />
        <ShimmerBox className="mt-1.5 h-4 w-3/4 rounded" />
        <ShimmerBox className="mt-1.5 h-3 w-full rounded" />
        <div className="mt-auto flex items-center justify-between pt-3">
          <div className="flex items-center gap-1.5">
            <ShimmerBox className="h-5 w-5 rounded-full" />
            <ShimmerBox className="h-3 w-16 rounded" />
          </div>
          <ShimmerBox className="h-3 w-12 rounded" />
        </div>
      </div>
    </div>
  );
}

export function CardSkeletonGrid({ count = 6 }: { count?: number }) {
  return (
    <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
      {Array.from({ length: count }).map((_, i) => (
        <motion.div
          key={i}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: i * 0.05 }}
        >
          <CardSkeleton />
        </motion.div>
      ))}
    </div>
  );
}

export function HeroSkeleton() {
  return (
    <section className="border-b bg-gradient-to-br from-primary/5 via-card to-background">
      <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">
          <ShimmerBox className="h-96 w-full rounded-2xl lg:col-span-2 lg:row-span-2" />
          <ShimmerBox className="h-32 w-full rounded-2xl" />
          <ShimmerBox className="h-32 w-full rounded-2xl" />
        </div>
      </div>
    </section>
  );
}

function ShimmerBox({ className }: { className?: string }) {
  return (
    <div className={`relative overflow-hidden rounded-md bg-muted ${className ?? ""}`}>
      <motion.div
        className="absolute inset-0"
        style={{
          background:
            "linear-gradient(90deg, transparent, var(--background), transparent)",
        }}
        animate={{
          x: ["-100%", "200%"],
        }}
        transition={{
          duration: 1.5,
          repeat: Infinity,
          ease: "linear",
        }}
      />
    </div>
  );
}
