"use client";

import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  X,
  ShieldCheck,
  Clock,
  Eye,
  AlertTriangle,
  Flag,
  Share2,
  Link2,
  CheckCircle2,
  Fingerprint,
  ChevronRight,
  Loader2,
  ScanLine,
  Sparkles,
  UserCircle,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { CoverArt } from "@/components/cover-art";
import { ReportContentDialog } from "@/components/report-content-dialog";
import { ReadingProgress } from "@/components/reading-progress";
import { RelatedArticles } from "@/components/related-articles";
import { NewsletterSignup } from "@/components/newsletter-signup";
import { TableOfContents } from "@/components/table-of-contents";
import { BookmarkButton } from "@/components/bookmarks";
import { ShareMenu } from "@/components/share-menu";
import { ReadingToolbar } from "@/components/reading-toolbar";
import { useReadingPosition } from "@/components/use-reading-position";
import { ReadingTimeProgress } from "@/components/reading-time-progress";
import {
  useHighlights,
  SelectionPopover,
  HighlightsPanel,
  FloatingHighlightButton,
  restoreHighlights,
} from "@/components/text-highlights";
import { ReactionBar } from "@/components/reactions";
import { CommentsPanel, useComments } from "@/components/comments";
import { AdZone } from "@/components/ad-zone";
import type { PostDetail } from "@/lib/types";
import { format } from "date-fns";
import { toast } from "sonner";

export function ArticleReader({
  post,
  onClose,
  onOpenRelated,
  onOpenAuthor,
  isBookmarked,
  onToggleBookmark,
}: {
  post: PostDetail | null;
  onClose: () => void;
  onOpenRelated: (slug: string) => void;
  onOpenAuthor: (login: string) => void;
  isBookmarked: boolean;
  onToggleBookmark: () => void;
}) {
  const [showReport, setShowReport] = useState(false);
  const [copied, setCopied] = useState(false);
  const [verifying, setVerifying] = useState(false);
  const [verified, setVerified] = useState<null | { ok: boolean; hash: string }>(null);
  const [focusMode, setFocusMode] = useState(false);
  const [highlightsOpen, setHighlightsOpen] = useState(false);
  const [commentsOpen, setCommentsOpen] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const articleRef = useRef<HTMLElement>(null);
  useReadingPosition(post?.slug ?? null, scrollRef);
  const {
    highlights,
    activeColor,
    setActiveColor,
    addHighlight,
    removeHighlight,
    clearAll: clearHighlights,
  } = useHighlights(post?.slug ?? null);
  const { comments, addComment, toggleLike, deleteComment } = useComments(
    post?.slug ?? null
  );

  // Restore highlights to the article DOM when they load
  useEffect(() => {
    if (!post || highlights.length === 0 || !articleRef.current) return;
    // Wait for the DOM to settle
    let raf = requestAnimationFrame(() => {
      if (articleRef.current) {
        restoreHighlights(articleRef.current, highlights);
      }
    });
    return () => cancelAnimationFrame(raf);
  }, [post, highlights]);

  // Listen for highlight-removal clicks from restored marks
  useEffect(() => {
    const onRemove = (e: Event) => {
      const id = (e as CustomEvent).detail as string;
      removeHighlight(id);
    };
    window.addEventListener("highlight-remove", onRemove);
    return () => window.removeEventListener("highlight-remove", onRemove);
  }, [removeHighlight]);

  useEffect(() => {
    setVerified(null);
    if (post) {
      document.body.style.overflow = "hidden";
      // increment view counter (fire and forget)
      fetch(`/api/posts/${post.slug}/view`, { method: "POST" }).catch(() => {});
    } else {
      document.body.style.overflow = "";
    }
    return () => {
      document.body.style.overflow = "";
    };
  }, [post]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape" && post) onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [post, onClose]);

  const handleCopyLink = () => {
    if (!post) return;
    const url = `${window.location.origin}/?article=${post.slug}`;
    navigator.clipboard.writeText(url).then(() => {
      setCopied(true);
      toast.success("Link copied — share the verified original.");
      setTimeout(() => setCopied(false), 2000);
    });
  };

  const handleShare = async () => {
    if (!post) return;
    const url = `${window.location.origin}/?article=${post.slug}`;
    if (navigator.share) {
      try {
        await navigator.share({ title: post.title, url });
      } catch {
        /* user cancelled */
      }
    } else {
      handleCopyLink();
    }
  };

  const handleVerify = async () => {
    if (!post) return;
    setVerifying(true);
    try {
      const res = await fetch(`/api/posts/${post.slug}/verify`);
      if (!res.ok) throw new Error("verify failed");
      const data = await res.json();
      setVerified({ ok: data.verified, hash: data.computedHash });
      if (data.verified) {
        toast.success("Integrity check passed — content matches the original fingerprint.");
      } else {
        toast.error("Integrity check FAILED — content has been modified.");
      }
    } catch {
      toast.error("Could not verify content integrity.");
    } finally {
      setVerifying(false);
    }
  };

  return (
    <>
      <AnimatePresence>
        {post && (
          <motion.div
            className="fixed inset-0 z-50 flex items-stretch justify-center bg-black/70 backdrop-blur-sm"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
          >
            <motion.div
              className={`relative z-10 mt-0 h-full w-full bg-card shadow-2xl sm:mt-6 sm:mb-6 sm:h-[calc(100vh-3rem)] sm:rounded-2xl overflow-hidden border transition-all duration-300 ${
                focusMode ? "max-w-2xl border-0 sm:my-0 sm:h-full" : "max-w-4xl"
              }`}
              initial={{ y: 30, opacity: 0, scale: 0.98 }}
              animate={{ y: 0, opacity: 1, scale: 1 }}
              exit={{ y: 30, opacity: 0, scale: 0.98 }}
              transition={{ type: "spring", stiffness: 260, damping: 28 }}
              onClick={(e) => e.stopPropagation()}
            >
              {/* Reading progress bar */}
              <ReadingProgress scrollRef={scrollRef} />

              {/* Header / cover — hidden in focus mode */}
              {!focusMode && (
              <div className="relative">
                <CoverArt
                  seed={post.coverSeed}
                  title={post.title}
                  className="h-44 w-full sm:h-56"
                  size="lg"
                />
                <Button
                  variant="secondary"
                  size="icon"
                  className="absolute right-3 top-3 h-9 w-9 rounded-full bg-black/40 text-white hover:bg-black/60 backdrop-blur-sm"
                  onClick={onClose}
                  aria-label="Close article"
                >
                  <X className="h-5 w-5" />
                </Button>
                <div className="absolute left-4 bottom-4 flex flex-wrap gap-2">
                  {post.categories.map((c) => (
                    <Badge
                      key={c.slug}
                      className="bg-black/40 text-white backdrop-blur-sm hover:bg-black/50"
                    >
                      {c.name}
                    </Badge>
                  ))}
                </div>
              </div>
              )}

              {/* Body */}
              <div className={`flex min-h-0 flex-col ${focusMode ? "h-full" : "h-[calc(100%-11rem)] sm:h-[calc(100%-14rem)]"}`}>
                <ScrollArea ref={scrollRef} className="min-h-0 flex-1 scroll-area-thin">
                  <div className="mx-auto max-w-2xl px-5 py-6 sm:px-8 sm:py-8">
                    <h1 className="font-serif text-3xl font-bold leading-tight tracking-tight sm:text-4xl">
                      {post.title}
                    </h1>

                    {/* Byline */}
                    <div className="mt-4 flex flex-wrap items-center gap-x-4 gap-y-2 text-sm text-muted-foreground">
                      <button
                        onClick={() => onOpenAuthor(post.author.login)}
                        className="flex items-center gap-2 rounded-lg p-0.5 pr-2 transition-colors hover:bg-muted"
                      >
                        <span className="flex h-7 w-7 items-center justify-center rounded-full bg-primary/10 font-semibold text-primary">
                          {post.author.displayName.slice(0, 1)}
                        </span>
                        <span className="font-medium text-foreground">
                          {post.author.displayName}
                        </span>
                        <UserCircle className="h-3.5 w-3.5 text-muted-foreground" />
                      </button>
                      <span className="flex items-center gap-1">
                        <Clock className="h-3.5 w-3.5" />
                        {format(new Date(post.publishedAt), "d MMM yyyy")}
                      </span>
                      <span className="flex items-center gap-1">
                        <Eye className="h-3.5 w-3.5" />
                        {post.views.toLocaleString()} views
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="h-3.5 w-3.5" />
                        {post.readMinutes} min read
                      </span>
                    </div>

                    {/* Integrity badge */}
                    <div className="mt-5 flex flex-col gap-3 rounded-xl border bg-accent/40 p-4">
                      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                        <div className="flex items-start gap-3">
                          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-accent text-accent-foreground">
                            <ShieldCheck className="h-5 w-5" />
                          </div>
                          <div className="text-sm">
                            <p className="font-semibold text-foreground">
                              Verified Original Content
                            </p>
                            <p className="text-muted-foreground">
                              This article is a SportX India original. Content fingerprint:
                            </p>
                            <code className="mt-1 block break-all font-mono text-[11px] text-accent-foreground/80">
                              sha256:{post.contentHash.slice(0, 24)}…
                            </code>
                          </div>
                        </div>
                        <Button
                          variant="outline"
                          size="sm"
                          className="shrink-0"
                          onClick={() => setShowReport(true)}
                        >
                          <Flag className="mr-1.5 h-3.5 w-3.5" />
                          Report stolen copy
                        </Button>
                      </div>
                      {/* Verify-now row */}
                      <div className="flex flex-wrap items-center gap-2 border-t pt-3">
                        <Button
                          variant="secondary"
                          size="sm"
                          onClick={handleVerify}
                          disabled={verifying}
                        >
                          {verifying ? (
                            <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" />
                          ) : (
                            <ScanLine className="mr-1.5 h-3.5 w-3.5" />
                          )}
                          {verifying ? "Verifying…" : "Verify integrity now"}
                        </Button>
                        {verified && (
                          <span
                            className={`flex items-center gap-1 text-xs font-medium ${
                              verified.ok ? "text-emerald-600" : "text-destructive"
                            }`}
                          >
                            {verified.ok ? (
                              <CheckCircle2 className="h-3.5 w-3.5" />
                            ) : (
                              <AlertTriangle className="h-3.5 w-3.5" />
                            )}
                            {verified.ok ? "Content intact — matches fingerprint" : "MISMATCH — content tampered"}
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Excerpt */}
                    {post.excerpt && (
                      <p className="mt-6 border-l-4 border-primary/50 pl-4 text-lg font-medium italic leading-relaxed text-muted-foreground">
                        {post.excerpt}
                      </p>
                    )}

                    {/* Table of contents */}
                    <TableOfContents articleRef={articleRef} scrollRef={scrollRef} />

                    {/* Article body */}
                    <article
                      ref={articleRef}
                      className="article-prose mt-6"
                      onContextMenu={(e) => {
                        // gentle anti-scrape nudge — does not block, but signals
                        e.preventDefault();
                        toast.info(
                          "SportX India content is protected. Please credit the source if quoting.",
                          { duration: 3500 }
                        );
                      }}
                      dangerouslySetInnerHTML={{ __html: post.content }}
                    />

                    {/* In-article ad zone */}
                    <AdZone slot="in-article" className="my-6 min-h-[120px] rounded-xl border" />

                    {/* Tags */}
                    {post.tags.length > 0 && (
                      <div className="mt-8 flex flex-wrap gap-2">
                        {post.tags.map((t) => (
                          <Badge key={t.slug} variant="secondary" className="font-normal">
                            #{t.name}
                          </Badge>
                        ))}
                      </div>
                    )}

                    <Separator className="my-8" />

                    {/* Footer notice */}
                    <div className="rounded-xl border border-dashed bg-muted/40 p-5 text-sm">
                      <div className="mb-2 flex items-center gap-2 font-semibold">
                        <Fingerprint className="h-4 w-4 text-primary" />
                        Content protection notice
                      </div>
                      <p className="text-muted-foreground">
                        This article was originally published on SportX India
                        on {format(new Date(post.publishedAt), "d MMMM yyyy")} by{" "}
                        {post.author.displayName}. Unauthorized reproduction on
                        other websites is a violation of our content license.
                        If you found this article on another site, please{" "}
                        <button
                          className="font-medium text-primary underline underline-offset-2"
                          onClick={() => setShowReport(true)}
                        >
                          report it here
                        </button>
                        .
                      </p>
                      <p className="mt-3 flex items-center gap-1.5 text-xs text-muted-foreground">
                        <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600" />
                        Integrity verified · Canonical source · SHA-256 signed
                      </p>
                    </div>

                    {/* Reaction bar (claps, comments, share) */}
                    {post && (
                      <div className="mt-6 flex items-center gap-3 border-y py-3">
                        <ReactionBar
                          slug={post.slug}
                          baseViews={post.views}
                          commentCount={comments.length}
                          onOpenComments={() => setCommentsOpen(true)}
                          onShare={() => toast.info("Use the share icons below", { duration: 1500 })}
                        />
                        <span className="ml-auto text-xs text-muted-foreground">
                          {post.views.toLocaleString()} views
                        </span>
                      </div>
                    )}

                    {/* Share row */}
                    <div className="mt-6 flex flex-wrap items-center gap-3">
                      {post && (
                        <ShareMenu slug={post.slug} title={post.title} />
                      )}
                      {post && (
                        <BookmarkButton
                          slug={post.slug}
                          title={post.title}
                          excerpt={post.excerpt}
                          coverSeed={post.coverSeed}
                          author={post.author}
                          publishedAt={post.publishedAt}
                          readMinutes={post.readMinutes}
                          isBookmarked={isBookmarked}
                          onToggle={onToggleBookmark}
                        />
                      )}
                      <span className="ml-auto flex items-center gap-1 text-xs text-muted-foreground">
                        Read more
                        <ChevronRight className="h-3 w-3" />
                      </span>
                    </div>

                    {/* Related articles */}
                    <RelatedArticles slug={post.slug} onOpen={onOpenRelated} />

                    {/* Newsletter inline */}
                    <div className="mt-8">
                      <NewsletterSignup variant="inline" />
                    </div>

                    {/* Back-to-top hint */}
                    <div className="mt-8 mb-4 text-center text-xs text-muted-foreground">
                      <Sparkles className="mr-1 inline h-3 w-3 text-primary" />
                      That&apos;s the end of this story — press{" "}
                      <kbd className="rounded border bg-muted px-1 font-mono">Esc</kbd>{" "}
                      to close.
                    </div>
                  </div>
                </ScrollArea>
              </div>

              {/* Reading toolbar (TTS, font size, focus mode) */}
              {post && (
                <ReadingToolbar
                  articleRef={articleRef}
                  scrollRef={scrollRef}
                  slug={post.slug}
                  onFocusModeChange={setFocusMode}
                />
              )}

              {/* Focus mode overlay hint */}
              <AnimatePresence>
                {focusMode && (
                  <motion.button
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    onClick={() => setFocusMode(false)}
                    className="absolute right-3 top-3 z-30 flex items-center gap-1.5 rounded-full bg-black/60 px-3 py-1.5 text-xs text-white backdrop-blur-md transition-colors hover:bg-black/80"
                  >
                    Exit focus mode
                    <kbd className="rounded bg-white/20 px-1 font-mono text-[10px]">Esc</kbd>
                  </motion.button>
                )}
              </AnimatePresence>

              {/* Reading time progress badge (top-center) */}
              {post && !focusMode && (
                <ReadingTimeProgress
                  scrollRef={scrollRef}
                  readMinutes={post.readMinutes}
                  visible={!!post}
                />
              )}

              {/* Floating highlights button (top-right, below close) */}
              {post && !focusMode && (
                <div className="absolute right-3 top-14 z-30">
                  <FloatingHighlightButton
                    count={highlights.length}
                    onClick={() => setHighlightsOpen(true)}
                  />
                </div>
              )}

              {/* Text selection popover for highlighting */}
              {post && (
                <SelectionPopover
                  targetRef={scrollRef}
                  onHighlight={(text, color) => addHighlight(text, color)}
                  activeColor={activeColor}
                  onColorChange={setActiveColor}
                />
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Highlights panel */}
      <HighlightsPanel
        open={highlightsOpen}
        onOpenChange={setHighlightsOpen}
        highlights={highlights}
        onRemove={removeHighlight}
        onClear={clearHighlights}
        onJumpTo={() => {
          setHighlightsOpen(false);
          toast.info("Jumping to highlight…", { duration: 1200 });
        }}
      />

      {/* Comments panel */}
      <CommentsPanel
        open={commentsOpen}
        onOpenChange={setCommentsOpen}
        slug={post?.slug ?? null}
        comments={comments}
        onAdd={addComment}
        onLike={toggleLike}
        onDelete={deleteComment}
      />

      <ReportContentDialog
        open={showReport}
        onOpenChange={setShowReport}
        postId={post?.id ?? null}
        postTitle={post?.title ?? null}
      />
    </>
  );
}
