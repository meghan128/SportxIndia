"use client";

import { useEffect, useState, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  X,
  ChevronRight,
  ChevronLeft,
  Sparkles,
  ShieldCheck,
  Bookmark,
  Command,
  BarChart3,
  Rocket,
  CheckCircle2,
} from "lucide-react";
import { Button } from "@/components/ui/button";

const STORAGE_KEY = "sportx-onboarding-completed";

type Step = {
  id: string;
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  description: string;
  accent: string;
};

const STEPS: Step[] = [
  {
    id: "welcome",
    icon: Sparkles,
    title: "Welcome to SportX India",
    description:
      "All About Sport — memoirs, editorials, and the science behind the game. Every article is a verified original, protected by SHA-256 fingerprints.",
    accent: "from-primary to-amber-600",
  },
  {
    id: "security",
    icon: ShieldCheck,
    title: "Content-Integrity Protected",
    description:
      "We auto-moderate every post and quarantine suspicious content. The 'Security Center' (top-right shield button) shows moderation queue, incidents, and lets you report stolen content.",
    accent: "from-emerald-600 to-primary",
  },
  {
    id: "command",
    icon: Command,
    title: "Quick Navigation",
    description:
      "Press ⌘K (or Ctrl+K) anytime to open the command palette — search articles, jump to categories, switch themes, and more. Press ? for all keyboard shortcuts.",
    accent: "from-violet-600 to-primary",
  },
  {
    id: "reading",
    icon: BarChart3,
    title: "Track Your Reading",
    description:
      "Open articles to build your reading stats — streaks, achievements, and a 7-day activity chart. Bookmark articles for later with the bookmark icon.",
    accent: "from-primary to-rose-600",
  },
  {
    id: "explore",
    icon: Rocket,
    title: "Explore & Enjoy",
    description:
      "Browse the archive by date, explore tags, follow your favorite authors, and use text-to-speech in the article reader. Happy reading!",
    accent: "from-amber-600 to-emerald-600",
  },
];

export function OnboardingTour() {
  const [open, setOpen] = useState(false);
  const [step, setStep] = useState(0);

  useEffect(() => {
    try {
      const completed = localStorage.getItem(STORAGE_KEY);
      if (!completed) {
        // Small delay so the page loads first
        const t = setTimeout(() => setOpen(true), 1200);
        return () => clearTimeout(t);
      }
    } catch {
      // ignore
    }
  }, []);

  const close = useCallback(() => {
    setOpen(false);
    try {
      localStorage.setItem(STORAGE_KEY, "1");
    } catch {
      // ignore
    }
  }, []);

  const next = () => {
    if (step < STEPS.length - 1) setStep((s) => s + 1);
    else close();
  };

  const prev = () => {
    if (step > 0) setStep((s) => s - 1);
  };

  const skip = () => close();

  const current = STEPS[step];
  const Icon = current.icon;
  const isLast = step === STEPS.length - 1;

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="fixed inset-0 z-[90] flex items-center justify-center bg-black/60 backdrop-blur-sm p-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={skip}
        >
          <motion.div
            className="relative w-full max-w-md overflow-hidden rounded-2xl border bg-card shadow-2xl"
            initial={{ scale: 0.95, y: 20, opacity: 0 }}
            animate={{ scale: 1, y: 0, opacity: 1 }}
            exit={{ scale: 0.95, y: 20, opacity: 0 }}
            transition={{ type: "spring", stiffness: 300, damping: 25 }}
            onClick={(e) => e.stopPropagation()}
          >
            {/* Gradient header */}
            <div className={`relative h-32 bg-gradient-to-br ${current.accent}`}>
              <div
                className="absolute inset-0 opacity-20"
                style={{
                  backgroundImage:
                    "radial-gradient(circle at 30% 30%, white 1px, transparent 1px), radial-gradient(circle at 70% 60%, white 1px, transparent 1px)",
                  backgroundSize: "20px 20px",
                }}
              />
              <button
                onClick={skip}
                className="absolute right-3 top-3 flex h-8 w-8 items-center justify-center rounded-full bg-black/20 text-white backdrop-blur-sm transition-colors hover:bg-black/40"
                aria-label="Skip tour"
              >
                <X className="h-4 w-4" />
              </button>
              <div className="absolute -bottom-6 left-1/2 -translate-x-1/2">
                <div className="flex h-14 w-14 items-center justify-center rounded-2xl border-4 border-card bg-card shadow-lg">
                  <div className={`flex h-full w-full items-center justify-center rounded-xl bg-gradient-to-br ${current.accent} text-white`}>
                    <Icon className="h-6 w-6" />
                  </div>
                </div>
              </div>
            </div>

            {/* Body */}
            <div className="px-6 pb-6 pt-10 text-center">
              <h2 className="font-serif text-xl font-bold tracking-tight">
                {current.title}
              </h2>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                {current.description}
              </p>

              {/* Progress dots */}
              <div className="mt-5 flex items-center justify-center gap-1.5">
                {STEPS.map((s, i) => (
                  <button
                    key={s.id}
                    onClick={() => setStep(i)}
                    className={`h-1.5 rounded-full transition-all ${
                      i === step
                        ? "w-6 bg-primary"
                        : "w-1.5 bg-muted-foreground/30 hover:bg-muted-foreground/50"
                    }`}
                    aria-label={`Go to step ${i + 1}`}
                  />
                ))}
              </div>

              {/* Actions */}
              <div className="mt-6 flex items-center justify-between gap-3">
                <button
                  onClick={skip}
                  className="text-xs text-muted-foreground transition-colors hover:text-foreground"
                >
                  Skip tour
                </button>
                <div className="flex items-center gap-2">
                  {step > 0 && (
                    <Button variant="ghost" size="sm" onClick={prev}>
                      <ChevronLeft className="h-4 w-4" />
                      Back
                    </Button>
                  )}
                  <Button size="sm" onClick={next}>
                    {isLast ? (
                      <>
                        <CheckCircle2 className="mr-1 h-4 w-4" />
                        Get started
                      </>
                    ) : (
                      <>
                        Next
                        <ChevronRight className="ml-1 h-4 w-4" />
                      </>
                    )}
                  </Button>
                </div>
              </div>

              {/* Step counter */}
              <div className="mt-3 text-[11px] text-muted-foreground">
                Step {step + 1} of {STEPS.length}
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
