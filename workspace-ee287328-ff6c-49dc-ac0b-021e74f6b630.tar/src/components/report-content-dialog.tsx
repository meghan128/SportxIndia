"use client";

import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { AlertTriangle, CheckCircle2, Loader2 } from "lucide-react";
import { toast } from "sonner";

export function ReportContentDialog({
  open,
  onOpenChange,
  postId,
  postTitle,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  postId: string | null;
  postTitle: string | null;
}) {
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);
  const [form, setForm] = useState({
    reporterName: "",
    reporterEmail: "",
    infringingUrl: "",
    description: "",
  });

  const reset = () => {
    setForm({ reporterName: "", reporterEmail: "", infringingUrl: "", description: "" });
    setDone(false);
  };

  const submit = async () => {
    if (!form.reporterName || !form.reporterEmail || !form.infringingUrl || !form.description) {
      toast.error("Please fill in all fields.");
      return;
    }
    setSubmitting(true);
    try {
      const res = await fetch("/api/reports", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, postId }),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || "Submission failed");
      }
      setDone(true);
      toast.success("Report filed. Our team will investigate the infringement.");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Submission failed");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog
      open={open}
      onOpenChange={(v) => {
        onOpenChange(v);
        if (!v) setTimeout(reset, 200);
      }}
    >
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
        {done ? (
          <div className="flex flex-col items-center py-8 text-center">
            <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-emerald-100 text-emerald-600">
              <CheckCircle2 className="h-7 w-7" />
            </div>
            <DialogTitle className="text-xl">Report received</DialogTitle>
            <DialogDescription className="mt-2 max-w-sm">
              Thank you for helping protect SportX India content. Our
              content-protection team will review the reported URL and take
              appropriate action under our DMCA policy.
            </DialogDescription>
            <Button className="mt-6" onClick={() => onOpenChange(false)}>
              Done
            </Button>
          </div>
        ) : (
          <>
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-primary" />
                Report stolen content
              </DialogTitle>
              <DialogDescription>
                Found this SportX India article republished on another site
                without permission? Tell us and we&apos;ll pursue takedown.
                {postTitle && (
                  <span className="mt-1 block font-medium text-foreground">
                    Reporting: “{postTitle.slice(0, 60)}{postTitle.length > 60 ? "…" : ""}”
                  </span>
                )}
              </DialogDescription>
            </DialogHeader>

            <div className="grid gap-4 py-2">
              <div className="grid gap-2">
                <Label htmlFor="rn">Your name</Label>
                <Input
                  id="rn"
                  value={form.reporterName}
                  onChange={(e) => setForm({ ...form, reporterName: e.target.value })}
                  placeholder="Jane Doe"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="re">Your email</Label>
                <Input
                  id="re"
                  type="email"
                  value={form.reporterEmail}
                  onChange={(e) => setForm({ ...form, reporterEmail: e.target.value })}
                  placeholder="jane@example.com"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="iu">Infringing URL</Label>
                <Input
                  id="iu"
                  value={form.infringingUrl}
                  onChange={(e) => setForm({ ...form, infringingUrl: e.target.value })}
                  placeholder="https://example-stolen-site.com/..."
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="d">Description</Label>
                <Textarea
                  id="d"
                  rows={4}
                  value={form.description}
                  onChange={(e) => setForm({ ...form, description: e.target.value })}
                  placeholder="Describe how the content is being used without authorization…"
                />
              </div>
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => onOpenChange(false)}>
                Cancel
              </Button>
              <Button onClick={submit} disabled={submitting}>
                {submitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Submit report
              </Button>
            </DialogFooter>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}
