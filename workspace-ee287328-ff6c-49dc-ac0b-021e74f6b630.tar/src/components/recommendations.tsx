"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Sparkles, ArrowRight, TrendingUp, Eye } from "lucide-react";
import { CoverArt } from "@/components/cover-art";
import type { PostSummary } from "@/lib/types";
import { format } from "date-fns";

/**
 * Recommendations — shows a "Because you read X" section on the homepage
 * based on the user's reading history (from localStorage). Falls back to
 * "Editor's picks" or "Trending" when no history exists.
 *
 * Uses the reading history stored by the reading-history component to find
 * the most-read category, then fetches articles from that category the user
 * hasn't read yet.
 */
export function Recommendations({
  history,
  onOpen,
  excludeSlugs,
}: {
  history: { slug: string; title: string; coverSeed: string; author: string; publishedAt: string }[];
  onOpen: (slug: string) => void;
  excludeSlugs: string[];
}) {
  const [recommendations, setRecommendations] = useState<PostSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [reason, setReason] = useState<string>("");

  useEffect(() => {
    let cancelled = false;
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setLoading(true);

    // Determine the recommendation strategy
    if (history.length === 0) {
      // No history → fetch trending (most-viewed)
      setReason("Trending now");
      fetch("/api/posts?sort=reads&limit=4")
        .then((r) => r.json())
        .then((d) => {
          if (!cancelled) {
            setRecommendations(
              (d.posts ?? []).filter(
                (p: PostSummary) => !excludeSlugs.includes(p.slug)
              )
            );
          }
        })
        .catch(() => setRecommendations([]))
        .finally(() => {
          if (!cancelled) setLoading(false);
        });
    } else {
      // Has history → fetch from the most recent read article's category
      const lastRead = history[0];
      fetch(`/api/posts/${lastRead.slug}/related`)
        .then((r) => r.json())
        .then((d) => {
          if (!cancelled) {
            const related = (d.related ?? []) as PostSummary[];
            // Exclude already-read articles
            const filtered = related.filter(
              (p) =>
                !excludeSlugs.includes(p.slug) &&
                !history.some((h) => h.slug === p.slug)
            );
            if (filtered.length > 0) {
              setRecommendations(filtered.slice(0, 4));
              setReason(`Because you read "${lastRead.title.slice(0, 40)}${lastRead.title.length > 40 ? "…" : ""}"`);
            } else {
              // Fallback to trending
              setReason("Trending now");
              fetch("/api/posts?sort=reads&limit=4")
                .then((r) => r.json())
                .then((d) => {
                  if (!cancelled) {
                    setRecommendations(
                      (d.posts ?? []).filter(
                        (p: PostSummary) => !excludeSlugs.includes(p.slug)
                      )
                    );
                  }
                })
                .catch(() => setRecommendations([]))
                .finally(() => {
                  if (!cancelled) setLoading(false);
                });
            }
          }
        })
        .catch(() => {
          if (!cancelled) {
            setReason("Trending now");
            fetch("/api/posts?sort=reads&limit=4")
              .then((r) => r.json())
              .then((d) => {
                if (!cancelled) {
                  setRecommendations(
                    (d.posts ?? []).filter(
                      (p: PostSummary) => !excludeSlugs.includes(p.slug)
                    )
                  );
                }
              })
              .catch(() => setRecommendations([]))
              .finally(() => {
                if (!cancelled) setLoading(false);
              });
          }
        })
        .finally(() => {
          if (!cancelled && recommendations.length === 0) {
            // setLoading will be handled in the inner .finally
          }
        });
    }

    return () => {
      cancelled = true;
    };
  }, [history.length]);

  if (!loading && recommendations.length === 0) return null;

  return (
    <motion.section
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className="mb-8"
    >
      <div className="mb-4 flex items-center gap-2">
        <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-primary/10 text-primary">
          <Sparkles className="h-3.5 w-3.5" />
        </div>
        <h2 className="font-serif text-xl font-bold tracking-tight">
          {reason || "Recommendations"}
        </h2>
        {reason === "Trending now" && (
          <TrendingUp className="h-4 w-4 text-amber-500" />
        )}
      </div>

      {loading ? (
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <div
              key={i}
              className="h-40 animate-pulse rounded-xl bg-muted"
              style={{ animationDelay: `${i * 0.1}s` }}
            />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
          {recommendations.map((post, i) => (
            <motion.button
              key={post.slug}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: i * 0.06 }}
              onClick={() => onOpen(post.slug)}
              className="group flex flex-col overflow-hidden rounded-xl border bg-card text-left shadow-sm transition-all hover:-translate-y-1 hover:shadow-lg hover:border-primary/30"
            >
              <div className="relative overflow-hidden">
                <div className="transition-transform duration-500 group-hover:scale-110">
                  <CoverArt
                    seed={post.coverSeed}
                    title={post.title}
                    className="h-24 w-full"
                    size="sm"
                  />
                </div>
                {post.categories[0] && (
                  <div className="absolute left-1.5 top-1.5 rounded-full bg-black/50 px-1.5 py-0.5 text-[9px] font-semibold text-white backdrop-blur-sm">
                    {post.categories[0].name}
                  </div>
                )}
              </div>
              <div className="flex flex-1 flex-col p-2.5">
                <h3 className="line-clamp-2 text-xs font-semibold leading-snug transition-colors group-hover:text-primary">
                  {post.title}
                </h3>
                <div className="mt-auto flex items-center gap-1.5 pt-1.5 text-[10px] text-muted-foreground">
                  <span className="flex items-center gap-0.5">
                    <Eye className="h-2.5 w-2.5" />
                    {post.views}
                  </span>
                  <span>· {post.readMinutes}m</span>
                </div>
              </div>
            </motion.button>
          ))}
        </div>
      )}
    </motion.section>
  );
}
