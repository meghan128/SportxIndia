"use client";

import { useEffect, useState, useCallback } from "react";

/**
 * Global keyboard navigation:
 *   /         → focus the search input
 *   j / →     → scroll down a card-height (next article)
 *   k / ←     → scroll up (previous article)
 *   g then s  → open Security Center
 *   g then n  → scroll to newsletter
 *   ?         → toggle the help overlay
 *   Esc       → close any open modal/dialog (handled by components)
 *
 * Disabled when the active element is an input/textarea/contenteditable.
 */
export function useKeyboardNav({
  onFocusSearch,
  onOpenSecurity,
  onOpenBookmarks,
  onOpenStats,
  onOpenTags,
  onOpenArchive,
  scrollCard,
}: {
  onFocusSearch: () => void;
  onOpenSecurity: () => void;
  onOpenBookmarks: () => void;
  onOpenStats: () => void;
  onOpenTags: () => void;
  onOpenArchive: () => void;
  scrollCard: (dir: 1 | -1) => void;
}) {
  const [helpOpen, setHelpOpen] = useState(false);

  const handler = useCallback(
    (e: KeyboardEvent) => {
      const el = document.activeElement as HTMLElement | null;
      const typing =
        el &&
        (el.tagName === "INPUT" ||
          el.tagName === "TEXTAREA" ||
          el.isContentEditable);

      // ?  — always available
      if (e.key === "?") {
        e.preventDefault();
        setHelpOpen((v) => !v);
        return;
      }
      if (e.key === "Escape" && helpOpen) {
        setHelpOpen(false);
        return;
      }
      if (typing) return;

      if (e.key === "/") {
        e.preventDefault();
        onFocusSearch();
      } else if (e.key === "j" || e.key === "ArrowRight") {
        e.preventDefault();
        scrollCard(1);
      } else if (e.key === "k" || e.key === "ArrowLeft") {
        e.preventDefault();
        scrollCard(-1);
      }
    },
    [helpOpen, onFocusSearch, onOpenSecurity, scrollCard]
  );

  // Separate handler for the "g then x" sequence (needs a small buffer)
  useEffect(() => {
    let buffer = "";
    let timer: ReturnType<typeof setTimeout> | null = null;

    const onKey = (e: KeyboardEvent) => {
      const el = document.activeElement as HTMLElement | null;
      const typing =
        el &&
        (el.tagName === "INPUT" ||
          el.tagName === "TEXTAREA" ||
          el.isContentEditable);
      if (typing) return;

      if (e.key === "g") {
        buffer = "g";
        if (timer) clearTimeout(timer);
        timer = setTimeout(() => (buffer = ""), 700);
        return;
      }
      if (buffer === "g" && e.key === "s") {
        e.preventDefault();
        buffer = "";
        onOpenSecurity();
      }
      if (buffer === "g" && e.key === "n") {
        e.preventDefault();
        buffer = "";
        document
          .getElementById("newsletter-section")
          ?.scrollIntoView({ behavior: "smooth", block: "center" });
      }
      if (buffer === "g" && e.key === "b") {
        e.preventDefault();
        buffer = "";
        onOpenBookmarks();
      }
      if (buffer === "g" && e.key === "r") {
        e.preventDefault();
        buffer = "";
        onOpenStats();
      }
      if (buffer === "g" && e.key === "t") {
        e.preventDefault();
        buffer = "";
        onOpenTags();
      }
      if (buffer === "g" && e.key === "a") {
        e.preventDefault();
        buffer = "";
        onOpenArchive();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onOpenSecurity, onOpenBookmarks, onOpenStats, onOpenTags, onOpenArchive]);

  useEffect(() => {
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [handler]);

  return { helpOpen, setHelpOpen };
}

export function KeyboardHelpOverlay({
  open,
  onClose,
}: {
  open: boolean;
  onClose: () => void;
}) {
  if (!open) return null;
  const keys: { k: string; d: string }[] = [
    { k: "/", d: "Focus search" },
    { k: "j / →", d: "Next article" },
    { k: "k / ←", d: "Previous article" },
    { k: "g s", d: "Open Security Center" },
    { k: "g b", d: "Open bookmarks" },
    { k: "g r", d: "Open reading stats" },
    { k: "g t", d: "Open tag explorer" },
    { k: "g a", d: "Open article archive" },
    { k: "g n", d: "Jump to newsletter" },
    { k: "?", d: "Toggle this help" },
    { k: "Esc", d: "Close dialogs" },
  ];
  return (
    <div
      className="fixed inset-0 z-[70] flex items-center justify-center bg-black/60 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md rounded-2xl border bg-card p-6 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-4 flex items-center justify-between">
          <h3 className="font-serif text-lg font-bold">Keyboard shortcuts</h3>
          <button
            onClick={onClose}
            className="text-muted-foreground hover:text-foreground"
          >
            Esc
          </button>
        </div>
        <div className="space-y-2.5">
          {keys.map((row) => (
            <div
              key={row.k}
              className="flex items-center justify-between text-sm"
            >
              <span className="text-muted-foreground">{row.d}</span>
              <kbd className="rounded-md border bg-muted px-2 py-0.5 font-mono text-xs font-medium">
                {row.k}
              </kbd>
            </div>
          ))}
        </div>
        <p className="mt-4 text-center text-xs text-muted-foreground">
          Press <kbd className="font-mono">?</kbd> anywhere to open this again.
        </p>
      </div>
    </div>
  );
}
