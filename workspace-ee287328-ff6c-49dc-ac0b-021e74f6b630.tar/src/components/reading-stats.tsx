"use client";

import { useEffect, useState, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  BarChart3,
  BookOpen,
  Clock,
  Flame,
  TrendingUp,
  Eye,
  Target,
  Award,
  X,
  Calendar,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { CoverArt } from "@/components/cover-art";
import { format, formatDistanceToNow, differenceInCalendarDays } from "date-fns";

const STORAGE_KEY = "sportx-reading-stats";

type ReadingSession = {
  slug: string;
  title: string;
  coverSeed: string;
  author: string;
  publishedAt: string;
  readMinutes: number;
  viewedAt: string; // ISO timestamp
};

type StatsState = {
  sessions: ReadingSession[];
  totalMinutesRead: number;
  streak: {
    current: number;
    longest: number;
    lastReadDate: string | null;
  };
};

export function useReadingStats() {
  const [stats, setStats] = useState<StatsState>({
    sessions: [],
    totalMinutesRead: 0,
    streak: { current: 0, longest: 0, lastReadDate: null },
  });

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as StatsState;
        // Recalculate streak on load (it may have been broken)
        const recalculated = recalculateStreak(parsed);
        // eslint-disable-next-line react-hooks/set-state-in-effect
        setStats(recalculated);
      }
    } catch {
      // ignore
    }
  }, []);

  const persist = (next: StatsState) => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
    } catch {
      // ignore
    }
  };

  const recordRead = useCallback(
    (post: {
      slug: string;
      title: string;
      coverSeed: string;
      readMinutes: number;
      publishedAt: string;
      author: { displayName: string };
    }) => {
      setStats((prev) => {
        const now = new Date();
        const today = now.toISOString().slice(0, 10);

        // Add session (dedupe by slug — keep latest view, but accumulate count)
        const session: ReadingSession = {
          slug: post.slug,
          title: post.title,
          coverSeed: post.coverSeed,
          author: post.author.displayName,
          publishedAt: post.publishedAt,
          readMinutes: post.readMinutes,
          viewedAt: now.toISOString(),
        };

        // Replace any existing session for this slug (so we don't double-count)
        const filtered = prev.sessions.filter((s) => s.slug !== post.slug);
        const sessions = [session, ...filtered].slice(0, 100);

        // Calculate streak
        const lastDate = prev.streak.lastReadDate;
        let current = prev.streak.current;
        let longest = prev.streak.longest;

        if (lastDate !== today) {
          if (lastDate) {
            const diff = differenceInCalendarDays(now, new Date(lastDate));
            if (diff === 1) {
              current += 1; // continued streak
            } else if (diff > 1) {
              current = 1; // streak broken, start new
            }
            // diff === 0 shouldn't happen since lastDate !== today
          } else {
            current = 1; // first ever read
          }
        }
        // If lastDate === today, streak stays the same (already counted today)

        longest = Math.max(longest, current);

        // Recalculate total minutes from sessions
        const totalMinutesRead = sessions.reduce(
          (sum, s) => sum + s.readMinutes,
          0
        );

        const next: StatsState = {
          sessions,
          totalMinutesRead,
          streak: { current, longest, lastReadDate: today },
        };
        persist(next);
        return next;
      });
    },
    []
  );

  const resetStats = useCallback(() => {
    const empty: StatsState = {
      sessions: [],
      totalMinutesRead: 0,
      streak: { current: 0, longest: 0, lastReadDate: null },
    };
    persist(empty);
    setStats(empty);
  }, []);

  return { stats, recordRead, resetStats };
}

function recalculateStreak(s: StatsState): StatsState {
  if (!s.streak.lastReadDate) return s;
  const today = new Date();
  const last = new Date(s.streak.lastReadDate);
  const diff = differenceInCalendarDays(today, last);
  // If more than 1 day has passed since last read, streak is broken
  if (diff > 1) {
    return { ...s, streak: { ...s.streak, current: 0 } };
  }
  return s;
}

// ===== Stats Dashboard Modal =====
export function ReadingStatsDashboard({
  open,
  onOpenChange,
  stats,
  onReset,
  onOpenArticle,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  stats: StatsState;
  onReset: () => void;
  onOpenArticle: (slug: string) => void;
}) {
  const uniqueArticles = stats.sessions.length;
  const totalMinutes = stats.totalMinutesRead;
  const avgPerArticle = uniqueArticles > 0 ? Math.round(totalMinutes / uniqueArticles) : 0;

  // Reading activity for last 7 days
  const last7Days = Array.from({ length: 7 }, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() - (6 - i));
    const key = d.toISOString().slice(0, 10);
    const count = stats.sessions.filter(
      (s) => s.viewedAt.slice(0, 10) === key
    ).length;
    return {
      label: d.toLocaleDateString("en", { weekday: "short" }),
      count,
      isToday: i === 6,
    };
  });
  const maxCount = Math.max(...last7Days.map((d) => d.count), 1);

  // Top categories read (derived from session titles — simplified)
  const recentSessions = stats.sessions.slice(0, 10);

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="fixed inset-0 z-50 flex items-stretch justify-center bg-black/70 backdrop-blur-sm sm:items-center sm:p-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={() => onOpenChange(false)}
        >
          <motion.div
            className="relative z-10 flex h-full w-full max-w-2xl flex-col bg-card shadow-2xl sm:h-auto sm:max-h-[90vh] sm:rounded-2xl overflow-hidden border"
            initial={{ y: 30, opacity: 0, scale: 0.98 }}
            animate={{ y: 0, opacity: 1, scale: 1 }}
            exit={{ y: 30, opacity: 0, scale: 0.98 }}
            transition={{ type: "spring", stiffness: 260, damping: 28 }}
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="relative overflow-hidden border-b bg-gradient-to-br from-primary via-primary/90 to-amber-600 p-5 text-primary-foreground">
              <div
                className="absolute inset-0 opacity-10"
                style={{
                  backgroundImage:
                    "repeating-linear-gradient(45deg, transparent, transparent 20px, rgba(255,255,255,0.1) 20px, rgba(255,255,255,0.1) 40px)",
                }}
              />
              <div className="relative flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/20 backdrop-blur-sm">
                    <BarChart3 className="h-5 w-5" />
                  </div>
                  <div>
                    <h2 className="font-serif text-xl font-bold">Your Reading Stats</h2>
                    <p className="text-xs text-primary-foreground/80">
                      Personal reading activity on SportX India
                    </p>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 text-primary-foreground hover:bg-white/20"
                  onClick={() => onOpenChange(false)}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </div>

            <ScrollArea className="flex-1 min-h-0 scroll-area-thin">
              <div className="p-5">
                {/* Top stat cards */}
                <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                  <StatTile
                    icon={BookOpen}
                    label="Articles read"
                    value={uniqueArticles}
                    color="text-primary"
                  />
                  <StatTile
                    icon={Clock}
                    label="Minutes read"
                    value={totalMinutes}
                    sub={fmtHours(totalMinutes)}
                    color="text-emerald-600"
                  />
                  <StatTile
                    icon={Flame}
                    label="Current streak"
                    value={stats.streak.current}
                    sub={stats.streak.current > 0 ? "days" : "—"}
                    color="text-orange-500"
                  />
                  <StatTile
                    icon={Award}
                    label="Longest streak"
                    value={stats.streak.longest}
                    sub="days"
                    color="text-amber-600"
                  />
                </div>

                {/* 7-day activity bar chart */}
                <div className="mt-6 rounded-xl border bg-card p-4">
                  <div className="mb-3 flex items-center gap-2">
                    <TrendingUp className="h-4 w-4 text-primary" />
                    <h3 className="text-sm font-semibold">Last 7 days</h3>
                    <span className="ml-auto text-xs text-muted-foreground">
                      {last7Days.reduce((a, b) => a + b.count, 0)} articles read
                    </span>
                  </div>
                  <div className="flex h-32 items-end justify-between gap-2">
                    {last7Days.map((d, i) => (
                      <div
                        key={i}
                        className="flex flex-1 flex-col items-center gap-1"
                      >
                        <div className="flex w-full flex-1 items-end justify-center">
                          <motion.div
                            initial={{ height: 0 }}
                            animate={{ height: `${(d.count / maxCount) * 100}%` }}
                            transition={{ delay: i * 0.05, duration: 0.4 }}
                            className={`w-full max-w-[2.5rem] rounded-t-md ${
                              d.count > 0
                                ? d.isToday
                                  ? "bg-primary"
                                  : "bg-primary/40"
                                : "bg-muted"
                            }`}
                            style={{ minHeight: d.count > 0 ? "8px" : "2px" }}
                          />
                        </div>
                        <span className="text-[10px] text-muted-foreground">
                          {d.label}
                        </span>
                        {d.count > 0 && (
                          <span className="text-[10px] font-semibold tabular-nums">
                            {d.count}
                          </span>
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Achievements */}
                <div className="mt-4">
                  <h3 className="mb-2 flex items-center gap-2 text-sm font-semibold">
                    <Target className="h-4 w-4 text-primary" />
                    Achievements
                  </h3>
                  <div className="flex flex-wrap gap-2">
                    <Achievement
                      icon={BookOpen}
                      label="First article"
                      unlocked={uniqueArticles >= 1}
                    />
                    <Achievement
                      icon={BookOpen}
                      label="10 articles"
                      unlocked={uniqueArticles >= 10}
                    />
                    <Achievement
                      icon={BookOpen}
                      label="50 articles"
                      unlocked={uniqueArticles >= 50}
                    />
                    <Achievement
                      icon={Clock}
                      label="1 hour read"
                      unlocked={totalMinutes >= 60}
                    />
                    <Achievement
                      icon={Clock}
                      label="5 hours read"
                      unlocked={totalMinutes >= 300}
                    />
                    <Achievement
                      icon={Flame}
                      label="3-day streak"
                      unlocked={stats.streak.longest >= 3}
                    />
                    <Achievement
                      icon={Flame}
                      label="7-day streak"
                      unlocked={stats.streak.longest >= 7}
                    />
                  </div>
                </div>

                {/* Recently read */}
                {recentSessions.length > 0 && (
                  <div className="mt-6">
                    <div className="mb-2 flex items-center justify-between">
                      <h3 className="flex items-center gap-2 text-sm font-semibold">
                        <Calendar className="h-4 w-4 text-primary" />
                        Recently read
                      </h3>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-7 text-xs text-muted-foreground hover:text-destructive"
                        onClick={onReset}
                      >
                        Reset stats
                      </Button>
                    </div>
                    <div className="space-y-2">
                      {recentSessions.map((s) => (
                        <button
                          key={s.slug}
                          onClick={() => onOpenArticle(s.slug)}
                          className="group flex w-full gap-3 rounded-lg border bg-card p-2 text-left transition-colors hover:border-primary/40"
                        >
                          <CoverArt
                            seed={s.coverSeed}
                            title={s.title}
                            className="h-12 w-12 shrink-0 rounded-md"
                            size="sm"
                          />
                          <div className="flex min-w-0 flex-1 flex-col">
                            <h4 className="line-clamp-1 text-xs font-semibold transition-colors group-hover:text-primary">
                              {s.title}
                            </h4>
                            <div className="flex items-center gap-2 text-[10px] text-muted-foreground">
                              <span>{s.author.split(" ")[0]}</span>
                              <span>·</span>
                              <span>{s.readMinutes}m</span>
                              <span>·</span>
                              <span>{formatDistanceToNow(new Date(s.viewedAt), { addSuffix: true })}</span>
                            </div>
                          </div>
                          <Eye className="h-3.5 w-3.5 self-center text-muted-foreground" />
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {recentSessions.length === 0 && (
                  <div className="mt-6 flex flex-col items-center justify-center py-10 text-center">
                    <div className="mb-3 flex h-14 w-14 items-center justify-center rounded-full bg-muted">
                      <BookOpen className="h-7 w-7 text-muted-foreground" />
                    </div>
                    <h3 className="font-semibold">No reading activity yet</h3>
                    <p className="mt-1 max-w-xs text-sm text-muted-foreground">
                      Open articles to start tracking your reading stats,
                      streaks, and achievements here.
                    </p>
                  </div>
                )}
              </div>
            </ScrollArea>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

function StatTile({
  icon: Icon,
  label,
  value,
  sub,
  color,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: number;
  sub?: string;
  color: string;
}) {
  return (
    <div className="rounded-xl border bg-card p-3">
      <Icon className={`mb-1 h-4 w-4 ${color}`} />
      <div className="text-2xl font-bold tabular-nums">{value.toLocaleString()}</div>
      <div className="text-[10px] uppercase tracking-wide text-muted-foreground">
        {label}
      </div>
      {sub && (
        <div className="text-[10px] text-muted-foreground/70">{sub}</div>
      )}
    </div>
  );
}

function Achievement({
  icon: Icon,
  label,
  unlocked,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  unlocked: boolean;
}) {
  return (
    <div
      className={`flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs ${
        unlocked
          ? "border-primary/30 bg-primary/5 text-primary"
          : "border-border bg-muted/50 text-muted-foreground/50"
      }`}
    >
      <Icon className={`h-3 w-3 ${unlocked ? "" : "grayscale"}`} />
      {label}
      {unlocked && <Badge className="ml-0.5 h-1.5 w-1.5 rounded-full bg-primary p-0" />}
    </div>
  );
}

function fmtHours(mins: number): string {
  if (mins < 60) return `${mins}m`;
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  return m > 0 ? `${h}h ${m}m` : `${h}h`;
}
