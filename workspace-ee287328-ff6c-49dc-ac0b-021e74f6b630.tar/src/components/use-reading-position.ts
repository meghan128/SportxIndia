"use client";

import { useEffect, useRef, useCallback } from "react";

const STORAGE_PREFIX = "sportx-scroll-";

/**
 * useReadingPosition — saves and restores the scroll position of the article
 * reader's ScrollArea viewport. When the user returns to an article they've
 * partially read, they pick up exactly where they left off.
 *
 * @param slug — the article slug (null when no article is open)
 * @param scrollRef — ref to the ScrollArea root element
 */
export function useReadingPosition(
  slug: string | null,
  scrollRef: React.RefObject<HTMLElement | null>
) {
  const saveTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Restore scroll position when an article opens
  useEffect(() => {
    if (!slug) return;
    const key = STORAGE_PREFIX + slug;
    let saved: number | null = null;
    try {
      saved = parseFloat(localStorage.getItem(key) || "0");
    } catch {
      saved = 0;
    }

    // Defer until the content has rendered (the viewport needs to have content)
    let raf = requestAnimationFrame(() => {
      const viewport = scrollRef.current?.querySelector(
        "[data-radix-scroll-area-viewport]"
      ) as HTMLElement | null;
      if (viewport && saved && saved > 50) {
        // Only restore if the user was meaningfully scrolled (not just at top)
        viewport.scrollTop = saved;
      }
    });

    return () => cancelAnimationFrame(raf);
  }, [slug]);

  // Save scroll position on scroll (debounced) + on unmount/close
  useEffect(() => {
    if (!slug) return;
    const viewport = scrollRef.current?.querySelector(
      "[data-radix-scroll-area-viewport]"
    ) as HTMLElement | null;
    if (!viewport) return;

    const onScroll = () => {
      if (saveTimerRef.current) clearTimeout(saveTimerRef.current);
      saveTimerRef.current = setTimeout(() => {
        try {
          localStorage.setItem(
            STORAGE_PREFIX + slug,
            String(viewport.scrollTop)
          );
        } catch {
          // ignore
        }
      }, 300);
    };

    viewport.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      viewport.removeEventListener("scroll", onScroll);
      // Save final position on unmount
      try {
        localStorage.setItem(
          STORAGE_PREFIX + slug,
          String(viewport.scrollTop)
        );
      } catch {
        // ignore
      }
      if (saveTimerRef.current) clearTimeout(saveTimerRef.current);
    };
  }, [slug]);

  const clearPosition = useCallback((s: string) => {
    try {
      localStorage.removeItem(STORAGE_PREFIX + s);
    } catch {
      // ignore
    }
  }, []);

  return { clearPosition };
}
