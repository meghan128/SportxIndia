"use client";

import { useEffect, useState, useRef, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Search,
  ArrowRight,
  CornerDownLeft,
  ShieldCheck,
  Bookmark,
  BarChart3,
  Hash,
  Home,
  Moon,
  Sun,
  HelpCircle,
  Newspaper,
  User,
  FileText,
  TrendingUp,
} from "lucide-react";
import { useTheme } from "next-themes";
import type { FilterData, PostSummary } from "@/lib/types";
import { format } from "date-fns";

type CommandItem = {
  id: string;
  label: string;
  hint?: string;
  icon: React.ComponentType<{ className?: string }>;
  group: "Navigate" | "Articles" | "Tools" | "Categories" | "Authors" | "Tags";
  action: () => void;
  keywords?: string;
};

export function CommandPalette({
  open,
  onOpenChange,
  filters,
  onOpenArticle,
  onOpenSecurity,
  onOpenBookmarks,
  onOpenStats,
  onOpenTags,
  onBrowseCategory,
  onBrowseAuthor,
  onBrowseTag,
  onScrollNewsletter,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  filters: FilterData | null;
  onOpenArticle: (slug: string) => void;
  onOpenSecurity: () => void;
  onOpenBookmarks: () => void;
  onOpenStats: () => void;
  onOpenTags: () => void;
  onBrowseCategory: (slug: string) => void;
  onBrowseAuthor: (login: string) => void;
  onBrowseTag: (slug: string) => void;
  onScrollNewsletter: () => void;
}) {
  const [query, setQuery] = useState("");
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [searchResults, setSearchResults] = useState<PostSummary[]>([]);
  const [searching, setSearching] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const listRef = useRef<HTMLDivElement>(null);
  const { setTheme } = useTheme();

  // Reset query when opened — uses requestAnimationFrame to defer the state
  // updates out of the effect body (avoids cascading renders lint).
  useEffect(() => {
    if (!open) return;
    let raf = requestAnimationFrame(() => {
      setQuery("");
      setSelectedIndex(0);
      setSearchResults([]);
      inputRef.current?.focus();
    });
    return () => cancelAnimationFrame(raf);
  }, [open]);

  // Debounced search for articles — the setLoading(true) call is guarded by
  // a cancelled flag and happens inside the async timeout, not the effect body.
  useEffect(() => {
    if (!query.trim()) {
      let raf = requestAnimationFrame(() => {
        setSearchResults([]);
        setSearching(false);
      });
      return () => cancelAnimationFrame(raf);
    }
    let cancelled = false;
    const t = setTimeout(() => {
      if (cancelled) return;
      setSearching(true);
      fetch(`/api/posts?q=${encodeURIComponent(query)}&limit=6`)
        .then((r) => r.json())
        .then((d) => {
          if (!cancelled) setSearchResults(d.posts ?? []);
        })
        .catch(() => {
          if (!cancelled) setSearchResults([]);
        })
        .finally(() => {
          if (!cancelled) setSearching(false);
        });
    }, 200);
    return () => {
      cancelled = true;
      clearTimeout(t);
    };
  }, [query]);

  // Build command items
  const items: CommandItem[] = [
    // Navigate
    {
      id: "nav-home",
      label: "Go to home",
      icon: Home,
      group: "Navigate",
      action: () => {
        onOpenChange(false);
        window.scrollTo({ top: 0, behavior: "smooth" });
      },
    },
    {
      id: "nav-newsletter",
      label: "Jump to newsletter",
      icon: Newspaper,
      group: "Navigate",
      action: () => {
        onOpenChange(false);
        onScrollNewsletter();
      },
    },
    // Tools
    {
      id: "tool-security",
      label: "Open Security Center",
      hint: "g s",
      icon: ShieldCheck,
      group: "Tools",
      action: () => {
        onOpenChange(false);
        onOpenSecurity();
      },
    },
    {
      id: "tool-bookmarks",
      label: "Open bookmarks",
      hint: "g b",
      icon: Bookmark,
      group: "Tools",
      action: () => {
        onOpenChange(false);
        onOpenBookmarks();
      },
    },
    {
      id: "tool-stats",
      label: "View reading stats",
      hint: "g r",
      icon: BarChart3,
      group: "Tools",
      action: () => {
        onOpenChange(false);
        onOpenStats();
      },
    },
    {
      id: "tool-tags",
      label: "Explore tags",
      hint: "g t",
      icon: Hash,
      group: "Tools",
      action: () => {
        onOpenChange(false);
        onOpenTags();
      },
    },
    {
      id: "tool-theme-dark",
      label: "Switch to dark mode",
      icon: Moon,
      group: "Tools",
      action: () => {
        setTheme("dark");
        onOpenChange(false);
      },
    },
    {
      id: "tool-theme-light",
      label: "Switch to light mode",
      icon: Sun,
      group: "Tools",
      action: () => {
        setTheme("light");
        onOpenChange(false);
      },
    },
    // Categories
    ...(filters?.categories ?? []).map((c) => ({
      id: `cat-${c.slug}`,
      label: c.name,
      hint: `${c.count} articles`,
      icon: FileText,
      group: "Categories" as const,
      action: () => {
        onOpenChange(false);
        onBrowseCategory(c.slug);
      },
    })),
    // Authors
    ...(filters?.authors ?? []).slice(0, 8).map((a) => ({
      id: `author-${a.login}`,
      label: a.displayName,
      hint: `${a.count} articles`,
      icon: User,
      group: "Authors" as const,
      action: () => {
        onOpenChange(false);
        onBrowseAuthor(a.login);
      },
    })),
    // Tags
    ...(filters?.tags ?? []).slice(0, 12).map((t) => ({
      id: `tag-${t.slug}`,
      label: `#${t.name}`,
      hint: `${t.count}`,
      icon: Hash,
      group: "Tags" as const,
      action: () => {
        onOpenChange(false);
        onBrowseTag(t.slug);
      },
    })),
  ];

  // Filter items by query
  const filteredItems = query.trim()
    ? items.filter((item) => {
        const text = `${item.label} ${item.group} ${item.keywords ?? ""}`.toLowerCase();
        return text.includes(query.toLowerCase());
      })
    : items;

  // Group articles separately (from search results)
  const articleResults = query.trim() ? searchResults : [];

  // Combined flat list for keyboard nav
  const flatList: { type: "item" | "article"; data: CommandItem | PostSummary }[] = [
    ...articleResults.map((p) => ({ type: "article" as const, data: p })),
    ...filteredItems.map((item) => ({ type: "item" as const, data: item })),
  ];

  // Reset selected index when query changes (deferred to avoid lint)
  useEffect(() => {
    let raf = requestAnimationFrame(() => setSelectedIndex(0));
    return () => cancelAnimationFrame(raf);
  }, [query]);

  const executeSelected = useCallback(() => {
    const entry = flatList[selectedIndex];
    if (!entry) return;
    if (entry.type === "item") {
      (entry.data as CommandItem).action();
    } else {
      const post = entry.data as PostSummary;
      onOpenChange(false);
      onOpenArticle(post.slug);
    }
  }, [flatList, selectedIndex, onOpenArticle, onOpenChange]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setSelectedIndex((i) => Math.min(flatList.length - 1, i + 1));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setSelectedIndex((i) => Math.max(0, i - 1));
    } else if (e.key === "Enter") {
      e.preventDefault();
      executeSelected();
    } else if (e.key === "Escape") {
      e.preventDefault();
      onOpenChange(false);
    }
  };

  // Scroll selected into view
  useEffect(() => {
    const el = listRef.current?.querySelector(`[data-idx="${selectedIndex}"]`);
    el?.scrollIntoView({ block: "nearest" });
  }, [selectedIndex]);

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="fixed inset-0 z-[80] flex items-start justify-center bg-black/60 backdrop-blur-md sm:pt-[15vh]"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={() => onOpenChange(false)}
        >
          <motion.div
            className="relative z-10 flex w-full max-w-xl flex-col overflow-hidden rounded-2xl border bg-card shadow-2xl"
            initial={{ y: -20, opacity: 0, scale: 0.97 }}
            animate={{ y: 0, opacity: 1, scale: 1 }}
            exit={{ y: -20, opacity: 0, scale: 0.97 }}
            transition={{ type: "spring", stiffness: 400, damping: 30 }}
            onClick={(e) => e.stopPropagation()}
          >
            {/* Search input */}
            <div className="flex items-center gap-3 border-b px-4 py-3">
              <Search className="h-4 w-4 shrink-0 text-muted-foreground" />
              <input
                ref={inputRef}
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Search articles, authors, tags, or run a command…"
                className="flex-1 bg-transparent text-sm outline-none placeholder:text-muted-foreground"
              />
              <kbd className="hidden rounded border bg-muted px-1.5 py-0.5 font-mono text-[10px] text-muted-foreground sm:block">
                ESC
              </kbd>
            </div>

            {/* Results */}
            <div
              ref={listRef}
              className="max-h-[60vh] min-h-0 overflow-y-auto scroll-area-thin"
            >
              {flatList.length === 0 && !searching && (
                <div className="flex flex-col items-center justify-center py-12 text-center">
                  <Search className="mb-2 h-8 w-8 text-muted-foreground/40" />
                  <p className="text-sm text-muted-foreground">
                    No results for &ldquo;{query}&rdquo;
                  </p>
                  <p className="text-xs text-muted-foreground/70">
                    Try a different search term or browse categories.
                  </p>
                </div>
              )}

              {searching && (
                <div className="flex items-center justify-center py-8 text-sm text-muted-foreground">
                  <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent" />
                  Searching…
                </div>
              )}

              {/* Article results */}
              {articleResults.length > 0 && (
                <CommandGroup label="Articles">
                  {articleResults.map((post, i) => {
                    const idx = i;
                    return (
                      <CommandRow
                        key={post.slug}
                        idx={idx}
                        selected={selectedIndex === idx}
                        onClick={() => {
                          onOpenChange(false);
                          onOpenArticle(post.slug);
                        }}
                        onHover={() => setSelectedIndex(idx)}
                      >
                        <div className="flex min-w-0 flex-1 items-center gap-3">
                          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-md bg-primary/10 text-primary">
                            <FileText className="h-4 w-4" />
                          </div>
                          <div className="min-w-0 flex-1">
                            <div className="truncate text-sm font-medium">
                              {highlightMatch(post.title, query)}
                            </div>
                            <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
                              <span>{post.author.displayName}</span>
                              <span>·</span>
                              <span>{format(new Date(post.publishedAt), "d MMM yyyy")}</span>
                              {post.categories[0] && (
                                <>
                                  <span>·</span>
                                  <span className="text-primary/70">{post.categories[0].name}</span>
                                </>
                              )}
                            </div>
                          </div>
                        </div>
                        {selectedIndex === idx && (
                          <CornerDownEnter />
                        )}
                      </CommandRow>
                    );
                  })}
                </CommandGroup>
              )}

              {/* Command items grouped */}
              {filteredItems.length > 0 && (
                <CommandGroup label={query.trim() ? "Commands & Filters" : "Quick actions"}>
                  {filteredItems.map((item, i) => {
                    const idx = articleResults.length + i;
                    const Icon = item.icon;
                    return (
                      <CommandRow
                        key={item.id}
                        idx={idx}
                        selected={selectedIndex === idx}
                        onClick={() => item.action()}
                        onHover={() => setSelectedIndex(idx)}
                      >
                        <div className="flex min-w-0 flex-1 items-center gap-3">
                          <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-md bg-muted text-muted-foreground">
                            <Icon className="h-3.5 w-3.5" />
                          </div>
                          <span className="truncate text-sm">{item.label}</span>
                        </div>
                        {item.hint && (
                          <kbd className="rounded border bg-muted px-1.5 py-0.5 font-mono text-[10px] text-muted-foreground">
                            {item.hint}
                          </kbd>
                        )}
                        {selectedIndex === idx && <CornerDownEnter />}
                      </CommandRow>
                    );
                  })}
                </CommandGroup>
              )}

              {/* Trending when no query */}
              {!query.trim() && filters && filters.tags.length > 0 && (
                <CommandGroup label="Trending tags">
                  {filters.tags.slice(0, 6).map((t, i) => {
                    const idx = articleResults.length + filteredItems.length + i;
                    return (
                      <CommandRow
                        key={`trending-${t.slug}`}
                        idx={idx}
                        selected={selectedIndex === idx}
                        onClick={() => {
                          onOpenChange(false);
                          onBrowseTag(t.slug);
                        }}
                        onHover={() => setSelectedIndex(idx)}
                      >
                        <div className="flex min-w-0 flex-1 items-center gap-3">
                          <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-md bg-primary/10 text-primary">
                            <TrendingUp className="h-3.5 w-3.5" />
                          </div>
                          <span className="truncate text-sm">#{t.name}</span>
                        </div>
                        <kbd className="rounded-full bg-muted px-2 py-0.5 text-[10px] tabular-nums text-muted-foreground">
                          {t.count}
                        </kbd>
                      </CommandRow>
                    );
                  })}
                </CommandGroup>
              )}
            </div>

            {/* Footer */}
            <div className="flex items-center justify-between border-t bg-muted/30 px-4 py-2 text-[11px] text-muted-foreground">
              <div className="flex items-center gap-3">
                <span className="flex items-center gap-1">
                  <kbd className="rounded border bg-card px-1 font-mono">↑</kbd>
                  <kbd className="rounded border bg-card px-1 font-mono">↓</kbd>
                  navigate
                </span>
                <span className="flex items-center gap-1">
                  <kbd className="rounded border bg-card px-1 font-mono">↵</kbd>
                  select
                </span>
              </div>
              <span className="flex items-center gap-1">
                <HelpCircle className="h-3 w-3" />
                Press <kbd className="rounded border bg-card px-1 font-mono">?</kbd> for all shortcuts
              </span>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

function CommandGroup({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div className="py-1">
      <div className="px-3 py-1.5 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
        {label}
      </div>
      {children}
    </div>
  );
}

function CommandRow({
  idx,
  selected,
  onClick,
  onHover,
  children,
}: {
  idx: number;
  selected: boolean;
  onClick: () => void;
  onHover: () => void;
  children: React.ReactNode;
}) {
  return (
    <div
      data-idx={idx}
      onMouseEnter={onHover}
      onClick={onClick}
      className={`flex cursor-pointer items-center gap-2 px-3 py-2 transition-colors ${
        selected ? "bg-primary/10" : "hover:bg-muted/50"
      }`}
    >
      {children}
    </div>
  );
}

function CornerDownEnter() {
  return (
    <CornerDownLeft className="h-3.5 w-3.5 shrink-0 text-primary" />
  );
}

/**
 * highlightMatch — wraps query-matching substrings in <mark> for visual
 * highlighting in search results.
 */
function highlightMatch(text: string, query: string): React.ReactNode {
  if (!query.trim()) return text;
  const q = query.trim().toLowerCase();
  const lower = text.toLowerCase();
  const idx = lower.indexOf(q);
  if (idx === -1) return text;
  return (
    <>
      {text.slice(0, idx)}
      <mark className="rounded bg-primary/20 px-0.5 text-primary">
        {text.slice(idx, idx + q.length)}
      </mark>
      {text.slice(idx + q.length)}
    </>
  );
}
