"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { ArrowRight, Clock, Eye } from "lucide-react";
import { CoverArt } from "@/components/cover-art";
import type { PostSummary } from "@/lib/types";
import { format } from "date-fns";

export function RelatedArticles({
  slug,
  onOpen,
}: {
  slug: string | null;
  onOpen: (slug: string) => void;
}) {
  const [related, setRelated] = useState<PostSummary[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!slug) return;
    let cancelled = false;
    // Mark loading before the async fetch begins. This is a standard pattern
    // for triggering a loading UI prior to a network request; the lint rule
    // is overly strict here for a pre-fetch loading flag.
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setLoading(true);
    fetch(`/api/posts/${slug}/related`)
      .then((r) => r.json())
      .then((d) => {
        if (!cancelled) setRelated(d.related ?? []);
      })
      .catch(() => {
        if (!cancelled) setRelated([]);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [slug]);

  if (!slug || loading || related.length === 0) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="mt-10 border-t pt-8"
    >
      <div className="mb-4 flex items-center gap-2">
        <span className="h-4 w-1 rounded-full bg-primary" />
        <h3 className="font-serif text-lg font-bold tracking-tight">
          Keep reading
        </h3>
        <span className="text-xs text-muted-foreground">
          Related by topic
        </span>
      </div>
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        {related.map((p, i) => (
          <motion.button
            key={p.slug}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.06 }}
            onClick={() => onOpen(p.slug)}
            className="group flex gap-3 rounded-xl border bg-card p-3 text-left transition-all hover:border-primary/40 hover:shadow-sm"
          >
            <CoverArt
              seed={p.coverSeed}
              title={p.title}
              className="h-20 w-20 shrink-0 rounded-lg"
              size="sm"
            />
            <div className="flex min-w-0 flex-1 flex-col">
              {p.categories[0] && (
                <span className="text-[10px] font-semibold uppercase tracking-wide text-primary">
                  {p.categories[0].name}
                </span>
              )}
              <h4 className="mt-0.5 line-clamp-2 text-sm font-semibold leading-snug transition-colors group-hover:text-primary">
                {p.title}
              </h4>
              <div className="mt-auto flex items-center gap-2 pt-1.5 text-[10px] text-muted-foreground">
                <span className="flex items-center gap-0.5">
                  <Clock className="h-3 w-3" />
                  {format(new Date(p.publishedAt), "d MMM yy")}
                </span>
                <span className="flex items-center gap-0.5">
                  <Eye className="h-3 w-3" />
                  {p.views}
                </span>
                <ArrowRight className="ml-auto h-3 w-3 transition-transform group-hover:translate-x-0.5" />
              </div>
            </div>
          </motion.button>
        ))}
      </div>
    </motion.div>
  );
}
