"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { History, Clock, Eye, X } from "lucide-react";
import { CoverArt } from "@/components/cover-art";
import type { PostSummary } from "@/lib/types";
import { format } from "date-fns";

const STORAGE_KEY = "sportx-reading-history";
const MAX_ITEMS = 8;

export type HistoryEntry = {
  slug: string;
  title: string;
  coverSeed: string;
  author: string;
  publishedAt: string;
  viewedAt: string;
};

export function useReadingHistory() {
  const [history, setHistory] = useState<HistoryEntry[]>([]);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        // eslint-disable-next-line react-hooks/set-state-in-effect
        setHistory(JSON.parse(raw));
      }
    } catch {
      // ignore
    }
  }, []);

  const addEntry = (post: {
    slug: string;
    title: string;
    coverSeed: string;
    author: { displayName: string };
    publishedAt: string;
  }) => {
    setHistory((prev) => {
      const filtered = prev.filter((e) => e.slug !== post.slug);
      const entry: HistoryEntry = {
        slug: post.slug,
        title: post.title,
        coverSeed: post.coverSeed,
        author: post.author.displayName,
        publishedAt: post.publishedAt,
        viewedAt: new Date().toISOString(),
      };
      const next = [entry, ...filtered].slice(0, MAX_ITEMS);
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
      } catch {
        // ignore
      }
      return next;
    });
  };

  const removeEntry = (slug: string) => {
    setHistory((prev) => {
      const next = prev.filter((e) => e.slug !== slug);
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
      } catch {
        // ignore
      }
      return next;
    });
  };

  const clearAll = () => {
    setHistory([]);
    try {
      localStorage.removeItem(STORAGE_KEY);
    } catch {
      // ignore
    }
  };

  return { history, addEntry, removeEntry, clearAll };
}

export function ReadingHistory({
  history,
  onOpen,
  onRemove,
  onClear,
}: {
  history: HistoryEntry[];
  onOpen: (slug: string) => void;
  onRemove: (slug: string) => void;
  onClear: () => void;
}) {
  if (history.length === 0) return null;

  return (
    <motion.section
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className="mb-8"
    >
      <div className="mb-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <History className="h-4 w-4 text-primary" />
          <h2 className="font-serif text-xl font-bold tracking-tight">
            Recently viewed
          </h2>
          <Badge2 count={history.length} />
        </div>
        <button
          onClick={onClear}
          className="text-xs text-muted-foreground transition-colors hover:text-destructive"
        >
          Clear all
        </button>
      </div>
      <div className="flex gap-4 overflow-x-auto pb-2 scroll-area-thin">
        {history.map((entry, i) => (
          <motion.div
            key={entry.slug}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: i * 0.04 }}
            className="group relative w-56 shrink-0"
          >
            <button
              onClick={() => onOpen(entry.slug)}
              className="flex w-full flex-col overflow-hidden rounded-xl border bg-card text-left shadow-sm transition-all hover:-translate-y-0.5 hover:shadow-md"
            >
              <CoverArt
                seed={entry.coverSeed}
                title={entry.title}
                className="h-24 w-full"
                size="sm"
              />
              <div className="p-3">
                <h3 className="line-clamp-2 text-sm font-semibold leading-snug transition-colors group-hover:text-primary">
                  {entry.title}
                </h3>
                <div className="mt-2 flex items-center gap-2 text-[11px] text-muted-foreground">
                  <span className="flex items-center gap-0.5">
                    <Clock className="h-3 w-3" />
                    {format(new Date(entry.viewedAt), "d MMM")}
                  </span>
                  <span>· {entry.author.split(" ")[0]}</span>
                </div>
              </div>
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation();
                onRemove(entry.slug);
              }}
              className="absolute right-1.5 top-1.5 flex h-6 w-6 items-center justify-center rounded-full bg-black/50 text-white opacity-0 backdrop-blur-sm transition-opacity hover:bg-black/70 group-hover:opacity-100"
              aria-label="Remove from history"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </motion.div>
        ))}
      </div>
    </motion.section>
  );
}

function Badge2({ count }: { count: number }) {
  return (
    <span className="rounded-full bg-secondary px-2 py-0.5 text-[11px] font-medium tabular-nums">
      {count}
    </span>
  );
}
