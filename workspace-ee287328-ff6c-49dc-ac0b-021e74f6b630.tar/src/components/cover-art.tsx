// Deterministic cover-art generator. Each post gets a unique gradient + motif
// based on its coverSeed (slug), so every article has a recognizable visual
// identity without needing external image hosting.

const PALETTES: { from: string; via: string; to: string; accent: string }[] = [
  { from: "oklch(0.55 0.2 30)", via: "oklch(0.4 0.15 45)", to: "oklch(0.25 0.08 60)", accent: "oklch(0.85 0.18 80)" },
  { from: "oklch(0.5 0.18 155)", via: "oklch(0.35 0.12 165)", to: "oklch(0.22 0.06 170)", accent: "oklch(0.85 0.15 140)" },
  { from: "oklch(0.5 0.2 280)", via: "oklch(0.38 0.15 300)", to: "oklch(0.22 0.06 320)", accent: "oklch(0.82 0.16 60)" },
  { from: "oklch(0.58 0.19 80)", via: "oklch(0.42 0.14 70)", to: "oklch(0.26 0.06 55)", accent: "oklch(0.5 0.18 30)" },
  { from: "oklch(0.5 0.2 10)", via: "oklch(0.38 0.15 20)", to: "oklch(0.22 0.06 30)", accent: "oklch(0.85 0.16 90)" },
  { from: "oklch(0.45 0.16 200)", via: "oklch(0.33 0.1 210)", to: "oklch(0.2 0.05 220)", accent: "oklch(0.82 0.14 160)" },
  { from: "oklch(0.55 0.18 145)", via: "oklch(0.4 0.13 130)", to: "oklch(0.24 0.06 110)", accent: "oklch(0.85 0.16 50)" },
  { from: "oklch(0.5 0.18 350)", via: "oklch(0.38 0.14 340)", to: "oklch(0.22 0.06 330)", accent: "oklch(0.85 0.15 180)" },
];

function hash(str: string): number {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

const MOTIFS = ["track", "ball", "whistle", "trophy", "lane", "star"] as const;
type Motif = (typeof MOTIFS)[number];

export function coverArt(seed: string): {
  palette: (typeof PALETTES)[number];
  motif: Motif;
  rotation: number;
  patternSeed: number;
} {
  const h = hash(seed);
  const palette = PALETTES[h % PALETTES.length];
  const motif = MOTIFS[(h >> 4) % MOTIFS.length];
  const rotation = ((h >> 8) % 360);
  return { palette, motif, rotation, patternSeed: h };
}

export function CoverArt({
  seed,
  title,
  className,
  size = "md",
}: {
  seed: string;
  title: string;
  className?: string;
  size?: "sm" | "md" | "lg";
}) {
  const { palette, motif, rotation } = coverArt(seed);
  const initials = title
    .split(/\s+/)
    .slice(0, 2)
    .map((w) => w[0]?.toUpperCase() ?? "")
    .join("");

  const motifSize = size === "lg" ? 120 : size === "sm" ? 56 : 84;

  return (
    <div
      className={`relative overflow-hidden ${className ?? ""}`}
      style={{
        background: `linear-gradient(135deg, ${palette.from}, ${palette.via} 55%, ${palette.to})`,
      }}
      aria-hidden
    >
      {/* Decorative motif */}
      <svg
        className="absolute -right-6 -bottom-6 opacity-30"
        width={motifSize * 2}
        height={motifSize * 2}
        viewBox="0 0 100 100"
        style={{ transform: `rotate(${rotation}deg)` }}
      >
        <MotifShape kind={motif} accent={palette.accent} />
      </svg>
      {/* Concentric rings */}
      <svg
        className="absolute -left-8 -top-8 opacity-20"
        width="160"
        height="160"
        viewBox="0 0 100 100"
      >
        <circle cx="50" cy="50" r="42" fill="none" stroke={palette.accent} strokeWidth="1.5" />
        <circle cx="50" cy="50" r="30" fill="none" stroke={palette.accent} strokeWidth="1.2" />
        <circle cx="50" cy="50" r="18" fill="none" stroke={palette.accent} strokeWidth="1" />
      </svg>
      {/* Initials badge */}
      <div
        className="absolute left-4 top-4 flex h-11 w-11 items-center justify-center rounded-lg font-serif text-lg font-bold backdrop-blur-sm"
        style={{
          background: "oklch(0 0 0 / 0.25)",
          color: palette.accent,
          border: `1px solid ${palette.accent}40`,
        }}
      >
        {initials || "SX"}
      </div>
      {/* Bottom gradient for legibility */}
      <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent" />
    </div>
  );
}

function MotifShape({ kind, accent }: { kind: Motif; accent: string }) {
  switch (kind) {
    case "track":
      return (
        <g fill="none" stroke={accent} strokeWidth="2.5">
          <ellipse cx="50" cy="50" rx="40" ry="22" />
          <ellipse cx="50" cy="50" rx="28" ry="15" />
          <ellipse cx="50" cy="50" rx="16" ry="8" />
        </g>
      );
    case "ball":
      return (
        <g fill={accent}>
          <circle cx="50" cy="50" r="30" fill="none" stroke={accent} strokeWidth="2.5" />
          <path d="M50 20 L62 30 L58 46 L42 46 L38 30 Z" />
          <path d="M50 80 L62 70 L58 54 L42 54 L38 70 Z" />
          <path d="M20 50 L30 38 L46 42 L46 58 L30 62 Z" />
          <path d="M80 50 L70 38 L54 42 L54 58 L70 62 Z" />
        </g>
      );
    case "whistle":
      return (
        <g fill={accent}>
          <circle cx="40" cy="50" r="20" />
          <rect x="55" y="42" width="30" height="16" rx="3" />
          <circle cx="40" cy="50" r="8" fill="oklch(0.2 0.05 50)" />
        </g>
      );
    case "trophy":
      return (
        <g fill="none" stroke={accent} strokeWidth="3">
          <path d="M30 25 H70 V45 Q70 60 50 60 Q30 60 30 45 Z" />
          <path d="M30 30 H18 Q18 45 30 48" />
          <path d="M70 30 H82 Q82 45 70 48" />
          <rect x="42" y="60" width="16" height="12" />
          <rect x="32" y="72" width="36" height="6" rx="1" />
        </g>
      );
    case "lane":
      return (
        <g stroke={accent} strokeWidth="2.5">
          <line x1="10" y1="10" x2="90" y2="90" />
          <line x1="30" y1="10" x2="90" y2="70" />
          <line x1="50" y1="10" x2="90" y2="50" />
          <line x1="70" y1="10" x2="90" y2="30" />
          <line x1="10" y1="30" x2="30" y2="50" />
          <line x1="10" y1="50" x2="50" y2="90" />
        </g>
      );
    case "star":
      return (
        <path
          d="M50 15 L58 38 L82 38 L63 52 L70 75 L50 61 L30 75 L37 52 L18 38 L42 38 Z"
          fill={accent}
        />
      );
  }
}
