"use client";

import { useEffect, useState } from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  AreaChart,
  Area,
  Legend,
} from "recharts";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { BarChart3, PieChart as PieIcon, TrendingUp, Activity } from "lucide-react";

type Analytics = {
  postsByCategory: { name: string; slug: string; count: number }[];
  moderationDistribution: { status: string; count: number }[];
  topPosts: { title: string; views: number; slug: string }[];
  postsByMonth: { month: string; count: number }[];
  auditByAction: { action: string; count: number }[];
  incidentBySeverity: { severity: string; count: number }[];
};

const STATUS_COLORS: Record<string, string> = {
  published: "oklch(0.6 0.18 155)",
  quarantined: "oklch(0.62 0.21 32)",
  pending: "oklch(0.7 0.18 80)",
};

const SEVERITY_COLORS: Record<string, string> = {
  critical: "oklch(0.55 0.22 27)",
  high: "oklch(0.62 0.21 32)",
  medium: "oklch(0.7 0.18 80)",
  low: "oklch(0.6 0.14 155)",
};

const CHART_COLORS = [
  "oklch(0.62 0.21 32)",
  "oklch(0.6 0.14 155)",
  "oklch(0.7 0.18 80)",
  "oklch(0.5 0.18 280)",
  "oklch(0.6 0.2 10)",
  "oklch(0.65 0.15 200)",
];

export function AnalyticsCharts() {
  const [data, setData] = useState<Analytics | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/analytics")
      .then((r) => r.json())
      .then((d) => setData(d))
      .catch(() => setData(null))
      .finally(() => setLoading(false));
  }, []);

  if (loading || !data) {
    return (
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <Skeleton className="h-64 w-full rounded-xl" />
        <Skeleton className="h-64 w-full rounded-xl" />
      </div>
    );
  }

  const monthFmt = (m: string) => {
    const [y, mo] = m.split("-");
    const d = new Date(Number(y), Number(mo) - 1, 1);
    return d.toLocaleDateString("en", { month: "short", year: "2-digit" });
  };

  return (
    <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
      {/* Posts by category */}
      <ChartCard
        icon={BarChart3}
        title="Articles by category"
        subtitle="Published content distribution"
      >
        <ResponsiveContainer width="100%" height={220}>
          <BarChart
            data={data.postsByCategory.slice(0, 8)}
            margin={{ top: 8, right: 8, left: -16, bottom: 0 }}
          >
            <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
            <XAxis
              dataKey="name"
              tick={{ fontSize: 10 }}
              interval={0}
              angle={-25}
              textAnchor="end"
              height={56}
              className="fill-muted-foreground"
            />
            <YAxis tick={{ fontSize: 11 }} className="fill-muted-foreground" allowDecimals={false} />
            <Tooltip
              cursor={{ fill: "oklch(0.62 0.21 32 / 0.08)" }}
              contentStyle={{
                background: "var(--card)",
                border: "1px solid var(--border)",
                borderRadius: "0.5rem",
                fontSize: "12px",
              }}
            />
            <Bar dataKey="count" radius={[4, 4, 0, 0]} fill="oklch(0.62 0.21 32)" />
          </BarChart>
        </ResponsiveContainer>
      </ChartCard>

      {/* Moderation distribution pie */}
      <ChartCard
        icon={PieIcon}
        title="Moderation status"
        subtitle="Published vs. quarantined"
      >
        <ResponsiveContainer width="100%" height={220}>
          <PieChart>
            <Pie
              data={data.moderationDistribution}
              dataKey="count"
              nameKey="status"
              cx="50%"
              cy="50%"
              innerRadius={50}
              outerRadius={85}
              paddingAngle={3}
            >
              {data.moderationDistribution.map((entry) => (
                <Cell
                  key={entry.status}
                  fill={STATUS_COLORS[entry.status] ?? "oklch(0.6 0.14 155)"}
                />
              ))}
            </Pie>
            <Tooltip
              contentStyle={{
                background: "var(--card)",
                border: "1px solid var(--border)",
                borderRadius: "0.5rem",
                fontSize: "12px",
              }}
            />
            <Legend
              wrapperStyle={{ fontSize: 11 }}
              iconType="circle"
            />
          </PieChart>
        </ResponsiveContainer>
      </ChartCard>

      {/* Posts published over time */}
      <ChartCard
        icon={TrendingUp}
        title="Publishing timeline"
        subtitle="Articles per month (last 12)"
      >
        <ResponsiveContainer width="100%" height={220}>
          <AreaChart
            data={data.postsByMonth.map((m) => ({
              ...m,
              label: monthFmt(m.month),
            }))}
            margin={{ top: 8, right: 8, left: -16, bottom: 0 }}
          >
            <defs>
              <linearGradient id="grad-posts" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="oklch(0.62 0.21 32)" stopOpacity={0.4} />
                <stop offset="100%" stopColor="oklch(0.62 0.21 32)" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
            <XAxis dataKey="label" tick={{ fontSize: 10 }} className="fill-muted-foreground" />
            <YAxis tick={{ fontSize: 11 }} className="fill-muted-foreground" allowDecimals={false} />
            <Tooltip
              contentStyle={{
                background: "var(--card)",
                border: "1px solid var(--border)",
                borderRadius: "0.5rem",
                fontSize: "12px",
              }}
            />
            <Area
              type="monotone"
              dataKey="count"
              stroke="oklch(0.62 0.21 32)"
              strokeWidth={2}
              fill="url(#grad-posts)"
            />
          </AreaChart>
        </ResponsiveContainer>
      </ChartCard>

      {/* Incident severity */}
      <ChartCard
        icon={Activity}
        title="Incidents by severity"
        subtitle="Auto-detected threats"
      >
        {data.incidentBySeverity.length === 0 ? (
          <div className="flex h-[220px] items-center justify-center text-sm text-muted-foreground">
            No incidents recorded
          </div>
        ) : (
          <ResponsiveContainer width="100%" height={220}>
            <BarChart
              data={data.incidentBySeverity}
              layout="vertical"
              margin={{ top: 8, right: 16, left: 8, bottom: 0 }}
            >
              <CartesianGrid strokeDasharray="3 3" className="stroke-border" horizontal={false} />
              <XAxis type="number" tick={{ fontSize: 11 }} className="fill-muted-foreground" allowDecimals={false} />
              <YAxis
                type="category"
                dataKey="severity"
                tick={{ fontSize: 11 }}
                width={70}
                className="fill-muted-foreground capitalize"
              />
              <Tooltip
                cursor={{ fill: "oklch(0.62 0.21 32 / 0.08)" }}
                contentStyle={{
                  background: "var(--card)",
                  border: "1px solid var(--border)",
                  borderRadius: "0.5rem",
                  fontSize: "12px",
                }}
              />
              <Bar dataKey="count" radius={[0, 4, 4, 0]}>
                {data.incidentBySeverity.map((entry) => (
                  <Cell
                    key={entry.severity}
                    fill={SEVERITY_COLORS[entry.severity] ?? "oklch(0.6 0.14 155)"}
                  />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        )}
      </ChartCard>
    </div>
  );
}

function ChartCard({
  icon: Icon,
  title,
  subtitle,
  children,
}: {
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  subtitle: string;
  children: React.ReactNode;
}) {
  return (
    <Card className="p-4">
      <div className="mb-3 flex items-center gap-2">
        <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-primary/10 text-primary">
          <Icon className="h-3.5 w-3.5" />
        </div>
        <div>
          <h4 className="text-sm font-semibold leading-none">{title}</h4>
          <p className="mt-0.5 text-[11px] text-muted-foreground">{subtitle}</p>
        </div>
      </div>
      {children}
    </Card>
  );
}
