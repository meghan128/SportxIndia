"use client";

import { useEffect, useState, useMemo, useRef } from "react";
import { List, ChevronRight } from "lucide-react";

/**
 * Table of contents for the article reader. Parses the rendered article HTML
 * for h2/h3 headings, builds a clickable outline, and highlights the section
 * currently in view.
 *
 * Must be rendered AFTER the article content is in the DOM. Pass a ref to the
 * article container element.
 */
export function TableOfContents({
  articleRef,
  scrollRef,
}: {
  articleRef: React.RefObject<HTMLElement | null>;
  scrollRef: React.RefObject<HTMLElement | null>;
}) {
  const [headings, setHeadings] = useState<{ id: string; text: string; level: number }[]>([]);
  const [activeId, setActiveId] = useState<string>("");
  const [collapsed, setCollapsed] = useState(false);

  // Extract headings from the rendered article
  useEffect(() => {
    if (!articleRef.current) return;
    const article = articleRef.current;
    const els = article.querySelectorAll("h2, h3");
    const items: { id: string; text: string; level: number }[] = [];
    els.forEach((el, i) => {
      const text = el.textContent?.trim() ?? "";
      if (!text) return;
      const id = el.id || `heading-${i}`;
      el.id = id;
      items.push({
        id,
        text: text.length > 60 ? text.slice(0, 60) + "…" : text,
        level: el.tagName === "H2" ? 2 : 3,
      });
    });
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setHeadings(items);
  }, [articleRef]);

  // Track active heading on scroll
  useEffect(() => {
    if (headings.length === 0) return;
    const viewport = scrollRef.current?.querySelector("[data-radix-scroll-area-viewport]");
    const target = viewport ?? scrollRef.current ?? window;

    const onScroll = () => {
      let current = "";
      for (const h of headings) {
        const el = document.getElementById(h.id);
        if (el) {
          const rect = el.getBoundingClientRect();
          // If the heading is above the viewport middle, it's the active one
          if (rect.top < 120) {
            current = h.id;
          }
        }
      }
      setActiveId(current || headings[0]?.id || "");
    };

    target.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
    return () => target.removeEventListener("scroll", onScroll);
  }, [headings, scrollRef]);

  const handleClick = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      const viewport = scrollRef.current?.querySelector("[data-radix-scroll-area-viewport]");
      if (viewport) {
        const top = (el as HTMLElement).offsetTop - 80;
        (viewport as HTMLElement).scrollTo({ top, behavior: "smooth" });
      } else {
        el.scrollIntoView({ behavior: "smooth", block: "start" });
      }
    }
  };

  if (headings.length < 3) return null; // Don't show TOC for short articles

  return (
    <div className="mb-6 rounded-xl border bg-muted/30 p-4">
      <button
        onClick={() => setCollapsed((v) => !v)}
        className="flex w-full items-center gap-2 text-sm font-semibold"
      >
        <List className="h-4 w-4 text-primary" />
        Table of contents
        <span className="ml-auto text-xs font-normal text-muted-foreground">
          {headings.length} sections
        </span>
        <ChevronRight
          className={`h-4 w-4 transition-transform ${collapsed ? "" : "rotate-90"}`}
        />
      </button>
      {!collapsed && (
        <ol className="mt-3 space-y-1 border-l-2 pl-0">
          {headings.map((h, i) => (
            <li key={h.id}>
              <button
                onClick={() => handleClick(h.id)}
                className={`flex w-full items-start gap-2 py-1 text-left text-sm transition-colors ${
                  h.level === 3 ? "pl-6" : "pl-3"
                } ${
                  activeId === h.id
                    ? "font-semibold text-primary"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                <span
                  className={`mt-1.5 h-1 w-1 shrink-0 rounded-full transition-colors ${
                    activeId === h.id ? "bg-primary" : "bg-muted-foreground/40"
                  }`}
                />
                <span className="leading-snug">{h.text}</span>
              </button>
            </li>
          ))}
        </ol>
      )}
    </div>
  );
}
