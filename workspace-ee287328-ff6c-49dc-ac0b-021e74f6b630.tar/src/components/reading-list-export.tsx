"use client";

import { useState, useRef } from "react";
import { Download, FileJson, FileText, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import type { BookmarkEntry } from "@/components/bookmarks";

/**
 * ReadingListExport — dropdown for exporting saved bookmarks as JSON or
 * Markdown. Downloads a file with all bookmarked articles.
 */
export function ReadingListExport({
  bookmarks,
}: {
  bookmarks: BookmarkEntry[];
}) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  const exportJSON = () => {
    const data = {
      exportedAt: new Date().toISOString(),
      source: "SportX India",
      count: bookmarks.length,
      bookmarks: bookmarks.map((b) => ({
        title: b.title,
        author: b.author,
        url: `${window.location.origin}/?article=${b.slug}`,
        publishedAt: b.publishedAt,
        bookmarkedAt: b.bookmarkedAt,
        readMinutes: b.readMinutes,
      })),
    };
    downloadFile(
      JSON.stringify(data, null, 2),
      "sportx-reading-list.json",
      "application/json"
    );
    toast.success("Reading list exported as JSON");
    setOpen(false);
  };

  const exportMarkdown = () => {
    const lines = bookmarks.map((b, i) => {
      const url = `${window.location.origin}/?article=${b.slug}`;
      const date = new Date(b.publishedAt).toLocaleDateString("en", {
        year: "numeric",
        month: "short",
        day: "numeric",
      });
      return `## ${i + 1}. ${b.title}

- **Author:** ${b.author}
- **Published:** ${date}
- **Read time:** ${b.readMinutes} min
- **Link:** [${url}](${url})
`;
    });
    const md = `# My SportX India Reading List

Exported on ${new Date().toLocaleDateString()} · ${bookmarks.length} articles

---

${lines.join("\n---\n\n")}
`;

    downloadFile(md, "sportx-reading-list.md", "text/markdown");
    toast.success("Reading list exported as Markdown");
    setOpen(false);
  };

  const downloadFile = (content: string, filename: string, mime: string) => {
    const blob = new Blob([content], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  if (bookmarks.length === 0) return null;

  return (
    <div ref={ref} className="relative">
      <Button
        variant="outline"
        size="sm"
        onClick={() => setOpen((v) => !v)}
        className="gap-1.5"
      >
        <Download className="h-3.5 w-3.5" />
        Export
      </Button>
      {open && (
        <div className="absolute right-0 top-full z-50 mt-1 w-44 overflow-hidden rounded-lg border bg-card shadow-xl">
          <button
            onClick={exportJSON}
            className="flex w-full items-center gap-2 px-3 py-2 text-sm transition-colors hover:bg-muted"
          >
            <FileJson className="h-4 w-4 text-amber-500" />
            JSON
          </button>
          <button
            onClick={exportMarkdown}
            className="flex w-full items-center gap-2 px-3 py-2 text-sm transition-colors hover:bg-muted"
          >
            <FileText className="h-4 w-4 text-sky-500" />
            Markdown
          </button>
        </div>
      )}
    </div>
  );
}
