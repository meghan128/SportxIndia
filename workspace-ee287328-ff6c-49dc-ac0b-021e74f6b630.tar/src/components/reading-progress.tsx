"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";

/**
 * Reading-progress bar. Tracks scroll position of the nearest scrollable
 * ancestor (the article reader's ScrollArea viewport) and renders a thin
 * gradient bar at the top of its container.
 *
 * Pass a `target` ref to the scrollable element, or leave undefined to track
 * the window scroll.
 */
export function ReadingProgress({
  scrollRef,
  className,
}: {
  scrollRef?: React.RefObject<HTMLElement | null>;
  className?: string;
}) {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const el = scrollRef?.current;
    // The Radix ScrollArea viewport is a child div; find it.
    let viewport: Element | null = el ?? null;
    if (el) {
      viewport =
        el.querySelector("[data-radix-scroll-area-viewport]") ?? el;
    }
    const target: Element | Window = viewport ?? window;

    const onScroll = () => {
      if (target === window) {
        const h = document.documentElement;
        const scrolled = h.scrollTop;
        const height = h.scrollHeight - h.clientHeight;
        setProgress(height > 0 ? (scrolled / height) * 100 : 0);
        return;
      }
      const t = target as Element;
      const scrolled = t.scrollTop;
      const height = t.scrollHeight - t.clientHeight;
      setProgress(height > 0 ? (scrolled / height) * 100 : 0);
    };

    target.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
    return () => target.removeEventListener("scroll", onScroll);
  }, [scrollRef]);

  return (
    <div
      className={`pointer-events-none absolute inset-x-0 top-0 z-20 h-1 bg-transparent ${className ?? ""}`}
      aria-hidden
    >
      <motion.div
        className="h-full origin-left bg-gradient-to-r from-primary via-amber-500 to-emerald-500"
        style={{ width: `${progress}%` }}
        transition={{ type: "spring", stiffness: 400, damping: 40 }}
      />
    </div>
  );
}
