"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Clock, Eye, Award, BookOpen, TrendingUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { CoverArt } from "@/components/cover-art";
import { format } from "date-fns";

export type AuthorProfile = {
  login: string;
  displayName: string;
  firstName: string | null;
  lastName: string | null;
  bio: string | null;
  role: string;
  createdAt: string;
  stats: {
    postCount: number;
    totalViews: number;
    categories: string[];
  };
  posts: {
    id: string;
    slug: string;
    title: string;
    excerpt: string | null;
    coverSeed: string;
    readMinutes: number;
    publishedAt: string;
    views: number;
    featured: boolean;
    categories: { slug: string; name: string }[];
    tags: { slug: string; name: string }[];
  }[];
};

export function AuthorProfileModal({
  authorLogin,
  onClose,
  onOpenArticle,
}: {
  authorLogin: string | null;
  onClose: () => void;
  onOpenArticle: (slug: string) => void;
}) {
  const [author, setAuthor] = useState<AuthorProfile | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!authorLogin) return;
    let cancelled = false;
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setLoading(true);
    fetch(`/api/authors/${authorLogin}`)
      .then((r) => r.json())
      .then((d) => {
        if (!cancelled) setAuthor(d);
      })
      .catch(() => {
        if (!cancelled) setAuthor(null);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [authorLogin]);

  useEffect(() => {
    if (authorLogin) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => {
      document.body.style.overflow = "";
    };
  }, [authorLogin]);

  return (
    <AnimatePresence>
      {authorLogin && (
        <motion.div
          className="fixed inset-0 z-50 flex items-stretch justify-center bg-black/70 backdrop-blur-sm sm:items-center sm:p-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
        >
          <motion.div
            className="relative z-10 flex h-full w-full max-w-3xl flex-col bg-card shadow-2xl sm:h-auto sm:max-h-[90vh] sm:rounded-2xl overflow-hidden border"
            initial={{ y: 30, opacity: 0, scale: 0.98 }}
            animate={{ y: 0, opacity: 1, scale: 1 }}
            exit={{ y: 30, opacity: 0, scale: 0.98 }}
            transition={{ type: "spring", stiffness: 260, damping: 28 }}
            onClick={(e) => e.stopPropagation()}
          >
            {loading ? (
              <div className="flex h-64 items-center justify-center">
                <div className="animate-pulse text-muted-foreground">
                  Loading author profile…
                </div>
              </div>
            ) : author ? (
              <>
                {/* Header banner */}
                <div className="relative h-32 bg-gradient-to-br from-primary via-primary/80 to-amber-600 sm:h-40">
                  <div
                    className="absolute inset-0 opacity-20"
                    style={{
                      backgroundImage:
                        "radial-gradient(circle at 20% 50%, white 1px, transparent 1px), radial-gradient(circle at 80% 30%, white 1px, transparent 1px)",
                      backgroundSize: "24px 24px",
                    }}
                  />
                  <Button
                    variant="secondary"
                    size="icon"
                    className="absolute right-3 top-3 h-9 w-9 rounded-full bg-black/30 text-white hover:bg-black/50 backdrop-blur-sm"
                    onClick={onClose}
                    aria-label="Close"
                  >
                    <X className="h-5 w-5" />
                  </Button>
                </div>

                {/* Avatar + name (overlapping the banner) */}
                <div className="relative px-6 sm:px-8">
                  <div className="-mt-12 flex items-end gap-4 sm:-mt-14">
                    <div className="flex h-24 w-24 shrink-0 items-center justify-center rounded-2xl border-4 border-card bg-primary font-serif text-4xl font-bold text-primary-foreground shadow-lg sm:h-28 sm:w-28">
                      {author.displayName.slice(0, 1)}
                    </div>
                    <div className="pb-2">
                      <h2 className="font-serif text-2xl font-bold tracking-tight sm:text-3xl">
                        {author.displayName}
                      </h2>
                      <div className="mt-1 flex flex-wrap items-center gap-2">
                        <Badge
                          variant={author.role === "owner" ? "default" : "secondary"}
                          className="capitalize"
                        >
                          {author.role}
                        </Badge>
                        <span className="text-xs text-muted-foreground">
                          Joined {format(new Date(author.createdAt), "MMM yyyy")}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Bio */}
                  {author.bio && (
                    <p className="mt-4 text-sm leading-relaxed text-muted-foreground">
                      {author.bio}
                    </p>
                  )}

                  {/* Stats */}
                  <div className="mt-5 grid grid-cols-3 gap-3">
                    <StatCard
                      icon={BookOpen}
                      label="Articles"
                      value={author.stats.postCount}
                    />
                    <StatCard
                      icon={Eye}
                      label="Total views"
                      value={author.stats.totalViews}
                    />
                    <StatCard
                      icon={Award}
                      label="Categories"
                      value={author.stats.categories.length}
                    />
                  </div>

                  {/* Category chips */}
                  {author.stats.categories.length > 0 && (
                    <div className="mt-4 flex flex-wrap gap-1.5">
                      {author.stats.categories.map((c) => (
                        <Badge key={c} variant="outline" className="text-[11px]">
                          {c}
                        </Badge>
                      ))}
                    </div>
                  )}
                </div>

                {/* Posts list */}
                <ScrollArea className="mt-5 max-h-[40vh] min-h-0 scroll-area-thin">
                  <div className="px-6 pb-6 sm:px-8">
                    <div className="mb-3 flex items-center gap-2">
                      <TrendingUp className="h-4 w-4 text-primary" />
                      <h3 className="text-sm font-semibold">
                        Articles by {author.displayName.split(" ")[0]}
                      </h3>
                      <Badge variant="secondary" className="text-[10px]">
                        {author.posts.length}
                      </Badge>
                    </div>
                    <div className="space-y-2">
                      {author.posts.map((p) => (
                        <button
                          key={p.id}
                          onClick={() => onOpenArticle(p.slug)}
                          className="group flex w-full gap-3 rounded-xl border bg-card p-3 text-left transition-all hover:border-primary/40 hover:shadow-sm"
                        >
                          <CoverArt
                            seed={p.coverSeed}
                            title={p.title}
                            className="h-16 w-16 shrink-0 rounded-lg"
                            size="sm"
                          />
                          <div className="flex min-w-0 flex-1 flex-col">
                            {p.categories[0] && (
                              <span className="text-[10px] font-semibold uppercase tracking-wide text-primary">
                                {p.categories[0].name}
                              </span>
                            )}
                            <h4 className="line-clamp-2 text-sm font-semibold leading-snug transition-colors group-hover:text-primary">
                              {p.title}
                            </h4>
                            <div className="mt-auto flex items-center gap-3 pt-1 text-[11px] text-muted-foreground">
                              <span className="flex items-center gap-0.5">
                                <Clock className="h-3 w-3" />
                                {format(new Date(p.publishedAt), "d MMM yyyy")}
                              </span>
                              <span className="flex items-center gap-0.5">
                                <Eye className="h-3 w-3" />
                                {p.views}
                              </span>
                              <span>· {p.readMinutes}m</span>
                            </div>
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>
                </ScrollArea>
              </>
            ) : (
              <div className="flex h-64 items-center justify-center text-muted-foreground">
                Author not found.
              </div>
            )}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

function StatCard({
  icon: Icon,
  label,
  value,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: number;
}) {
  return (
    <div className="rounded-xl border bg-muted/30 p-3 text-center">
      <Icon className="mx-auto mb-1 h-4 w-4 text-primary" />
      <div className="text-xl font-bold tabular-nums">{value.toLocaleString()}</div>
      <div className="text-[10px] uppercase tracking-wide text-muted-foreground">
        {label}
      </div>
    </div>
  );
}
