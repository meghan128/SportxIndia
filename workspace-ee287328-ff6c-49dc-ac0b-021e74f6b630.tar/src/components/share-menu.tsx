"use client";

import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Share2,
  Twitter,
  Linkedin,
  Facebook,
  MessageCircle,
  Mail,
  Link2,
  CheckCircle2,
  ChevronDown,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

type SharePlatform = {
  id: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  color: string;
  getUrl: (url: string, title: string) => string;
};

const PLATFORMS: SharePlatform[] = [
  {
    id: "twitter",
    label: "Twitter / X",
    icon: Twitter,
    color: "hover:bg-black hover:text-white",
    getUrl: (url, title) =>
      `https://twitter.com/intent/tweet?text=${encodeURIComponent(title)}&url=${encodeURIComponent(url)}`,
  },
  {
    id: "linkedin",
    label: "LinkedIn",
    icon: Linkedin,
    color: "hover:bg-[#0A66C2] hover:text-white",
    getUrl: (url, _title) =>
      `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}`,
  },
  {
    id: "facebook",
    label: "Facebook",
    icon: Facebook,
    color: "hover:bg-[#1877F2] hover:text-white",
    getUrl: (url, _title) =>
      `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`,
  },
  {
    id: "whatsapp",
    label: "WhatsApp",
    icon: MessageCircle,
    color: "hover:bg-[#25D366] hover:text-white",
    getUrl: (url, title) =>
      `https://wa.me/?text=${encodeURIComponent(title + " " + url)}`,
  },
  {
    id: "email",
    label: "Email",
    icon: Mail,
    color: "hover:bg-primary hover:text-primary-foreground",
    getUrl: (url, title) =>
      `mailto:?subject=${encodeURIComponent(title)}&body=${encodeURIComponent("Check out this SportX India article: " + url)}`,
  },
];

export function ShareMenu({
  slug,
  title,
  variant = "default",
}: {
  slug: string;
  title: string;
  variant?: "default" | "compact";
}) {
  const [open, setOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const articleUrl = typeof window !== "undefined"
    ? `${window.location.origin}/?article=${slug}`
    : `/?article=${slug}`;

  useEffect(() => {
    const onClick = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    if (open) document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, [open]);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(articleUrl);
      setCopied(true);
      toast.success("Link copied — share the verified original.");
      setTimeout(() => setCopied(false), 2000);
    } catch {
      toast.error("Could not copy link.");
    }
  };

  const handleShare = (platform: SharePlatform) => {
    const url = platform.getUrl(articleUrl, title);
    window.open(url, "_blank", "noopener,noreferrer,width=600,height=500");
    setOpen(false);
  };

  if (variant === "compact") {
    return (
      <div ref={menuRef} className="relative">
        <Button
          variant="outline"
          size="sm"
          onClick={() => setOpen((v) => !v)}
          className="gap-1.5"
        >
          <Share2 className="h-4 w-4" />
          Share
          <ChevronDown className={`h-3 w-3 transition-transform ${open ? "rotate-180" : ""}`} />
        </Button>
        <AnimatePresence>
          {open && (
            <motion.div
              initial={{ opacity: 0, y: -8, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -8, scale: 0.95 }}
              transition={{ duration: 0.15 }}
              className="absolute right-0 top-full z-50 mt-2 w-52 overflow-hidden rounded-xl border bg-card shadow-xl"
            >
              <div className="p-1.5">
                {PLATFORMS.map((p) => {
                  const Icon = p.icon;
                  return (
                    <button
                      key={p.id}
                      onClick={() => handleShare(p)}
                      className={`flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-sm transition-colors ${p.color}`}
                    >
                      <Icon className="h-4 w-4" />
                      {p.label}
                    </button>
                  );
                })}
                <div className="my-1 border-t" />
                <button
                  onClick={handleCopy}
                  className="flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-sm transition-colors hover:bg-muted"
                >
                  {copied ? (
                    <CheckCircle2 className="h-4 w-4 text-emerald-600" />
                  ) : (
                    <Link2 className="h-4 w-4" />
                  )}
                  {copied ? "Copied!" : "Copy link"}
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    );
  }

  // Default — inline row of icons (for article reader share section)
  return (
    <div ref={menuRef} className="flex flex-wrap items-center gap-2">
      {PLATFORMS.map((p) => {
        const Icon = p.icon;
        return (
          <button
            key={p.id}
            onClick={() => handleShare(p)}
            aria-label={`Share on ${p.label}`}
            title={`Share on ${p.label}`}
            className={`flex h-9 w-9 items-center justify-center rounded-lg border bg-card transition-all hover:scale-110 hover:border-transparent ${p.color}`}
          >
            <Icon className="h-4 w-4" />
          </button>
        );
      })}
      <button
        onClick={handleCopy}
        aria-label="Copy link"
        title="Copy link"
        className="flex h-9 w-9 items-center justify-center rounded-lg border bg-card transition-all hover:scale-110 hover:bg-muted"
      >
        {copied ? (
          <CheckCircle2 className="h-4 w-4 text-emerald-600" />
        ) : (
          <Link2 className="h-4 w-4" />
        )}
      </button>
    </div>
  );
}
