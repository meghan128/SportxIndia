"use client";

import { useEffect, useState, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  MessageCircle,
  X,
  Send,
  Trash2,
  Reply,
  Heart,
  Clock,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { toast } from "sonner";
import { formatDistanceToNow } from "date-fns";

const STORAGE_PREFIX = "sportx-comments-";

export type Comment = {
  id: string;
  slug: string;
  author: string;
  text: string;
  createdAt: string;
  likes: number;
  liked: boolean;
  parentId: string | null;
};

/**
 * useComments — hook for localStorage-based comments per article.
 */
export function useComments(slug: string | null) {
  const [comments, setComments] = useState<Comment[]>([]);

  useEffect(() => {
    if (!slug) {
      let raf = requestAnimationFrame(() => setComments([]));
      return () => cancelAnimationFrame(raf);
    }
    let raf = requestAnimationFrame(() => {
      try {
        const raw = localStorage.getItem(STORAGE_PREFIX + slug);
        if (raw) {
          setComments(JSON.parse(raw));
        } else {
          setComments([]);
        }
      } catch {
        setComments([]);
      }
    });
    return () => cancelAnimationFrame(raf);
  }, [slug]);

  const persist = useCallback(
    (next: Comment[]) => {
      if (!slug) return;
      try {
        localStorage.setItem(STORAGE_PREFIX + slug, JSON.stringify(next));
      } catch {
        // ignore
      }
    },
    [slug]
  );

  const addComment = useCallback(
    (author: string, text: string, parentId: string | null = null) => {
      if (!slug || !text.trim() || !author.trim()) return;
      const comment: Comment = {
        id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
        slug,
        author: author.trim(),
        text: text.trim(),
        createdAt: new Date().toISOString(),
        likes: 0,
        liked: false,
        parentId,
      };
      setComments((prev) => {
        const next = [comment, ...prev];
        persist(next);
        return next;
      });
      toast.success("Comment posted", { duration: 1500 });
    },
    [slug, persist]
  );

  const toggleLike = useCallback(
    (id: string) => {
      setComments((prev) => {
        const next = prev.map((c) =>
          c.id === id
            ? {
                ...c,
                liked: !c.liked,
                likes: c.liked ? c.likes - 1 : c.likes + 1,
              }
            : c
        );
        persist(next);
        return next;
      });
    },
    [persist]
  );

  const deleteComment = useCallback(
    (id: string) => {
      setComments((prev) => {
        const next = prev.filter((c) => c.id !== id && c.parentId !== id);
        persist(next);
        return next;
      });
      toast.success("Comment deleted", { duration: 1200 });
    },
    [persist]
  );

  return { comments, addComment, toggleLike, deleteComment };
}

/**
 * CommentsPanel — slide-in panel for viewing and posting comments.
 */
export function CommentsPanel({
  open,
  onOpenChange,
  slug,
  comments,
  onAdd,
  onLike,
  onDelete,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  slug: string | null;
  comments: Comment[];
  onAdd: (author: string, text: string, parentId: string | null) => void;
  onLike: (id: string) => void;
  onDelete: (id: string) => void;
}) {
  const [author, setAuthor] = useState("");
  const [text, setText] = useState("");
  const [replyTo, setReplyTo] = useState<string | null>(null);

  // Persist author name across sessions
  useEffect(() => {
    let raf = requestAnimationFrame(() => {
      try {
        const saved = localStorage.getItem("sportx-comment-author");
        if (saved) setAuthor(saved);
      } catch {
        // ignore
      }
    });
    return () => cancelAnimationFrame(raf);
  }, []);

  const handleSubmit = () => {
    if (!author.trim()) {
      toast.error("Please enter your name.");
      return;
    }
    if (!text.trim()) {
      toast.error("Please write a comment.");
      return;
    }
    try {
      localStorage.setItem("sportx-comment-author", author.trim());
    } catch {
      // ignore
    }
    onAdd(author, text, replyTo);
    setText("");
    setReplyTo(null);
  };

  // Group comments: top-level + replies
  const topLevel = comments.filter((c) => !c.parentId);
  const getReplies = (parentId: string) =>
    comments.filter((c) => c.parentId === parentId);

  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div
            className="fixed inset-0 z-[55] bg-black/40 backdrop-blur-sm"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => onOpenChange(false)}
          />
          <motion.div
            className="fixed right-0 top-0 z-[56] flex h-full w-full max-w-md flex-col border-l bg-card shadow-2xl"
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
          >
            {/* Header */}
            <div className="flex items-center justify-between border-b p-4">
              <div className="flex items-center gap-2">
                <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10 text-primary">
                  <MessageCircle className="h-5 w-5" />
                </div>
                <div>
                  <h2 className="font-serif text-lg font-bold">Discussion</h2>
                  <p className="text-xs text-muted-foreground">
                    {comments.length} comment{comments.length !== 1 ? "s" : ""}
                  </p>
                </div>
              </div>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={() => onOpenChange(false)}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>

            {/* Comment form */}
            <div className="border-b p-4">
              {replyTo && (
                <div className="mb-2 flex items-center gap-2 text-xs text-muted-foreground">
                  <Reply className="h-3 w-3" />
                  Replying to a comment
                  <button
                    onClick={() => setReplyTo(null)}
                    className="text-primary hover:underline"
                  >
                    Cancel
                  </button>
                </div>
              )}
              <div className="flex gap-2">
                <Input
                  value={author}
                  onChange={(e) => setAuthor(e.target.value)}
                  placeholder="Your name"
                  className="w-32 shrink-0"
                  maxLength={30}
                />
                <Textarea
                  value={text}
                  onChange={(e) => setText(e.target.value)}
                  placeholder="Share your thoughts…"
                  rows={2}
                  maxLength={500}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) {
                      e.preventDefault();
                      handleSubmit();
                    }
                  }}
                />
              </div>
              <div className="mt-2 flex items-center justify-between">
                <span className="text-[11px] text-muted-foreground">
                  {text.length}/500 · ⌘+Enter to post
                </span>
                <Button size="sm" onClick={handleSubmit} className="gap-1.5">
                  <Send className="h-3.5 w-3.5" />
                  Post
                </Button>
              </div>
            </div>

            {/* Comments list */}
            <ScrollArea className="flex-1 min-h-0 scroll-area-thin">
              {topLevel.length === 0 ? (
                <div className="flex flex-col items-center justify-center px-6 py-16 text-center">
                  <div className="mb-3 flex h-14 w-14 items-center justify-center rounded-full bg-muted">
                    <MessageCircle className="h-7 w-7 text-muted-foreground" />
                  </div>
                  <h3 className="font-semibold">Be the first to comment</h3>
                  <p className="mt-1 max-w-xs text-sm text-muted-foreground">
                    Share your thoughts on this article. Comments are stored
                    locally on your device.
                  </p>
                </div>
              ) : (
                <div className="space-y-3 p-4">
                  {topLevel.map((comment, i) => (
                    <motion.div
                      key={comment.id}
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.04 }}
                    >
                      <CommentItem
                        comment={comment}
                        replies={getReplies(comment.id)}
                        onLike={onLike}
                        onDelete={onDelete}
                        onReply={(id) => {
                          setReplyTo(id);
                        }}
                      />
                    </motion.div>
                  ))}
                </div>
              )}
            </ScrollArea>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

function CommentItem({
  comment,
  replies,
  onLike,
  onDelete,
  onReply,
}: {
  comment: Comment;
  replies: Comment[];
  onLike: (id: string) => void;
  onDelete: (id: string) => void;
  onReply: (id: string) => void;
}) {
  const [showActions, setShowActions] = useState(false);

  return (
    <div
      className="group rounded-xl border bg-card p-3"
      onMouseEnter={() => setShowActions(true)}
      onMouseLeave={() => setShowActions(false)}
    >
      <div className="flex items-start gap-2.5">
        <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary/10 text-xs font-semibold text-primary">
          {comment.author.slice(0, 1).toUpperCase()}
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <span className="text-sm font-semibold">{comment.author}</span>
            <span className="flex items-center gap-0.5 text-[10px] text-muted-foreground">
              <Clock className="h-2.5 w-2.5" />
              {formatDistanceToNow(new Date(comment.createdAt), { addSuffix: true })}
            </span>
          </div>
          <p className="mt-1 text-sm leading-relaxed text-foreground/90">
            {comment.text}
          </p>

          {/* Actions */}
          <div className="mt-2 flex items-center gap-3">
            <button
              onClick={() => onLike(comment.id)}
              className={`flex items-center gap-1 text-xs transition-colors ${
                comment.liked
                  ? "text-rose-500"
                  : "text-muted-foreground hover:text-rose-500"
              }`}
            >
              <Heart className={`h-3 w-3 ${comment.liked ? "fill-current" : ""}`} />
              {comment.likes > 0 && (
                <span className="tabular-nums">{comment.likes}</span>
              )}
            </button>
            <button
              onClick={() => onReply(comment.id)}
              className="flex items-center gap-1 text-xs text-muted-foreground transition-colors hover:text-primary"
            >
              <Reply className="h-3 w-3" />
              Reply
            </button>
            {showActions && (
              <button
                onClick={() => onDelete(comment.id)}
                className="flex items-center gap-1 text-xs text-muted-foreground transition-colors hover:text-destructive"
              >
                <Trash2 className="h-3 w-3" />
                Delete
              </button>
            )}
          </div>

          {/* Replies */}
          {replies.length > 0 && (
            <div className="mt-3 space-y-2 border-l-2 pl-3">
              {replies.map((reply) => (
                <div key={reply.id} className="flex items-start gap-2">
                  <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-muted text-[10px] font-semibold text-muted-foreground">
                    {reply.author.slice(0, 1).toUpperCase()}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-semibold">{reply.author}</span>
                      <span className="text-[10px] text-muted-foreground">
                        {formatDistanceToNow(new Date(reply.createdAt), { addSuffix: true })}
                      </span>
                    </div>
                    <p className="mt-0.5 text-xs leading-relaxed text-foreground/90">
                      {reply.text}
                    </p>
                    <button
                      onClick={() => onLike(reply.id)}
                      className={`mt-1 flex items-center gap-1 text-[10px] transition-colors ${
                        reply.liked
                          ? "text-rose-500"
                          : "text-muted-foreground hover:text-rose-500"
                      }`}
                    >
                      <Heart className={`h-2.5 w-2.5 ${reply.liked ? "fill-current" : ""}`} />
                      {reply.likes > 0 && <span className="tabular-nums">{reply.likes}</span>}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
