"use client";

import { useEffect, useState, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Calendar, ChevronDown, Hash, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { CoverArt } from "@/components/cover-art";
import type { PostSummary } from "@/lib/types";
import { format } from "date-fns";

type GroupedPosts = {
  year: number;
  months: {
    month: number;
    monthName: string;
    posts: PostSummary[];
  }[];
  total: number;
};

export function ArchiveTimeline({
  open,
  onOpenChange,
  onOpenArticle,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  onOpenArticle: (slug: string) => void;
}) {
  const [posts, setPosts] = useState<PostSummary[]>([]);
  const [loading, setLoading] = useState(false);
  const [expandedYears, setExpandedYears] = useState<Set<number>>(new Set());
  const [expandedMonths, setExpandedMonths] = useState<Set<string>>(new Set());

  useEffect(() => {
    if (!open) return;
    let cancelled = false;
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setLoading(true);
    fetch("/api/posts?limit=100&sort=oldest")
      .then((r) => r.json())
      .then((d) => {
        if (cancelled) return;
        setPosts(d.posts ?? []);
        // Expand the most recent year by default
        const years = [...new Set((d.posts ?? []).map((p: PostSummary) => new Date(p.publishedAt).getFullYear()))];
        if (years.length > 0) {
          setExpandedYears(new Set([Math.max(...years)]));
        }
      })
      .catch(() => {
        if (!cancelled) setPosts([]);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [open]);

  // Group posts by year → month
  const grouped = useMemo<GroupedPosts[]>(() => {
    const map = new Map<number, Map<number, PostSummary[]>>();
    for (const p of posts) {
      const date = new Date(p.publishedAt);
      const year = date.getFullYear();
      const month = date.getMonth();
      if (!map.has(year)) map.set(year, new Map());
      if (!map.get(year)!.has(month)) map.get(year)!.set(month, []);
      map.get(year)!.get(month)!.push(p);
    }
    return Array.from(map.entries())
      .sort((a, b) => b[0] - a[0])
      .map(([year, monthMap]) => ({
        year,
        total: Array.from(monthMap.values()).reduce((s, arr) => s + arr.length, 0),
        months: Array.from(monthMap.entries())
          .sort((a, b) => b[0] - a[0])
          .map(([month, monthPosts]) => ({
            month,
            monthName: format(new Date(2024, month, 1), "MMMM"),
            posts: monthPosts,
          })),
      }));
  }, [posts]);

  const toggleYear = (year: number) => {
    setExpandedYears((prev) => {
      const next = new Set(prev);
      if (next.has(year)) next.delete(year);
      else next.add(year);
      return next;
    });
  };

  const toggleMonth = (key: string) => {
    setExpandedMonths((prev) => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  };

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="fixed inset-0 z-50 flex items-stretch justify-center bg-black/70 backdrop-blur-sm sm:items-center sm:p-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={() => onOpenChange(false)}
        >
          <motion.div
            className="relative z-10 flex h-full w-full max-w-2xl flex-col bg-card shadow-2xl sm:h-auto sm:max-h-[90vh] sm:rounded-2xl overflow-hidden border"
            initial={{ y: 30, opacity: 0, scale: 0.98 }}
            animate={{ y: 0, opacity: 1, scale: 1 }}
            exit={{ y: 30, opacity: 0, scale: 0.98 }}
            transition={{ type: "spring", stiffness: 260, damping: 28 }}
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="relative overflow-hidden border-b bg-gradient-to-br from-primary/10 via-card to-emerald-500/10 p-5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10 text-primary">
                    <Calendar className="h-5 w-5" />
                  </div>
                  <div>
                    <h2 className="font-serif text-xl font-bold">Article Archive</h2>
                    <p className="text-xs text-muted-foreground">
                      {posts.length} articles · browse by date
                    </p>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8"
                  onClick={() => onOpenChange(false)}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </div>

            <ScrollArea className="flex-1 min-h-0 scroll-area-thin">
              <div className="p-5">
                {loading ? (
                  <div className="space-y-3">
                    {Array.from({ length: 4 }).map((_, i) => (
                      <div key={i} className="h-16 animate-pulse rounded-xl bg-muted" />
                    ))}
                  </div>
                ) : grouped.length === 0 ? (
                  <p className="py-8 text-center text-sm text-muted-foreground">
                    No articles found.
                  </p>
                ) : (
                  <div className="space-y-3">
                    {grouped.map((yearGroup) => {
                      const isExpanded = expandedYears.has(yearGroup.year);
                      return (
                        <div
                          key={yearGroup.year}
                          className="overflow-hidden rounded-xl border"
                        >
                          {/* Year header */}
                          <button
                            onClick={() => toggleYear(yearGroup.year)}
                            className="flex w-full items-center gap-3 bg-muted/50 px-4 py-3 text-left transition-colors hover:bg-muted"
                          >
                            <ChevronDown
                              className={`h-4 w-4 shrink-0 transition-transform ${
                                isExpanded ? "" : "-rotate-90"
                              }`}
                            />
                            <span className="font-serif text-lg font-bold">
                              {yearGroup.year}
                            </span>
                            <Badge variant="secondary" className="text-xs">
                              {yearGroup.total} {yearGroup.total === 1 ? "article" : "articles"}
                            </Badge>
                          </button>

                          {/* Months */}
                          <AnimatePresence initial={false}>
                            {isExpanded && (
                              <motion.div
                                initial={{ height: 0, opacity: 0 }}
                                animate={{ height: "auto", opacity: 1 }}
                                exit={{ height: 0, opacity: 0 }}
                                transition={{ duration: 0.2 }}
                                className="overflow-hidden"
                              >
                                <div className="divide-y border-t">
                                  {yearGroup.months.map((monthGroup) => {
                                    const monthKey = `${yearGroup.year}-${monthGroup.month}`;
                                    const monthExpanded = expandedMonths.has(monthKey);
                                    return (
                                      <div key={monthKey}>
                                        <button
                                          onClick={() => toggleMonth(monthKey)}
                                          className="flex w-full items-center gap-2 px-4 py-2.5 text-left text-sm transition-colors hover:bg-muted/30"
                                        >
                                          <ChevronDown
                                            className={`h-3.5 w-3.5 shrink-0 text-muted-foreground transition-transform ${
                                              monthExpanded ? "" : "-rotate-90"
                                            }`}
                                          />
                                          <span className="font-medium">{monthGroup.monthName}</span>
                                          <span className="text-xs text-muted-foreground">
                                            {monthGroup.posts.length}
                                          </span>
                                        </button>
                                        <AnimatePresence initial={false}>
                                          {monthExpanded && (
                                            <motion.div
                                              initial={{ height: 0, opacity: 0 }}
                                              animate={{ height: "auto", opacity: 1 }}
                                              exit={{ height: 0, opacity: 0 }}
                                              transition={{ duration: 0.2 }}
                                              className="overflow-hidden"
                                            >
                                              <div className="space-y-1.5 px-4 pb-3">
                                                {monthGroup.posts.map((post, i) => (
                                                  <motion.button
                                                    key={post.slug}
                                                    initial={{ opacity: 0, x: -8 }}
                                                    animate={{ opacity: 1, x: 0 }}
                                                    transition={{ delay: i * 0.03 }}
                                                    onClick={() => {
                                                      onOpenChange(false);
                                                      onOpenArticle(post.slug);
                                                    }}
                                                    className="group flex w-full gap-3 rounded-lg border bg-card p-2 text-left transition-all hover:border-primary/40 hover:shadow-sm"
                                                  >
                                                    <CoverArt
                                                      seed={post.coverSeed}
                                                      title={post.title}
                                                      className="h-12 w-12 shrink-0 rounded-md"
                                                      size="sm"
                                                    />
                                                    <div className="flex min-w-0 flex-1 flex-col">
                                                      <h4 className="line-clamp-2 text-xs font-semibold leading-snug transition-colors group-hover:text-primary">
                                                        {post.title}
                                                      </h4>
                                                      <div className="flex items-center gap-2 pt-1 text-[10px] text-muted-foreground">
                                                        <span>{post.author.displayName.split(" ")[0]}</span>
                                                        <span>·</span>
                                                        <span>{format(new Date(post.publishedAt), "d MMM")}</span>
                                                        {post.categories[0] && (
                                                          <>
                                                            <span>·</span>
                                                            <span className="text-primary/70">
                                                              {post.categories[0].name}
                                                            </span>
                                                          </>
                                                        )}
                                                      </div>
                                                    </div>
                                                    <ArrowRight className="h-3.5 w-3.5 shrink-0 self-center text-muted-foreground transition-all group-hover:translate-x-0.5 group-hover:text-primary" />
                                                  </motion.button>
                                                ))}
                                              </div>
                                            </motion.div>
                                          )}
                                        </AnimatePresence>
                                      </div>
                                    );
                                  })}
                                </div>
                              </motion.div>
                            )}
                          </AnimatePresence>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </ScrollArea>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
