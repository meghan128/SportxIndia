"use client";

import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight } from "lucide-react";

/**
 * Numbered pagination with page numbers (1, 2, 3 ... N) instead of just
 * Previous/Next. Shows a window of pages around the current one.
 */
export function NumberedPagination({
  total,
  limit,
  offset,
  onPageChange,
}: {
  total: number;
  limit: number;
  offset: number;
  onPageChange: (offset: number) => void;
}) {
  if (total <= limit) return null;

  const currentPage = Math.floor(offset / limit);
  const totalPages = Math.ceil(total / limit);
  const maxButtons = 5;

  // Build the page number window
  let startPage = Math.max(0, currentPage - Math.floor(maxButtons / 2));
  let endPage = startPage + maxButtons - 1;
  if (endPage >= totalPages) {
    endPage = totalPages - 1;
    startPage = Math.max(0, endPage - maxButtons + 1);
  }

  const pages: (number | "...")[] = [];
  if (startPage > 0) {
    pages.push(0);
    if (startPage > 1) pages.push("...");
  }
  for (let i = startPage; i <= endPage; i++) {
    pages.push(i);
  }
  if (endPage < totalPages - 1) {
    if (endPage < totalPages - 2) pages.push("...");
    pages.push(totalPages - 1);
  }

  return (
    <div className="mt-10 flex flex-wrap items-center justify-center gap-2">
      <Button
        variant="outline"
        size="sm"
        disabled={currentPage === 0}
        onClick={() => onPageChange(Math.max(0, offset - limit))}
        className="gap-1"
      >
        <ChevronLeft className="h-4 w-4" />
        Prev
      </Button>

      <div className="flex items-center gap-1">
        {pages.map((p, i) =>
          p === "..." ? (
            <span
              key={`ellipsis-${i}`}
              className="px-2 text-sm text-muted-foreground"
            >
              …
            </span>
          ) : (
            <Button
              key={p}
              variant={p === currentPage ? "default" : "outline"}
              size="sm"
              onClick={() => onPageChange(p * limit)}
              className={
                p === currentPage
                  ? "min-w-9 font-semibold tabular-nums"
                  : "min-w-9 tabular-nums"
              }
            >
              {p + 1}
            </Button>
          )
        )}
      </div>

      <Button
        variant="outline"
        size="sm"
        disabled={offset + limit >= total}
        onClick={() => onPageChange(offset + limit)}
        className="gap-1"
      >
        Next
        <ChevronRight className="h-4 w-4" />
      </Button>

      <span className="ml-2 text-sm text-muted-foreground tabular-nums">
        {offset + 1}–{Math.min(offset + limit, total)} of {total}
      </span>
    </div>
  );
}
