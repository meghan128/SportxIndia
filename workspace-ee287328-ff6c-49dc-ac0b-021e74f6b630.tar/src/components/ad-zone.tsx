"use client";

import { useEffect, useState } from "react";

type AdMap = Record<string, string>;

// Cache ad zones at the module level so we only fetch once
let adCache: AdMap | null = null;

/**
 * AdZone — renders ad code for a given slot (header, sidebar, in-article, footer).
 * Fetches active ad zones from /api/ads on first render, then caches.
 * Renders nothing if no ad is configured for the slot.
 */
export function AdZone({
  slot,
  className,
}: {
  slot: "header" | "sidebar" | "in-article" | "footer";
  className?: string;
}) {
  const [ads, setAds] = useState<AdMap | null>(adCache);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    if (adCache) {
      let raf = requestAnimationFrame(() => {
        setAds(adCache);
        setLoaded(true);
      });
      return () => cancelAnimationFrame(raf);
    }
    fetch("/api/ads")
      .then((r) => r.json())
      .then((d) => {
        adCache = d.ads ?? {};
        setAds(adCache);
        setLoaded(true);
      })
      .catch(() => setLoaded(true));
  }, []);

  if (!loaded || !ads || !ads[slot]) return null;

  return (
    <div
      className={`ad-zone overflow-hidden ${className ?? ""}`}
      dangerouslySetInnerHTML={{ __html: ads[slot] }}
    />
  );
}
