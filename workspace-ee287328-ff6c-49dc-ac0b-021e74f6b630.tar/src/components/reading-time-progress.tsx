"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Clock, CheckCircle2 } from "lucide-react";

/**
 * ReadingTimeProgress — shows the user's reading progress as a percentage
 * and estimated remaining time. Appears in the article reader as a small
 * floating badge that updates as the user scrolls.
 *
 * @param scrollRef — ref to the ScrollArea root element
 * @param readMinutes — total estimated read time in minutes
 * @param visible — whether to show the badge
 */
export function ReadingTimeProgress({
  scrollRef,
  readMinutes,
  visible,
}: {
  scrollRef: React.RefObject<HTMLElement | null>;
  readMinutes: number;
  visible: boolean;
}) {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    if (!visible) return;
    const viewport = scrollRef.current?.querySelector(
      "[data-radix-scroll-area-viewport]"
    ) as HTMLElement | null;
    if (!viewport) return;

    const onScroll = () => {
      const scrolled = viewport.scrollTop;
      const height = viewport.scrollHeight - viewport.clientHeight;
      setProgress(height > 0 ? Math.min(100, (scrolled / height) * 100) : 0);
    };

    viewport.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
    return () => viewport.removeEventListener("scroll", onScroll);
  }, [scrollRef, visible]);

  const remainingMin = Math.max(0, Math.ceil(readMinutes * (1 - progress / 100)));
  const isComplete = progress >= 95;

  return (
    <AnimatePresence>
      {visible && progress > 2 && (
        <motion.div
          initial={{ opacity: 0, y: -10, scale: 0.9 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: -10, scale: 0.9 }}
          className="absolute left-1/2 top-3 z-20 -translate-x-1/2"
        >
          <div
            className={`flex items-center gap-2 rounded-full border px-3 py-1 text-xs font-medium shadow-lg backdrop-blur-md transition-colors ${
              isComplete
                ? "border-emerald-500/40 bg-emerald-50/90 text-emerald-700 dark:bg-emerald-950/80 dark:text-emerald-300"
                : "border-border bg-card/90 text-muted-foreground"
            }`}
          >
            {isComplete ? (
              <>
                <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600" />
                <span>Article complete</span>
              </>
            ) : (
              <>
                <Clock className="h-3.5 w-3.5 text-primary" />
                <span className="tabular-nums">{Math.round(progress)}%</span>
                <span className="text-muted-foreground/60">·</span>
                <span>{remainingMin} min left</span>
              </>
            )}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
