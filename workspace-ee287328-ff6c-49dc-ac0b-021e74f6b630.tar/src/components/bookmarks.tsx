"use client";

import { useEffect, useState, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Bookmark,
  BookmarkX,
  Clock,
  Eye,
  X,
  BookOpen,
  Trash2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { CoverArt } from "@/components/cover-art";
import { ReadingListExport } from "@/components/reading-list-export";
import { format } from "date-fns";
import { toast } from "sonner";

const STORAGE_KEY = "sportx-bookmarks";

export type BookmarkEntry = {
  slug: string;
  title: string;
  excerpt: string | null;
  coverSeed: string;
  author: { login: string; displayName: string };
  publishedAt: string;
  readMinutes: number;
  bookmarkedAt: string;
};

export function useBookmarks() {
  const [bookmarks, setBookmarks] = useState<BookmarkEntry[]>([]);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        // eslint-disable-next-line react-hooks/set-state-in-effect
        setBookmarks(JSON.parse(raw));
      }
    } catch {
      // ignore
    }
  }, []);

  const persist = (next: BookmarkEntry[]) => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
    } catch {
      // ignore
    }
  };

  const isBookmarked = useCallback(
    (slug: string) => bookmarks.some((b) => b.slug === slug),
    [bookmarks]
  );

  const toggleBookmark = useCallback(
    (post: Omit<BookmarkEntry, "bookmarkedAt">) => {
      setBookmarks((prev) => {
        const existing = prev.find((b) => b.slug === post.slug);
        if (existing) {
          const next = prev.filter((b) => b.slug !== post.slug);
          persist(next);
          toast.success("Removed from bookmarks");
          return next;
        }
        const entry: BookmarkEntry = {
          ...post,
          bookmarkedAt: new Date().toISOString(),
        };
        const next = [entry, ...prev].slice(0, 50);
        persist(next);
        toast.success("Bookmarked for later", {
          description: post.title.slice(0, 60),
        });
        return next;
      });
    },
    []
  );

  const removeBookmark = useCallback((slug: string) => {
    setBookmarks((prev) => {
      const next = prev.filter((b) => b.slug !== slug);
      persist(next);
      return next;
    });
  }, []);

  const clearAll = useCallback(() => {
    setBookmarks([]);
    try {
      localStorage.removeItem(STORAGE_KEY);
    } catch {
      // ignore
    }
  }, []);

  return { bookmarks, isBookmarked, toggleBookmark, removeBookmark, clearAll };
}

// Bookmark toggle button — used in the article reader
export function BookmarkButton({
  slug,
  title,
  excerpt,
  coverSeed,
  author,
  publishedAt,
  readMinutes,
  isBookmarked,
  onToggle,
}: {
  slug: string;
  title: string;
  excerpt: string | null;
  coverSeed: string;
  author: { login: string; displayName: string };
  publishedAt: string;
  readMinutes: number;
  isBookmarked: boolean;
  onToggle: () => void;
}) {
  return (
    <Button
      variant={isBookmarked ? "default" : "outline"}
      size="sm"
      onClick={onToggle}
      className={isBookmarked ? "gap-1.5" : "gap-1.5"}
    >
      {isBookmarked ? (
        <>
          <Bookmark className="h-4 w-4 fill-current" />
          Bookmarked
        </>
      ) : (
        <>
          <Bookmark className="h-4 w-4" />
          Bookmark
        </>
      )}
    </Button>
  );
}

// Bookmarks drawer — slide-in panel showing all saved articles
export function BookmarksDrawer({
  open,
  onOpenChange,
  bookmarks,
  onOpenArticle,
  onRemove,
  onClear,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  bookmarks: BookmarkEntry[];
  onOpenArticle: (slug: string) => void;
  onRemove: (slug: string) => void;
  onClear: () => void;
}) {
  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div
            className="fixed inset-0 z-40 bg-black/50 backdrop-blur-sm"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => onOpenChange(false)}
          />
          <motion.div
            className="fixed right-0 top-0 z-50 flex h-full w-full max-w-md flex-col border-l bg-card shadow-2xl"
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
          >
            {/* Header */}
            <div className="flex items-center justify-between border-b p-4">
              <div className="flex items-center gap-2">
                <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary text-primary-foreground">
                  <BookOpen className="h-5 w-5" />
                </div>
                <div>
                  <h2 className="font-serif text-lg font-bold">Bookmarks</h2>
                  <p className="text-xs text-muted-foreground">
                    {bookmarks.length} saved article
                    {bookmarks.length !== 1 ? "s" : ""}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                {bookmarks.length > 0 && (
                  <>
                    <ReadingListExport bookmarks={bookmarks} />
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={onClear}
                      className="text-xs text-muted-foreground hover:text-destructive"
                    >
                      <Trash2 className="mr-1 h-3.5 w-3.5" />
                      Clear
                    </Button>
                  </>
                )}
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8"
                  onClick={() => onOpenChange(false)}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </div>

            {/* List */}
            <ScrollArea className="flex-1 min-h-0 scroll-area-thin">
              {bookmarks.length === 0 ? (
                <div className="flex flex-col items-center justify-center px-6 py-20 text-center">
                  <div className="mb-3 flex h-14 w-14 items-center justify-center rounded-full bg-muted">
                    <Bookmark className="h-7 w-7 text-muted-foreground" />
                  </div>
                  <h3 className="font-semibold">No bookmarks yet</h3>
                  <p className="mt-1 max-w-xs text-sm text-muted-foreground">
                    Save articles to read later. Click the bookmark icon in any
                    article to add it here.
                  </p>
                </div>
              ) : (
                <div className="space-y-2 p-3">
                  {bookmarks.map((b, i) => (
                    <motion.div
                      key={b.slug}
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: i * 0.04 }}
                      className="group relative flex gap-3 rounded-xl border bg-card p-3 transition-colors hover:border-primary/40"
                    >
                      <button
                        onClick={() => onOpenArticle(b.slug)}
                        className="flex flex-1 gap-3 text-left"
                      >
                        <CoverArt
                          seed={b.coverSeed}
                          title={b.title}
                          className="h-16 w-16 shrink-0 rounded-lg"
                          size="sm"
                        />
                        <div className="flex min-w-0 flex-1 flex-col">
                          <h4 className="line-clamp-2 text-sm font-semibold leading-snug transition-colors group-hover:text-primary">
                            {b.title}
                          </h4>
                          {b.excerpt && (
                            <p className="mt-0.5 line-clamp-1 text-[11px] text-muted-foreground">
                              {b.excerpt}
                            </p>
                          )}
                          <div className="mt-auto flex items-center gap-2 pt-1 text-[10px] text-muted-foreground">
                            <span className="flex items-center gap-0.5">
                              <Clock className="h-2.5 w-2.5" />
                              {format(new Date(b.publishedAt), "d MMM yy")}
                            </span>
                            <span>· {b.author.displayName.split(" ")[0]}</span>
                            <span>· {b.readMinutes}m</span>
                          </div>
                        </div>
                      </button>
                      <button
                        onClick={() => onRemove(b.slug)}
                        className="absolute right-2 top-2 flex h-6 w-6 items-center justify-center rounded-full bg-background/80 text-muted-foreground opacity-0 backdrop-blur-sm transition-all hover:bg-destructive/10 hover:text-destructive group-hover:opacity-100"
                        aria-label="Remove bookmark"
                      >
                        <BookmarkX className="h-3.5 w-3.5" />
                      </button>
                    </motion.div>
                  ))}
                </div>
              )}
            </ScrollArea>

            {/* Footer */}
            {bookmarks.length > 0 && (
              <div className="border-t p-3 text-center text-xs text-muted-foreground">
                <Badge variant="outline" className="gap-1">
                  <BookOpen className="h-3 w-3" />
                  {bookmarks.length} saved
                </Badge>
              </div>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
