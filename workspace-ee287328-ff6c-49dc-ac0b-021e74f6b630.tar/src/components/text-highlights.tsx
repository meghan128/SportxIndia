"use client";

import { useEffect, useState, useCallback, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Highlighter, X, Trash2, Quote } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { toast } from "sonner";

const STORAGE_PREFIX = "sportx-highlights-";

export type Highlight = {
  id: string;
  slug: string;
  text: string;
  note: string | null;
  createdAt: string;
  color: string;
};

export const HIGHLIGHT_COLORS = [
  { id: "yellow", label: "Yellow", bg: "bg-yellow-200 dark:bg-yellow-900/40", text: "text-yellow-900 dark:text-yellow-100", hex: "#fef08a" },
  { id: "green", label: "Green", bg: "bg-emerald-200 dark:bg-emerald-900/40", text: "text-emerald-900 dark:text-emerald-100", hex: "#a7f3d0" },
  { id: "blue", label: "Blue", bg: "bg-sky-200 dark:bg-sky-900/40", text: "text-sky-900 dark:text-sky-100", hex: "#bae6fd" },
  { id: "pink", label: "Pink", bg: "bg-pink-200 dark:bg-pink-900/40", text: "text-pink-900 dark:text-pink-100", hex: "#fbcfe8" },
];

// Keep COLORS export for backward compatibility
const COLORS = HIGHLIGHT_COLORS;

/**
 * useHighlights — hook for saving/loading text highlights per article.
 * Uses localStorage with key `sportx-highlights-{slug}`.
 */
export function useHighlights(slug: string | null) {
  const [highlights, setHighlights] = useState<Highlight[]>([]);
  const [activeColor, setActiveColor] = useState(COLORS[0].id);

  useEffect(() => {
    if (!slug) {
      let raf = requestAnimationFrame(() => setHighlights([]));
      return () => cancelAnimationFrame(raf);
    }
    let raf = requestAnimationFrame(() => {
      try {
        const raw = localStorage.getItem(STORAGE_PREFIX + slug);
        if (raw) {
          setHighlights(JSON.parse(raw));
        } else {
          setHighlights([]);
        }
      } catch {
        setHighlights([]);
      }
    });
    return () => cancelAnimationFrame(raf);
  }, [slug]);

  const persist = useCallback(
    (next: Highlight[]) => {
      if (!slug) return;
      try {
        localStorage.setItem(STORAGE_PREFIX + slug, JSON.stringify(next));
      } catch {
        // ignore
      }
    },
    [slug]
  );

  const addHighlight = useCallback(
    (text: string, colorId: string, note: string | null = null) => {
      if (!slug || !text.trim()) return;
      const color = COLORS.find((c) => c.id === colorId) ?? COLORS[0];
      const highlight: Highlight = {
        id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
        slug,
        text: text.trim(),
        note,
        createdAt: new Date().toISOString(),
        color: color.id,
      };
      setHighlights((prev) => {
        const next = [highlight, ...prev].slice(0, 50);
        persist(next);
        return next;
      });
      toast.success("Highlight saved", { duration: 1500 });
    },
    [slug, persist]
  );

  const removeHighlight = useCallback(
    (id: string) => {
      setHighlights((prev) => {
        const next = prev.filter((h) => h.id !== id);
        persist(next);
        return next;
      });
    },
    [persist]
  );

  const clearAll = useCallback(() => {
    setHighlights([]);
    persist([]);
  }, [persist]);

  return {
    highlights,
    activeColor,
    setActiveColor,
    addHighlight,
    removeHighlight,
    clearAll,
  };
}

/**
 * restoreHighlights — walks the article DOM and wraps saved highlight text
 * in <mark> elements so they're visually highlighted on load.
 *
 * Uses a TreeWalker to find text nodes, then searches for highlight text
 * within each node. Wraps matches in <mark data-highlight="id"> elements
 * with the appropriate background color.
 */
export function restoreHighlights(
  articleEl: HTMLElement,
  highlights: Highlight[]
) {
  if (!articleEl || highlights.length === 0) return;

  const walker = document.createTreeWalker(articleEl, NodeFilter.SHOW_TEXT, {
    acceptNode: (node) => {
      // Skip nodes inside existing marks, scripts, or empty text
      const parent = node.parentElement;
      if (!parent || !node.textContent?.trim()) return NodeFilter.FILTER_REJECT;
      if (parent.tagName === "MARK") return NodeFilter.FILTER_REJECT;
      if (parent.tagName === "SCRIPT" || parent.tagName === "STYLE")
        return NodeFilter.FILTER_REJECT;
      return NodeFilter.FILTER_ACCEPT;
    },
  });

  const textNodes: Text[] = [];
  let current = walker.nextNode();
  while (current) {
    textNodes.push(current as Text);
    current = walker.nextNode();
  }

  for (const highlight of highlights) {
    const color = COLORS.find((c) => c.id === highlight.color) ?? COLORS[0];
    const target = highlight.text.trim();
    if (!target) continue;

    for (const textNode of textNodes) {
      const content = textNode.textContent ?? "";
      const idx = content.indexOf(target);
      if (idx === -1) continue;

      // Split the text node and wrap the match
      const range = document.createRange();
      range.setStart(textNode, idx);
      range.setEnd(textNode, idx + target.length);

      const mark = document.createElement("mark");
      mark.setAttribute("data-highlight", highlight.id);
      mark.style.backgroundColor = color.hex;
      mark.style.borderRadius = "3px";
      mark.style.padding = "0 2px";
      mark.style.cursor = "pointer";
      mark.title = "Click to remove highlight";

      mark.addEventListener("click", (e) => {
        e.stopPropagation();
        // Remove the mark and unwrap the text
        const parent = mark.parentNode;
        if (parent) {
          while (mark.firstChild) {
            parent.insertBefore(mark.firstChild, mark);
          }
          parent.removeChild(mark);
          parent.normalize(); // Merge adjacent text nodes
        }
        // Also remove from localStorage via a custom event
        window.dispatchEvent(
          new CustomEvent("highlight-remove", { detail: highlight.id })
        );
      });

      try {
        range.surroundContents(mark);
        // Refresh text nodes list since the DOM changed
        break;
      } catch {
        // surroundContents fails if the range spans multiple elements
        continue;
      }
    }
  }
}

/**
 * SelectionPopover — floating popover that appears when the user selects text
 * in the article, offering highlight color options.
 */
export function SelectionPopover({
  targetRef,
  onHighlight,
  activeColor,
  onColorChange,
}: {
  targetRef: React.RefObject<HTMLElement | null>;
  onHighlight: (text: string, color: string) => void;
  activeColor: string;
  onColorChange: (color: string) => void;
}) {
  const [selection, setSelection] = useState<string | null>(null);
  const [position, setPosition] = useState<{ x: number; y: number } | null>(null);

  useEffect(() => {
    const target = targetRef.current;
    if (!target) return;

    const onMouseUp = (e: MouseEvent) => {
      setTimeout(() => {
        const sel = window.getSelection();
        const text = sel?.toString().trim() ?? "";
        if (text.length >= 3 && text.length <= 500 && target.contains(sel?.anchorNode?.parentElement ?? null)) {
          setSelection(text);
          setPosition({ x: e.clientX, y: e.clientY });
        } else {
          setSelection(null);
        }
      }, 10);
    };

    const onScroll = () => setSelection(null);

    target.addEventListener("mouseup", onMouseUp);
    const viewport = target.querySelector("[data-radix-scroll-area-viewport]");
    if (viewport) viewport.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      target.removeEventListener("mouseup", onMouseUp);
      if (viewport) viewport.removeEventListener("scroll", onScroll);
    };
  }, [targetRef]);

  const handleHighlight = () => {
    if (selection) {
      onHighlight(selection, activeColor);
      setSelection(null);
      window.getSelection()?.removeAllRanges();
    }
  };

  if (!selection || !position) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, scale: 0.9, y: 5 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.9 }}
        className="fixed z-[60] flex items-center gap-1 rounded-lg border bg-card p-1.5 shadow-xl"
        style={{
          left: Math.min(position.x - 100, window.innerWidth - 220),
          top: position.y - 50,
        }}
      >
        <span className="px-1.5 text-[10px] font-medium text-muted-foreground">
          Highlight:
        </span>
        {COLORS.map((c) => (
          <button
            key={c.id}
            onClick={() => onColorChange(c.id)}
            className={`h-6 w-6 rounded-full border-2 transition-transform hover:scale-110 ${
              activeColor === c.id ? "border-foreground" : "border-transparent"
            }`}
            style={{ backgroundColor: c.hex }}
            aria-label={c.label}
            title={c.label}
          />
        ))}
        <div className="mx-0.5 h-5 w-px bg-border" />
        <Button
          size="sm"
          className="h-7 gap-1 px-2 text-xs"
          onClick={handleHighlight}
        >
          <Highlighter className="h-3 w-3" />
          Save
        </Button>
      </motion.div>
    </AnimatePresence>
  );
}

/**
 * HighlightsPanel — slide-in panel showing all saved highlights for the
 * current article.
 */
export function HighlightsPanel({
  open,
  onOpenChange,
  highlights,
  onRemove,
  onClear,
  onJumpTo,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  highlights: Highlight[];
  onRemove: (id: string) => void;
  onClear: () => void;
  onJumpTo: (highlight: Highlight) => void;
}) {
  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="fixed right-0 top-0 z-[60] flex h-full w-full max-w-sm flex-col border-l bg-card shadow-2xl"
          initial={{ x: "100%" }}
          animate={{ x: 0 }}
          exit={{ x: "100%" }}
          transition={{ type: "spring", stiffness: 300, damping: 30 }}
        >
          <div className="flex items-center justify-between border-b p-4">
            <div className="flex items-center gap-2">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10 text-primary">
                <Highlighter className="h-5 w-5" />
              </div>
              <div>
                <h2 className="font-serif text-lg font-bold">Highlights</h2>
                <p className="text-xs text-muted-foreground">
                  {highlights.length} saved quote{highlights.length !== 1 ? "s" : ""}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-1">
              {highlights.length > 0 && (
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-xs text-muted-foreground hover:text-destructive"
                  onClick={onClear}
                >
                  <Trash2 className="mr-1 h-3.5 w-3.5" />
                  Clear
                </Button>
              )}
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={() => onOpenChange(false)}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>

          <ScrollArea className="flex-1 min-h-0 scroll-area-thin">
            {highlights.length === 0 ? (
              <div className="flex flex-col items-center justify-center px-6 py-20 text-center">
                <div className="mb-3 flex h-14 w-14 items-center justify-center rounded-full bg-muted">
                  <Highlighter className="h-7 w-7 text-muted-foreground" />
                </div>
                <h3 className="font-semibold">No highlights yet</h3>
                <p className="mt-1 max-w-xs text-sm text-muted-foreground">
                  Select text in the article to highlight key passages.
                  They&apos;ll appear here for quick reference.
                </p>
              </div>
            ) : (
              <div className="space-y-2 p-3">
                {highlights.map((h, i) => {
                  const color = COLORS.find((c) => c.id === h.color) ?? COLORS[0];
                  return (
                    <motion.div
                      key={h.id}
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: i * 0.04 }}
                      className="group relative rounded-xl border bg-card p-3"
                    >
                      <button
                        onClick={() => onJumpTo(h)}
                        className="block w-full text-left"
                      >
                        <div className="mb-1.5 flex items-center gap-1.5">
                          <Quote className={`h-3 w-3 ${color.text}`} />
                          <span className={`text-[10px] font-semibold uppercase tracking-wide ${color.text}`}>
                            {color.label}
                          </span>
                        </div>
                        <p className={`rounded-md ${color.bg} px-2.5 py-1.5 text-sm italic leading-relaxed`}>
                          &ldquo;{h.text}&rdquo;
                        </p>
                      </button>
                      <button
                        onClick={() => onRemove(h.id)}
                        className="absolute right-1.5 top-1.5 flex h-6 w-6 items-center justify-center rounded-full bg-background/80 text-muted-foreground opacity-0 backdrop-blur-sm transition-all hover:bg-destructive/10 hover:text-destructive group-hover:opacity-100"
                        aria-label="Remove highlight"
                      >
                        <X className="h-3.5 w-3.5" />
                      </button>
                    </motion.div>
                  );
                })}
              </div>
            )}
          </ScrollArea>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

/**
 * FloatingHighlightButton — appears in the article reader to open the
 * highlights panel.
 */
export function FloatingHighlightButton({
  count,
  onClick,
}: {
  count: number;
  onClick: () => void;
}) {
  return (
    <motion.button
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      onClick={onClick}
      className="relative flex h-10 w-10 items-center justify-center rounded-full border bg-card shadow-lg transition-all hover:scale-105 hover:shadow-xl"
      aria-label="View highlights"
      title="View highlights"
    >
      <Highlighter className="h-4 w-4 text-primary" />
      {count > 0 && (
        <span className="absolute -right-1 -top-1 flex h-5 min-w-5 items-center justify-center rounded-full bg-primary px-1 text-[10px] font-bold text-primary-foreground">
          {count}
        </span>
      )}
    </motion.button>
  );
}
