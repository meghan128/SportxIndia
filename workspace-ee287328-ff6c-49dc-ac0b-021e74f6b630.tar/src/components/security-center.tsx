"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
} from "@/components/ui/sheet";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { ReportContentDialog } from "@/components/report-content-dialog";
import { AnalyticsCharts } from "@/components/analytics-charts";
import {
  ShieldCheck,
  ShieldAlert,
  Activity,
  FileWarning,
  Flag,
  Fingerprint,
  Lock,
  CheckCircle2,
  XCircle,
  Loader2,
  AlertTriangle,
  ExternalLink,
  Clock,
  Ban,
  Eye,
  TrendingUp,
  Database,
  ScanLine,
  BarChart3,
} from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";
import type {
  DashboardStats,
  AuditEntry,
  SecurityIncident,
  ContentReport,
  PostSummary,
} from "@/lib/types";

type Tab = "overview" | "moderation" | "incidents" | "reports" | "audit";

export function SecurityCenter({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
}) {
  const [tab, setTab] = useState<Tab>("overview");
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [audit, setAudit] = useState<AuditEntry[]>([]);
  const [incidents, setIncidents] = useState<SecurityIncident[]>([]);
  const [reports, setReports] = useState<ContentReport[]>([]);
  const [quarantined, setQuarantined] = useState<PostSummary[]>([]);
  const [loading, setLoading] = useState(false);
  const [reportOpen, setReportOpen] = useState(false);

  const loadAll = async () => {
    setLoading(true);
    try {
      const [s, a, i, r] = await Promise.all([
        fetch("/api/stats").then((x) => x.json()),
        fetch("/api/audit?limit=40").then((x) => x.json()),
        fetch("/api/incidents").then((x) => x.json()),
        fetch("/api/reports").then((x) => x.json()),
      ]);
      setStats(s);
      setAudit(a.entries ?? []);
      setIncidents(i.incidents ?? []);
      setReports(r.reports ?? []);
      // load quarantined posts
      const q = await fetch("/api/posts?mod=1&limit=48").then((x) => x.json());
      setQuarantined((q.posts ?? []).filter((p: PostSummary) => p.status === "quarantined"));
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (open) loadAll();
  }, [open]);

  const moderate = async (slug: string, action: "publish" | "quarantine") => {
    try {
      await fetch(`/api/posts/${slug}/moderate`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action, actor: "owner" }),
      });
      toast.success(action === "publish" ? "Post approved & published." : "Post quarantined.");
      loadAll();
    } catch {
      toast.error("Action failed.");
    }
  };

  const resolveIncident = async (id: string, resolution: "resolved" | "ignored") => {
    try {
      await fetch(`/api/incidents/${id}/resolve`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ resolution, actor: "owner" }),
      });
      toast.success(resolution === "resolved" ? "Incident resolved." : "Incident dismissed.");
      loadAll();
    } catch {
      toast.error("Action failed.");
    }
  };

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent
        side="right"
        className="flex w-full flex-col gap-0 p-0 sm:max-w-2xl"
      >
        {/* Header */}
        <div className="border-b bg-gradient-to-br from-primary/10 via-card to-card px-5 py-4">
          <SheetHeader className="space-y-1 p-0 text-left">
            <div className="flex items-center gap-2">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary text-primary-foreground">
                <ShieldCheck className="h-5 w-5" />
              </div>
              <div>
                <SheetTitle className="text-lg">Security &amp; Content Center</SheetTitle>
                <SheetDescription className="text-xs">
                  Content-integrity verification · Moderation · DMCA reports
                </SheetDescription>
              </div>
            </div>
          </SheetHeader>
          <div className="mt-3 flex items-center gap-2">
            <Button
              size="sm"
              variant="outline"
              onClick={loadAll}
              disabled={loading}
            >
              {loading ? (
                <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" />
              ) : (
                <ScanLine className="mr-1.5 h-3.5 w-3.5" />
              )}
              Refresh scan
            </Button>
            <Button
              size="sm"
              variant="secondary"
              onClick={() => setReportOpen(true)}
            >
              <Flag className="mr-1.5 h-3.5 w-3.5" />
              Report theft
            </Button>
          </div>
        </div>

        {/* Tabs */}
        <div className="px-3 pt-3">
          <Tabs value={tab} onValueChange={(v) => setTab(v as Tab)}>
            <ScrollArea className="w-full whitespace-nowrap">
              <TabsList className="grid w-max grid-cols-5">
                <TabsTrigger value="overview" className="gap-1.5">
                  <Activity className="h-3.5 w-3.5" /> Overview
                </TabsTrigger>
                <TabsTrigger value="moderation" className="gap-1.5">
                  <FileWarning className="h-3.5 w-3.5" /> Queue
                  {quarantined.length > 0 && (
                    <Badge variant="destructive" className="ml-1 h-4 px-1 text-[10px]">
                      {quarantined.length}
                    </Badge>
                  )}
                </TabsTrigger>
                <TabsTrigger value="incidents" className="gap-1.5">
                  <ShieldAlert className="h-3.5 w-3.5" /> Incidents
                  {(stats?.incidents.open ?? 0) > 0 && (
                    <Badge variant="destructive" className="ml-1 h-4 px-1 text-[10px]">
                      {stats?.incidents.open}
                    </Badge>
                  )}
                </TabsTrigger>
                <TabsTrigger value="reports" className="gap-1.5">
                  <Flag className="h-3.5 w-3.5" /> Reports
                  {(stats?.reports.open ?? 0) > 0 && (
                    <Badge variant="secondary" className="ml-1 h-4 px-1 text-[10px]">
                      {stats?.reports.open}
                    </Badge>
                  )}
                </TabsTrigger>
                <TabsTrigger value="audit" className="gap-1.5">
                  <Clock className="h-3.5 w-3.5" /> Audit
                </TabsTrigger>
              </TabsList>
            </ScrollArea>

            <TabsContent value="overview" className="mt-4">
              <ScrollArea className="h-[calc(100vh-13rem)] scroll-area-thin pr-3">
                <OverviewPanel stats={stats} audit={audit.slice(0, 5)} />
              </ScrollArea>
            </TabsContent>

            <TabsContent value="moderation" className="mt-4">
              <ScrollArea className="h-[calc(100vh-13rem)] scroll-area-thin pr-3">
                <ModerationPanel posts={quarantined} onModerate={moderate} />
              </ScrollArea>
            </TabsContent>

            <TabsContent value="incidents" className="mt-4">
              <ScrollArea className="h-[calc(100vh-13rem)] scroll-area-thin pr-3">
                <IncidentsPanel
                  incidents={incidents}
                  onResolve={resolveIncident}
                />
              </ScrollArea>
            </TabsContent>

            <TabsContent value="reports" className="mt-4">
              <ScrollArea className="h-[calc(100vh-13rem)] scroll-area-thin pr-3">
                <ReportsPanel reports={reports} />
              </ScrollArea>
            </TabsContent>

            <TabsContent value="audit" className="mt-4">
              <ScrollArea className="h-[calc(100vh-13rem)] scroll-area-thin pr-3">
                <AuditPanel entries={audit} />
              </ScrollArea>
            </TabsContent>
          </Tabs>
        </div>
      </SheetContent>

      <ReportContentDialog open={reportOpen} onOpenChange={setReportOpen} postId={null} postTitle={null} />
    </Sheet>
  );
}

// ---------- Overview ----------
function OverviewPanel({
  stats,
  audit,
}: {
  stats: DashboardStats | null;
  audit: AuditEntry[];
}) {
  if (!stats) return <Loading />;
  const cards = [
    {
      label: "Published articles",
      value: stats.posts.published,
      total: stats.posts.total,
      icon: Database,
      tone: "default",
    },
    {
      label: "Quarantined",
      value: stats.posts.quarantined,
      icon: Ban,
      tone: stats.posts.quarantined > 0 ? "destructive" : "default",
    },
    {
      label: "Open incidents",
      value: stats.incidents.open,
      icon: ShieldAlert,
      tone: stats.incidents.open > 0 ? "destructive" : "default",
    },
    {
      label: "Theft reports (open)",
      value: stats.reports.open,
      sub: `${stats.reports.total} total filed`,
      icon: Flag,
      tone: stats.reports.open > 0 ? "warning" : "default",
    },
    {
      label: "Verified fingerprints",
      value: stats.integrity.verifiedFingerprints,
      sub: `${stats.integrity.coverage}% coverage`,
      icon: Fingerprint,
      tone: "success",
    },
    {
      label: "Total views",
      value: stats.engagement.totalViews,
      icon: Eye,
      tone: "default",
    },
  ] as const;

  return (
    <div className="space-y-5 pb-6">
      <div className="grid grid-cols-2 gap-3">
        {cards.map((c) => (
          <div
            key={c.label}
            className={`rounded-xl border p-4 ${
              c.tone === "destructive"
                ? "border-destructive/30 bg-destructive/5"
                : c.tone === "warning"
                  ? "border-amber-500/30 bg-amber-50 dark:bg-amber-950/20"
                  : c.tone === "success"
                    ? "border-emerald-500/30 bg-emerald-50 dark:bg-emerald-950/20"
                    : "bg-card"
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs text-muted-foreground">{c.label}</span>
              <c.icon
                className={`h-4 w-4 ${
                  c.tone === "destructive"
                    ? "text-destructive"
                    : c.tone === "warning"
                      ? "text-amber-600"
                      : c.tone === "success"
                        ? "text-emerald-600"
                        : "text-muted-foreground"
                }`}
              />
            </div>
            <div className="mt-1 flex items-baseline gap-1">
              <span className="text-2xl font-bold tabular-nums">
                {c.value.toLocaleString()}
              </span>
              {"total" in c && c.total !== undefined && (
                <span className="text-xs text-muted-foreground">/ {c.total}</span>
              )}
            </div>
            {"sub" in c && c.sub && (
              <span className="text-[11px] text-muted-foreground">{c.sub}</span>
            )}
          </div>
        ))}
      </div>

      {/* Integrity meter */}
      <div className="rounded-xl border bg-card p-4">
        <div className="mb-2 flex items-center justify-between">
          <span className="flex items-center gap-2 text-sm font-semibold">
            <Lock className="h-4 w-4 text-primary" />
            Content-integrity coverage
          </span>
          <Badge variant="outline" className="font-mono text-[11px]">
            {stats.integrity.algorithm}
          </Badge>
        </div>
        <Progress value={stats.integrity.coverage} className="h-2" />
        <p className="mt-2 text-xs text-muted-foreground">
          {stats.integrity.verifiedFingerprints} of {stats.posts.total} posts have a
          cryptographic fingerprint. Readers can verify any article is an
          unmodified SportX India original.
        </p>
      </div>

      {/* Analytics charts */}
      <div>
        <h3 className="mb-3 flex items-center gap-2 text-sm font-semibold">
          <BarChart3 className="h-4 w-4 text-primary" />
          Analytics
        </h3>
        <AnalyticsCharts />
      </div>

      {/* Recent activity */}
      <div>
        <h3 className="mb-2 flex items-center gap-2 text-sm font-semibold">
          <TrendingUp className="h-4 w-4 text-primary" />
          Recent security activity
        </h3>
        <div className="space-y-2">
          {audit.length === 0 && (
            <p className="text-xs text-muted-foreground">No recent activity.</p>
          )}
          {audit.map((a) => (
            <AuditRow key={a.id} entry={a} compact />
          ))}
        </div>
      </div>
    </div>
  );
}

// ---------- Moderation ----------
function ModerationPanel({
  posts,
  onModerate,
}: {
  posts: PostSummary[];
  onModerate: (slug: string, action: "publish" | "quarantine") => void;
}) {
  if (posts.length === 0) {
    return (
      <EmptyState
        icon={CheckCircle2}
        title="Moderation queue clear"
        desc="No posts are currently quarantined. New submissions and auto-moderation flags will appear here."
        tone="success"
      />
    );
  }
  return (
    <div className="space-y-3 pb-6">
      <div className="rounded-lg border border-destructive/30 bg-destructive/5 p-3 text-xs text-destructive">
        <AlertTriangle className="mr-1.5 inline h-3.5 w-3.5" />
        {posts.length} post{posts.length !== 1 && "s"} flagged by auto-moderation.
        Review and approve legitimate content, or keep quarantined to hide it
        from public view.
      </div>
      {posts.map((p) => {
        const reasons: string[] = (() => {
          try {
            return JSON.parse((p as PostSummary & { moderationReasons?: string }).moderationReasons || "[]");
          } catch {
            return [];
          }
        })();
        return (
          <div key={p.id} className="rounded-xl border bg-card p-4">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  <Badge variant="destructive" className="text-[10px]">
                    Score {p.moderationScore}/100
                  </Badge>
                  <span className="text-[11px] text-muted-foreground">
                    {format(new Date(p.publishedAt), "d MMM yyyy")}
                  </span>
                  <span className="text-[11px] text-muted-foreground">·</span>
                  <span className="text-[11px] text-muted-foreground">
                    by {p.author.displayName}
                  </span>
                </div>
                <h4 className="mt-1 font-semibold leading-snug">{p.title}</h4>
                {p.excerpt && (
                  <p className="mt-1 line-clamp-2 text-xs text-muted-foreground">
                    {p.excerpt}
                  </p>
                )}
                {reasons.length > 0 && (
                  <div className="mt-2 flex flex-wrap gap-1">
                    {reasons.map((r) => (
                      <Badge key={r} variant="outline" className="text-[10px] font-mono">
                        {r}
                      </Badge>
                    ))}
                  </div>
                )}
              </div>
            </div>
            <div className="mt-3 flex gap-2">
              <Button
                size="sm"
                variant="default"
                onClick={() => onModerate(p.slug, "publish")}
              >
                <CheckCircle2 className="mr-1.5 h-3.5 w-3.5" />
                Approve &amp; publish
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => onModerate(p.slug, "quarantine")}
              >
                <Ban className="mr-1.5 h-3.5 w-3.5" />
                Keep quarantined
              </Button>
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ---------- Incidents ----------
function IncidentsPanel({
  incidents,
  onResolve,
}: {
  incidents: SecurityIncident[];
  onResolve: (id: string, resolution: "resolved" | "ignored") => void;
}) {
  if (incidents.length === 0) {
    return (
      <EmptyState
        icon={ShieldCheck}
        title="No security incidents"
        desc="Auto-moderation has not flagged any suspicious activity."
        tone="success"
      />
    );
  }
  return (
    <div className="space-y-3 pb-6">
      {incidents.map((i) => (
        <div
          key={i.id}
          className={`rounded-xl border p-4 ${
            i.status === "open"
              ? i.severity === "critical"
                ? "border-destructive/40 bg-destructive/5"
                : "border-amber-500/40 bg-amber-50 dark:bg-amber-950/20"
              : "bg-card opacity-80"
          }`}
        >
          <div className="flex flex-wrap items-center gap-2">
            <Badge
              variant={
                i.severity === "critical"
                  ? "destructive"
                  : i.severity === "high"
                    ? "destructive"
                    : "secondary"
              }
              className="text-[10px] uppercase"
            >
              {i.severity}
            </Badge>
            <Badge variant="outline" className="text-[10px] font-mono">
              {i.type}
            </Badge>
            <Badge
              variant={i.status === "open" ? "default" : "secondary"}
              className="text-[10px]"
            >
              {i.status}
            </Badge>
            <span className="ml-auto text-[11px] text-muted-foreground">
              {format(new Date(i.detectedAt), "d MMM yyyy, HH:mm")}
            </span>
          </div>
          {i.post && (
            <h4 className="mt-2 font-semibold leading-snug">{i.post.title}</h4>
          )}
          <p className="mt-1 text-xs text-muted-foreground">{i.reason}</p>
          {i.status === "open" ? (
            <div className="mt-3 flex gap-2">
              <Button
                size="sm"
                variant="default"
                onClick={() => onResolve(i.id, "resolved")}
              >
                <CheckCircle2 className="mr-1.5 h-3.5 w-3.5" />
                Mark resolved
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => onResolve(i.id, "ignored")}
              >
                <XCircle className="mr-1.5 h-3.5 w-3.5" />
                Dismiss (false positive)
              </Button>
            </div>
          ) : (
            <p className="mt-2 text-[11px] text-muted-foreground">
              {i.resolution} · by {i.resolvedBy} · {i.resolvedAt && format(new Date(i.resolvedAt), "d MMM yyyy")}
            </p>
          )}
        </div>
      ))}
    </div>
  );
}

// ---------- Reports ----------
function ReportsPanel({ reports }: { reports: ContentReport[] }) {
  if (reports.length === 0) {
    return (
      <EmptyState
        icon={Flag}
        title="No content-theft reports"
        desc="When readers report stolen SportX India content on other sites, the cases will appear here for tracking."
      />
    );
  }
  return (
    <div className="space-y-3 pb-6">
      {reports.map((r) => (
        <div key={r.id} className="rounded-xl border bg-card p-4">
          <div className="flex flex-wrap items-center gap-2">
            <Badge
              variant={r.status === "open" ? "destructive" : "secondary"}
              className="text-[10px] uppercase"
            >
              {r.status}
            </Badge>
            <span className="text-[11px] text-muted-foreground">
              {format(new Date(r.createdAt), "d MMM yyyy")}
            </span>
            <span className="text-[11px] text-muted-foreground">·</span>
            <span className="text-[11px] text-muted-foreground">
              by {r.reporterName}
            </span>
          </div>
          {r.post && (
            <p className="mt-1 text-xs font-medium">
              Original: “{r.post.title}”
            </p>
          )}
          <a
            href={r.infringingUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-1 flex items-center gap-1 text-xs text-primary underline underline-offset-2"
          >
            <ExternalLink className="h-3 w-3" />
            {r.infringingUrl}
          </a>
          <p className="mt-2 text-xs text-muted-foreground">{r.description}</p>
        </div>
      ))}
    </div>
  );
}

// ---------- Audit ----------
function AuditPanel({ entries }: { entries: AuditEntry[] }) {
  if (entries.length === 0) {
    return (
      <EmptyState
        icon={Clock}
        title="Audit log empty"
        desc="Every moderation, resolve, and report action is recorded here."
      />
    );
  }
  return (
    <div className="space-y-2 pb-6">
      {entries.map((e) => (
        <AuditRow key={e.id} entry={e} />
      ))}
    </div>
  );
}

function AuditRow({ entry, compact = false }: { entry: AuditEntry; compact?: boolean }) {
  const color =
    entry.severity === "critical"
      ? "text-destructive bg-destructive/10"
      : entry.severity === "warning"
        ? "text-amber-600 bg-amber-100 dark:bg-amber-950/40"
        : "text-emerald-600 bg-emerald-100 dark:bg-emerald-950/40";
  const icon =
    entry.severity === "critical"
      ? ShieldAlert
      : entry.severity === "warning"
        ? AlertTriangle
        : CheckCircle2;
  const Icon = icon;
  return (
    <div className={`flex gap-3 ${compact ? "" : "rounded-lg border bg-card p-3"}`}>
      <div className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-full ${color}`}>
        <Icon className="h-3.5 w-3.5" />
      </div>
      <div className="min-w-0 flex-1">
        <p className="text-sm leading-snug">{entry.message}</p>
        <div className="mt-0.5 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-[11px] text-muted-foreground">
          <Badge variant="outline" className="h-4 px-1 text-[10px] font-mono">
            {entry.action}
          </Badge>
          <span>by {entry.actor}</span>
          {!compact && <span>·</span>}
          {!compact && <span>{format(new Date(entry.createdAt), "d MMM yyyy, HH:mm:ss")}</span>}
        </div>
      </div>
    </div>
  );
}

function Loading() {
  return (
    <div className="flex h-40 items-center justify-center text-muted-foreground">
      <Loader2 className="mr-2 h-5 w-5 animate-spin" />
      Loading…
    </div>
  );
}

function EmptyState({
  icon: Icon,
  title,
  desc,
  tone = "default",
}: {
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  desc: string;
  tone?: "default" | "success";
}) {
  return (
    <div className="flex flex-col items-center justify-center py-12 text-center">
      <div
        className={`mb-3 flex h-12 w-12 items-center justify-center rounded-full ${
          tone === "success"
            ? "bg-emerald-100 text-emerald-600 dark:bg-emerald-950/40"
            : "bg-muted text-muted-foreground"
        }`}
      >
        <Icon className="h-6 w-6" />
      </div>
      <h4 className="font-semibold">{title}</h4>
      <p className="mt-1 max-w-xs text-xs text-muted-foreground">{desc}</p>
    </div>
  );
}
