"use client";

import { useState } from "react";
import { Mail, CheckCircle2, Loader2, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";

export function NewsletterSignup({
  variant = "footer",
  className,
}: {
  variant?: "footer" | "inline";
  className?: string;
}) {
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);

  const submit = async () => {
    if (!email) {
      toast.error("Please enter your email.");
      return;
    }
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) {
      toast.error("Please enter a valid email.");
      return;
    }
    setLoading(true);
    try {
      const res = await fetch("/api/newsletter", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, name, source: variant }),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || "Subscription failed");
      }
      const data = await res.json();
      setDone(true);
      if (data.already) {
        toast.success("You're already subscribed — thanks for your support!");
      } else if (data.reactivated) {
        toast.success("Welcome back! Your subscription has been reactivated.");
      } else {
        toast.success("Subscribed! Check your inbox for a confirmation.");
      }
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Subscription failed");
    } finally {
      setLoading(false);
    }
  };

  if (done) {
    return (
      <div
        className={`flex items-center gap-3 rounded-xl border border-emerald-500/30 bg-emerald-50 p-4 dark:bg-emerald-950/20 ${className ?? ""}`}
      >
        <CheckCircle2 className="h-5 w-5 shrink-0 text-emerald-600" />
        <div className="text-sm">
          <p className="font-semibold text-foreground">You're subscribed!</p>
          <p className="text-muted-foreground">
            New SportX India stories land in your inbox weekly.
          </p>
        </div>
      </div>
    );
  }

  if (variant === "inline") {
    return (
      <div
        className={`rounded-2xl border bg-gradient-to-br from-primary/5 via-card to-card p-6 ${className ?? ""}`}
      >
        <div className="mb-3 flex items-center gap-2">
          <Sparkles className="h-4 w-4 text-primary" />
          <h3 className="font-serif text-lg font-bold">Never miss a story</h3>
        </div>
        <p className="mb-4 text-sm text-muted-foreground">
          Get the best of SportX India — memoirs, editorials, and the science
          behind the game — delivered weekly. No spam, ever.
        </p>
        <div className="flex flex-col gap-2 sm:flex-row">
          <Input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && submit()}
            placeholder="you@example.com"
            className="flex-1 transition-all focus-visible:ring-2 focus-visible:ring-primary/40 focus-visible:ring-offset-2 focus-visible:border-primary"
          />
          <Button onClick={submit} disabled={loading}>
            {loading ? (
              <Loader2 className="mr-1.5 h-4 w-4 animate-spin" />
            ) : (
              <Mail className="mr-1.5 h-4 w-4" />
            )}
            Subscribe
          </Button>
        </div>
      </div>
    );
  }

  // footer variant — compact
  return (
    <div className={className}>
      <div className="mb-3 flex items-center gap-2">
        <Mail className="h-4 w-4 text-primary" />
        <h4 className="text-xs font-semibold uppercase tracking-wider text-background/60">
          Newsletter
        </h4>
      </div>
      <p className="mb-3 text-sm text-background/70">
        Weekly sports stories, delivered. No spam.
      </p>
      <div className="flex flex-col gap-2 sm:flex-row">
        <Input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && submit()}
          placeholder="you@example.com"
          className="flex-1 border-background/20 bg-background/10 text-background placeholder:text-background/40"
        />
        <Button
          onClick={submit}
          disabled={loading}
          size="sm"
          className="bg-primary text-primary-foreground hover:bg-primary/90"
        >
          {loading ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : (
            "Subscribe"
          )}
        </Button>
      </div>
    </div>
  );
}
